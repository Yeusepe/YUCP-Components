# Developer Guide

**Create your own YUCP-compatible components with preprocessing, custom UI, and VRCFury integration.**

## Overview

This guide shows you how to create custom components that integrate with the YUCP Components ecosystem. You'll learn the architecture, preprocessing system, custom UI creation, and VRCFury integration patterns used throughout YUCP Components.

### What You'll Learn
- Component architecture and interfaces
- Build preprocessing system
- Custom Inspector UI with YUCP branding
- VRCFury API integration
- Progress window usage
- Beta warning system
- Icon assignment
- Best practices

## YUCP Component Architecture

### Core Interfaces

Every YUCP component implements these interfaces:

```csharp
using VRC.SDKBase;

public class MyCustomComponent : MonoBehaviour, 
    IEditorOnly,                    // Removed from builds
    IPreprocessCallbackBehaviour    // VRCFury requirement
{
    public int PreprocessOrder => 0;
    public bool OnPreprocess() => true;
}
```

**IEditorOnly**: Component is stripped from builds (editor-only)  
**IPreprocessCallbackBehaviour**: Required by VRCFury for preprocessing

### Component + Processor Pattern

YUCP uses a two-class pattern:

**Runtime Component** (Data Container):
```csharp
// Runtime/Components/Data/MyCustomComponent.cs
public class MyCustomComponent : MonoBehaviour, IEditorOnly, IPreprocessCallbackBehaviour
{
    [Tooltip("Example setting")]
    public bool exampleFlag;
    
    [Tooltip("Target object")]
    public GameObject targetObject;
    
    public int PreprocessOrder => 0;
    public bool OnPreprocess() => true;
}
```

**Editor Processor** (Build Logic):
```csharp
// Editor/Components/Processors/MyCustomComponentProcessor.cs
public class MyCustomComponentProcessor : IVRCSDKPreprocessAvatarCallback
{
    public int callbackOrder => 0;  // Execution order
    
    public bool OnPreprocessAvatar(GameObject avatarRoot)
    {
        var components = avatarRoot.GetComponentsInChildren<MyCustomComponent>(true);
        
        foreach (var comp in components)
        {
            ProcessComponent(comp);
        }
        
        return true;  // Continue build
    }
    
    private void ProcessComponent(MyCustomComponent comp)
    {
        // Your processing logic here
    }
}
```

### Why This Pattern?

**Separation of concerns**:
- Component = Data (serialized, survives Unity reloads)
- Processor = Logic (build-time only, no serialization)

**Benefits**:
- Clean data model
- Testable processing
- No runtime overhead
- Easy to understand

## Step-by-Step: Creating a Component

### Step 1: Create Runtime Component

**File**: `Runtime/Components/Data/MyCustomComponent.cs`

```csharp
using UnityEngine;
using VRC.SDKBase;

namespace YUCP.Components
{
    [AddComponentMenu("YUCP/My Custom Component")]
    [HelpURL("https://github.com/yourname/your-repo")]
    [DisallowMultipleComponent]
    public class MyCustomComponent : MonoBehaviour, IEditorOnly, IPreprocessCallbackBehaviour
    {
        [Header("Settings")]
        [Tooltip("Enable this feature")]
        public bool enableFeature = true;
        
        [Tooltip("Target GameObject to affect")]
        public GameObject targetObject;
        
        [Tooltip("Intensity of the effect")]
        [Range(0f, 1f)]
        public float intensity = 0.5f;
        
        [Header("Statistics (Read-only)")]
        [SerializeField] private int processedCount = 0;
        
        public int ProcessedCount => processedCount;
        
        public int PreprocessOrder => 0;
        public bool OnPreprocess() => true;
        
        public void SetProcessedCount(int count)
        {
            processedCount = count;
        }
    }
}
```

**Key attributes**:
- `[AddComponentMenu]` - Where component appears in Add Component menu
- `[HelpURL]` - Help button link
- `[DisallowMultipleComponent]` - Only one per GameObject
- `[Header]` - Section headers in Inspector
- `[Tooltip]` - Hover tooltips
- `[Range]` - Slider for numeric values
- `[SerializeField]` - Serialize private field

### Step 2: Create .meta File

**File**: `Runtime/Components/Data/MyCustomComponent.cs.meta`

```yaml
fileFormatVersion: 2
guid: [Generate unique GUID]
MonoImporter:
  externalObjects: {}
  serializedVersion: 2
  defaultReferences: []
  executionOrder: 0
  icon: {instanceID: 0}
  userData: 
  assetBundleName: 
  assetBundleVariant: 
```

Unity generates this automatically when you create the file.

### Step 3: Create Processor

**File**: `Editor/Components/Processors/MyCustomComponentProcessor.cs`

```csharp
using UnityEngine;
using VRC.SDKBase.Editor.BuildPipeline;
using YUCP.Components;
using YUCP.Components.Editor.UI;

namespace YUCP.Components.Editor
{
    public class MyCustomComponentProcessor : IVRCSDKPreprocessAvatarCallback
    {
        public int callbackOrder => 0;  // Adjust based on dependencies
        
        public bool OnPreprocessAvatar(GameObject avatarRoot)
        {
            var components = avatarRoot.GetComponentsInChildren<MyCustomComponent>(true);
            
            if (components.Length == 0)
                return true;  // Nothing to process
            
            var progressWindow = YUCPProgressWindow.Create();
            progressWindow.Progress(0, "Processing custom components...");
            
            try
            {
                for (int i = 0; i < components.Length; i++)
                {
                    var comp = components[i];
                    
                    if (!ValidateComponent(comp))
                    {
                        Debug.LogError($"Validation failed for {comp.name}", comp);
                        continue;
                    }
                    
                    ProcessComponent(comp);
                    
                    float progress = (float)(i + 1) / components.Length;
                    progressWindow.Progress(progress, $"Processed {i + 1}/{components.Length}");
                }
            }
            finally
            {
                progressWindow.CloseWindow();
            }
            
            return true;
        }
        
        private bool ValidateComponent(MyCustomComponent comp)
        {
            if (comp.targetObject == null)
            {
                Debug.LogError("Target object not set", comp);
                return false;
            }
            
            return true;
        }
        
        private void ProcessComponent(MyCustomComponent comp)
        {
            // Your processing logic
            Debug.Log($"Processing {comp.name} with intensity {comp.intensity}", comp);
            
            // Example: Set processed count
            comp.SetProcessedCount(1);
            
            // Example: Modify target object
            if (comp.targetObject != null && comp.enableFeature)
            {
                // Do something with the target
            }
        }
    }
}
```

### Step 4: Create Custom Inspector

**File**: `Editor/Header/MyCustomComponentEditor.cs`

```csharp
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;
using YUCP.Components;

namespace YUCP.Components.Resources
{
    [CustomEditor(typeof(MyCustomComponent))]
    public class MyCustomComponentEditor : UnityEditor.Editor
    {
        public override VisualElement CreateInspectorGUI()
        {
            var root = new VisualElement();
            
            // Add YUCP header
            root.Add(YUCPComponentHeader.CreateHeaderOverlay("My Custom Component"));
            
            // Add IMGUI container
            var container = new IMGUIContainer(() => {
                serializedObject.Update();
                
                DrawSection("Settings", () => {
                    EditorGUILayout.PropertyField(serializedObject.FindProperty("enableFeature"));
                    EditorGUILayout.PropertyField(serializedObject.FindProperty("targetObject"));
                    EditorGUILayout.PropertyField(serializedObject.FindProperty("intensity"));
                });
                
                // Read-only statistics
                if (((MyCustomComponent)target).ProcessedCount > 0)
                {
                    EditorGUILayout.Space(5);
                    EditorGUILayout.HelpBox(
                        $"Processed: {((MyCustomComponent)target).ProcessedCount} times",
                        MessageType.Info);
                }
                
                serializedObject.ApplyModifiedProperties();
            });
            
            root.Add(container);
            return root;
        }
        
        private void DrawSection(string title, System.Action content)
        {
            EditorGUILayout.Space(5);
            
            var originalColor = GUI.backgroundColor;
            GUI.backgroundColor = new Color(0f, 0f, 0f, 0.1f);
            
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            GUI.backgroundColor = originalColor;
            
            if (!string.IsNullOrEmpty(title))
            {
                var style = new GUIStyle(EditorStyles.boldLabel);
                style.alignment = TextAnchor.MiddleLeft;
                EditorGUILayout.LabelField(title, style);
                EditorGUILayout.Space(3);
            }
            
            content?.Invoke();
            
            EditorGUILayout.EndVertical();
        }
    }
}
```

### Step 5: Test Your Component

1. Create new GameObject in avatar
2. Add Component → YUCP → My Custom Component
3. Configure settings
4. Build avatar
5. Check Console for processing logs

## Advanced Features

### Beta Warning System

Add beta warning to experimental components:

```csharp
using YUCP.Components;

[BetaWarning("This component is experimental. Use with caution.")]
public class MyBetaComponent : MonoBehaviour, IEditorOnly, IPreprocessCallbackBehaviour
{
    // ...
}
```

**Custom message**:
```csharp
[BetaWarning("Known issues: Feature X may not work on all avatars.")]
public class MyBetaComponent : MonoBehaviour
{
    // ...
}
```

**Inspector automatically shows warning**:
- Red background
- Warning icon
- Custom message text

[Image: Inspector showing beta warning box]

**Manual warning in custom Inspector**:
```csharp
public override void OnInspectorGUI()
{
    BetaWarningHelper.DrawBetaWarningIMGUI(typeof(MyBetaComponent));
    
    // Rest of Inspector UI
}
```

### Callback Order Management

**Callback order** determines when your processor runs:

```csharp
public int callbackOrder => 0;  // Default

// Early processors (run first)
public int callbackOrder => int.MinValue;      // Armature components
public int callbackOrder => int.MinValue + 50; // Auto Grip
public int callbackOrder => int.MinValue + 99; // Auto Body Hider Coordinator

// Late processors (run after others)
public int callbackOrder => int.MinValue + 100; // Auto Body Hider
public int callbackOrder => int.MinValue + 200; // Gesture Manager Input
```

**Guidelines**:
- Run early if other components depend on you
- Run late if you depend on other components
- Use same order as similar components
- Document order decisions

### VRCFury API Integration

**Creating toggles**:
```csharp
using com.vrcfury.api;

var toggle = FuryComponents.CreateToggle(gameObject);
toggle.SetMenuPath("MyMenu/MyToggle");
toggle.SetSaved();
toggle.SetDefaultOn();
toggle.SetGlobalParameter("MyParam");

var actions = toggle.GetActions();
actions.AddTurnOn(targetObject);
actions.AddAnimationClip(animationClip);
```

**Creating armature links**:
```csharp
var link = FuryComponents.CreateArmatureLink(gameObject);
link.LinkTo(HumanBodyBones.Head);
link.LinkTo("Armature/Hips/Tail/Tail_01");
```

**Advanced toggle features** (via reflection):
```csharp
// Access internal toggle model
var toggleType = toggle.GetType();
var cField = toggleType.GetField("c", BindingFlags.NonPublic | BindingFlags.Instance);
var toggleModel = cField.GetValue(toggle);

// Set hold button
var holdButtonField = toggleModel.GetType().GetField("holdButton", BindingFlags.Public | BindingFlags.Instance);
holdButtonField?.SetValue(toggleModel, true);

// Add exclusive tag
toggle.AddExclusiveTag("OutfitGroup1");
```

### Progress Window Usage

```csharp
using YUCP.Components.Editor.UI;

// Create window
var progressWindow = YUCPProgressWindow.Create();

// Update progress
progressWindow.Progress(0.0f, "Starting...");
progressWindow.Progress(0.5f, "Halfway done...");
progressWindow.Progress(1.0f, "Complete!");

// Always close when done
progressWindow.CloseWindow();
```

**Best practices**:
- Create at start of processing
- Update regularly (every item or every 10%)
- Always close in finally block
- Use descriptive status messages

### Custom Inspector Patterns

#### Pattern 1: Pure IMGUI
```csharp
public override void OnInspectorGUI()
{
    serializedObject.Update();
    
    EditorGUILayout.PropertyField(serializedObject.FindProperty("myField"));
    
    serializedObject.ApplyModifiedProperties();
}
```

#### Pattern 2: UIElements with IMGUI Container (Recommended)
```csharp
public override VisualElement CreateInspectorGUI()
{
    var root = new VisualElement();
    root.Add(YUCPComponentHeader.CreateHeaderOverlay("My Component"));
    
    var container = new IMGUIContainer(() => {
        serializedObject.Update();
        // IMGUI code here
        serializedObject.ApplyModifiedProperties();
    });
    
    root.Add(container);
    return root;
}
```

#### Pattern 3: Foldouts
```csharp
private bool showAdvanced = false;

void OnInspectorGUI()
{
    showAdvanced = EditorGUILayout.BeginFoldoutHeaderGroup(showAdvanced, "Advanced Options");
    if (showAdvanced)
    {
        EditorGUI.indentLevel++;
        // Advanced fields here
        EditorGUI.indentLevel--;
    }
    EditorGUILayout.EndFoldoutHeaderGroup();
}
```

### Scene View Gizmos

**DrawGizmo attribute**:
```csharp
[DrawGizmo(GizmoType.Selected | GizmoType.Active)]
static void DrawGizmos(MyCustomComponent data, GizmoType gizmoType)
{
    if (!data.showPreview) return;
    
    // Draw visualization
    Gizmos.color = Color.cyan;
    Gizmos.DrawWireSphere(data.targetObject.transform.position, 0.1f);
    
    // Draw handles
    Handles.color = Color.yellow;
    Handles.Label(data.transform.position, "My Component");
}
```

**Scene GUI callback**:
```csharp
private void OnEnable()
{
    SceneView.duringSceneGui += OnSceneGUI;
}

private void OnDisable()
{
    SceneView.duringSceneGui -= OnSceneGUI;
}

private void OnSceneGUI(SceneView sceneView)
{
    // Custom Scene view rendering
    Handles.BeginGUI();
    GUI.Box(new Rect(10, 10, 200, 50), "My Overlay");
    Handles.EndGUI();
}
```

## VRCFury Integration Patterns

### Pattern: Simple Toggle

```csharp
using com.vrcfury.api;

var toggle = FuryComponents.CreateToggle(data.gameObject);
toggle.SetMenuPath(data.menuPath);

if (data.saved)
    toggle.SetSaved();

var actions = toggle.GetActions();
actions.AddTurnOn(data.targetObject);
```

### Pattern: Toggle with Animation

```csharp
// Create animation clip
AnimationClip clip = CreateAnimationClip();

// Add to toggle
var toggle = FuryComponents.CreateToggle(data.gameObject);
var actions = toggle.GetActions();
actions.AddAnimationClip(clip);

// Set motion field via reflection (for runtime-created clips)
var toggleType = toggle.GetType();
var cField = toggleType.GetField("c", BindingFlags.NonPublic | BindingFlags.Instance);
var toggleModel = cField.GetValue(toggle);
var stateField = toggleModel.GetType().GetField("state", BindingFlags.Public | BindingFlags.Instance);
var state = stateField.GetValue(toggleModel);
var actionsField = state.GetType().GetField("actions", BindingFlags.Public | BindingFlags.Instance);
var actionsList = actionsField.GetValue(state) as System.Collections.IList;

if (actionsList != null && actionsList.Count > 0)
{
    var lastAction = actionsList[actionsList.Count - 1];
    var motionField = lastAction.GetType().GetField("motion", BindingFlags.Public | BindingFlags.Instance);
    motionField?.SetValue(lastAction, clip);
}
```

### Pattern: Armature Link

```csharp
var link = FuryComponents.CreateArmatureLink(data.gameObject);

// Option 1: Humanoid bone
link.LinkTo(HumanBodyBones.Head);

// Option 2: Bone with offset
link.LinkTo(HumanBodyBones.LeftHand, "Armor/MountPoint");

// Option 3: Full path
link.LinkTo("Armature/Hips/Tail/Tail_01/Tail_Tip");
```

## Best Practices

### Validation

Always validate before processing:

```csharp
private bool ValidateComponent(MyComponent comp)
{
    if (comp.targetObject == null)
    {
        Debug.LogError("[MyProcessor] Target object not set", comp);
        return false;
    }
    
    if (comp.intensity < 0 || comp.intensity > 1)
    {
        Debug.LogWarning($"[MyProcessor] Intensity {comp.intensity} out of range", comp);
        return false;
    }
    
    return true;
}
```

### Error Handling

Use try-catch for fault tolerance:

```csharp
try
{
    ProcessComponent(comp);
}
catch (System.Exception ex)
{
    Debug.LogError($"[MyProcessor] Error processing '{comp.name}': {ex.Message}", comp);
    Debug.LogException(ex);
    // Continue with other components
}
```

### Logging

Use consistent log format:

```csharp
Debug.Log($"[MyProcessor] Processing '{comp.name}'", comp);
Debug.LogWarning($"[MyProcessor] Warning for '{comp.name}': reason", comp);
Debug.LogError($"[MyProcessor] Error for '{comp.name}': reason", comp);
```

**Format**: `[ProcessorName] Message`, comp  
- Processor name in brackets
- Component passed as context (clickable in Console)

### Progress Reporting

Report progress for long operations:

```csharp
var progressWindow = YUCPProgressWindow.Create();

try
{
    for (int i = 0; i < items.Count; i++)
    {
        ProcessItem(items[i]);
        
        float progress = (float)(i + 1) / items.Count;
        progressWindow.Progress(progress, $"Processed {i + 1}/{items.Count} items");
    }
}
finally
{
    progressWindow.CloseWindow();  // Always close
}
```

### Callback Order Guidelines

Choose appropriate order:

```
int.MinValue              → Very early (armature, positioning)
int.MinValue + 50         → Early (grip generation)
int.MinValue + 100        → Mid-early (mesh modification)
int.MinValue + 200        → Mid (parameter setup)
0                         → Default (general processing)
100                       → Late (finalization)
int.MaxValue              → Very late (last-minute changes)
```

**Dependencies**:
- If you modify meshes → run before toggle creation
- If you create toggles → run after mesh modification
- If you depend on VRCFury components → run early

## Example Components

### Example 1: Simple Object Enabler

**Component**:
```csharp
[AddComponentMenu("YUCP/Examples/Object Enabler")]
public class ObjectEnabler : MonoBehaviour, IEditorOnly, IPreprocessCallbackBehaviour
{
    public GameObject targetObject;
    public bool enableOnBuild = true;
    
    public int PreprocessOrder => 0;
    public bool OnPreprocess() => true;
}
```

**Processor**:
```csharp
public class ObjectEnablerProcessor : IVRCSDKPreprocessAvatarCallback
{
    public int callbackOrder => 0;
    
    public bool OnPreprocessAvatar(GameObject avatarRoot)
    {
        var components = avatarRoot.GetComponentsInChildren<ObjectEnabler>(true);
        
        foreach (var comp in components)
        {
            if (comp.targetObject != null)
            {
                comp.targetObject.SetActive(comp.enableOnBuild);
                Debug.Log($"Set {comp.targetObject.name} active: {comp.enableOnBuild}");
            }
        }
        
        return true;
    }
}
```

### Example 2: Material Property Setter

**Component**:
```csharp
[AddComponentMenu("YUCP/Examples/Material Property Setter")]
public class MaterialPropertySetter : MonoBehaviour, IEditorOnly, IPreprocessCallbackBehaviour
{
    public Renderer targetRenderer;
    public string propertyName = "_Color";
    public Color propertyValue = Color.white;
    
    public int PreprocessOrder => 0;
    public bool OnPreprocess() => true;
}
```

**Processor**:
```csharp
public class MaterialPropertySetterProcessor : IVRCSDKPreprocessAvatarCallback
{
    public int callbackOrder => 0;
    
    public bool OnPreprocessAvatar(GameObject avatarRoot)
    {
        var components = avatarRoot.GetComponentsInChildren<MaterialPropertySetter>(true);
        
        foreach (var comp in components)
        {
            if (comp.targetRenderer == null) continue;
            
            foreach (var mat in comp.targetRenderer.sharedMaterials)
            {
                if (mat != null && mat.HasProperty(comp.propertyName))
                {
                    mat.SetColor(comp.propertyName, comp.propertyValue);
                    EditorUtility.SetDirty(mat);
                }
            }
        }
        
        return true;
    }
}
```

### Example 3: Conditional Component Deleter

```csharp
[AddComponentMenu("YUCP/Examples/Conditional Deleter")]
public class ConditionalDeleter : MonoBehaviour, IEditorOnly, IPreprocessCallbackBehaviour
{
    public Component componentToDelete;
    public bool deleteIfTrue = true;
    
    public int PreprocessOrder => 0;
    public bool OnPreprocess() => true;
}

public class ConditionalDeleterProcessor : IVRCSDKPreprocessAvatarCallback
{
    public int callbackOrder => int.MinValue;  // Run early
    
    public bool OnPreprocessAvatar(GameObject avatarRoot)
    {
        var components = avatarRoot.GetComponentsInChildren<ConditionalDeleter>(true);
        
        foreach (var comp in components)
        {
            if (comp.componentToDelete != null && comp.deleteIfTrue)
            {
                if (comp.componentToDelete is Transform tr)
                {
                    Object.DestroyImmediate(tr.gameObject);
                }
                else
                {
                    Object.DestroyImmediate(comp.componentToDelete);
                }
                
                Debug.Log($"Deleted component: {comp.componentToDelete.GetType().Name}");
            }
        }
        
        return true;
    }
}
```

## Icon Assignment

YUCP automatically assigns icons to components:

**File**: `Editor/YUCPIconAssigner.cs`

Icons are assigned to scripts in these folders:
```
Runtime/Components/Data/
Editor/Components/Processors/
```

**Icon path**: `Resources/Icons/Mini_Icon.png`

**How it works**:
- Runs on Unity startup
- Scans component scripts
- Assigns icon via .meta file modification
- Only runs once per session

**Manual icon assignment**:
```csharp
MonoScript script = GetScript();
string iconGuid = AssetDatabase.AssetPathToGUID("Packages/com.yucp.components/Resources/Icons/Mini_Icon.png");

MonoImporter importer = AssetImporter.GetAtPath(scriptPath) as MonoImporter;
importer.SetIcon(icon);
importer.SaveAndReimport();
```

## Assembly Definitions

YUCP uses two assembly definitions:

**Runtime**: `Runtime/yucp.components.Runtime.asmdef`
```json
{
  "name": "yucp.components.Runtime",
  "references": ["VRC.SDKBase"],
  "includePlatforms": [],
  "excludePlatforms": [],
  "allowUnsafeCode": false
}
```

**Editor**: `Editor/yucp.components.Editor.asmdef`
```json
{
  "name": "yucp.components.Editor",
  "references": [
    "yucp.components.Runtime",
    "VRC.SDKBase.Editor",
    "VRCFury"
  ],
  "includePlatforms": ["Editor"],
  "allowUnsafeCode": false
}
```

**Why separate assemblies?**
- Runtime: No editor dependencies, faster compile
- Editor: Can reference Runtime + editor-only libraries
- Better organization and compile times

## Testing Your Component

### Unit Testing Pattern

```csharp
#if UNITY_EDITOR
using NUnit.Framework;
using UnityEngine;

public class MyComponentTests
{
    [Test]
    public void ComponentValidation_WithoutTarget_ReturnsFalse()
    {
        var go = new GameObject();
        var comp = go.AddComponent<MyCustomComponent>();
        
        var processor = new MyCustomComponentProcessor();
        bool result = processor.ValidateComponent(comp);
        
        Assert.IsFalse(result);
        
        Object.DestroyImmediate(go);
    }
}
#endif
```

### Integration Testing

1. Create test avatar in scene
2. Add your component
3. Configure settings
4. Enter Play mode (for runtime testing)
5. Build avatar (for preprocessing testing)
6. Check Console for logs
7. Verify results in VRChat

## Common Patterns

### Pattern: Mesh Modification

```csharp
Mesh originalMesh = renderer.sharedMesh;
Mesh modifiedMesh = Object.Instantiate(originalMesh);
modifiedMesh.name = originalMesh.name + "_Modified";

// Modify mesh
Vector3[] vertices = modifiedMesh.vertices;
// ... modify vertices ...
modifiedMesh.vertices = vertices;

renderer.sharedMesh = modifiedMesh;
```

### Pattern: Material Modification

```csharp
Material originalMat = renderer.sharedMaterial;
Material modifiedMat = Object.Instantiate(originalMat);
modifiedMat.name = originalMat.name + "_Modified";

// Modify material
modifiedMat.SetFloat("_MyProperty", value);
modifiedMat.EnableKeyword("MY_KEYWORD");

var mats = renderer.sharedMaterials;
mats[materialIndex] = modifiedMat;
renderer.sharedMaterials = mats;

EditorUtility.SetDirty(modifiedMat);
```

### Pattern: Animation Creation

```csharp
AnimationClip clip = new AnimationClip();
clip.name = "MyAnimation";

// Create curve
AnimationCurve curve = AnimationCurve.Linear(0f, 0f, 1f, 1f);

// Create binding
EditorCurveBinding binding = EditorCurveBinding.FloatCurve(
    "Path/To/Object",
    typeof(GameObject),
    "m_IsActive"
);

AnimationUtility.SetEditorCurve(clip, binding, curve);
```

## Publishing Your Component

### Package Structure

```
Packages/com.yourname.yourpackage/
├── package.json
├── README.md
├── LICENSE.md
├── CHANGELOG.md
├── Runtime/
│   ├── Components/
│   │   └── Data/
│   │       └── MyComponent.cs
│   └── yourpackage.Runtime.asmdef
├── Editor/
│   ├── Components/
│   │   ├── Processors/
│   │   │   └── MyComponentProcessor.cs
│   │   └── Header/
│   │       └── MyComponentEditor.cs
│   └── yourpackage.Editor.asmdef
└── Resources/
    └── Icons/
        └── Icon.png
```

### package.json Template

```json
{
  "name": "com.yourname.yourpackage",
  "displayName": "Your Package Name",
  "version": "1.0.0",
  "description": "Description of your package",
  "unity": "2022.3",
  "author": {
    "name": "Your Name",
    "url": "https://yourwebsite.com"
  },
  "dependencies": {
    "com.vrchat.avatars": "3.5.0"
  },
  "vpmDependencies": {
    "com.vrcfury": ">=1.0.0"
  }
}
```

### README.md Template

```markdown
# Your Package Name

Description of what your package does.

## Features
- Feature 1
- Feature 2

## Installation
Via VCC or manual .unitypackage import

## Usage
1. Add component
2. Configure
3. Build

## Documentation
Link to wiki

## License
MIT
```

## For the Nerds

### IVRCSDKPreprocessAvatarCallback Interface

**VRChat SDK interface**:
```csharp
namespace VRC.SDKBase.Editor.BuildPipeline
{
    public interface IVRCSDKPreprocessAvatarCallback
    {
        int callbackOrder { get; }
        bool OnPreprocessAvatar(GameObject avatarGameObject);
    }
}
```

**Discovery**: VRChat SDK scans all assemblies for implementations  
**Execution**: Callbacks sorted by `callbackOrder`, then executed  
**Return value**: `true` = continue build, `false` = cancel build

### IEditorOnly Interface

**VRChat SDK interface**:
```csharp
namespace VRC.SDKBase
{
    public interface IEditorOnly { }
}
```

**Purpose**: Marks components for removal from builds  
**Stripping**: VRChat SDK removes these before upload  
**Why use it**: Prevents data components from existing at runtime

### IPreprocessCallbackBehaviour Interface

**Unity interface** (not VRChat specific):
```csharp
public interface IPreprocessCallbackBehaviour
{
    int PreprocessOrder { get; }
    bool OnPreprocess();
}
```

**Required by VRCFury** for component discovery  
**Not actually called**: VRChat SDK uses its own callback system  
**Return `true`**: Always return true from OnPreprocess()

### YUCPProgressWindow Implementation

**File**: `Editor/UI/YUCPProgressWindow.cs`

Creates centered overlay window:

```csharp
public static YUCPProgressWindow Create()
{
    var window = CreateInstance<YUCPProgressWindow>();
    
    // Center on main editor window
    Rect mainWindowRect = GetEditorMainWindowPos();
    float width = 450f;
    float height = 200f;
    float x = mainWindowRect.x + (mainWindowRect.width - width) / 2f;
    float y = mainWindowRect.y + (mainWindowRect.height - height) / 2f;
    
    window.position = new Rect(x, y, width, height);
    window.ShowPopup();
    
    return window;
}
```

**UIElements-based**: Uses ProgressBar and Label elements  
**Transparent background**: Custom style  
**YUCP branding**: Shows YUCP logo

### SerializedObject Pattern

**Why use SerializedObject?**
- Undo/Redo support
- Multi-object editing
- Prefab override support
- Proper dirty tracking

**Pattern**:
```csharp
public override void OnInspectorGUI()
{
    serializedObject.Update();  // Sync with actual object
    
    // Modify properties
    EditorGUILayout.PropertyField(serializedObject.FindProperty("myField"));
    
    serializedObject.ApplyModifiedProperties();  // Apply changes
}
```

**Don't do this**:
```csharp
// BAD - breaks undo/redo
MyComponent comp = (MyComponent)target;
comp.myField = newValue;
```

### Custom Attributes

Create custom attributes for metadata:

```csharp
[AttributeUsage(AttributeTargets.Class)]
public class MyCustomAttribute : Attribute
{
    public string Message { get; }
    
    public MyCustomAttribute(string message)
    {
        Message = message;
    }
}

// Usage
[MyCustomAttribute("This component does X")]
public class MyComponent : MonoBehaviour
{
    // ...
}

// In Editor
var attr = (MyCustomAttribute)Attribute.GetCustomAttribute(
    typeof(MyComponent),
    typeof(MyCustomAttribute)
);

if (attr != null)
{
    Debug.Log(attr.Message);
}
```

### Source Code Templates

**Example processor** included:
```
Editor/Components/Processors/MyCustomComponentProcessor.cs
```

**Example component** included:
```
Runtime/Components/Data/MyCustomComponent.cs
```

Study existing components for patterns and architecture.

## Resources

### YUCP Components Source
```
GitHub: https://github.com/yucp-club/YUCP-Components
```

### VRCFury Documentation
```
Website: https://vrcfury.com/
API: See VRCFury package source
```

### VRChat SDK Documentation
```
Docs: https://creators.vrchat.com/
SDK: Check VRChat package source
```

### Unity Documentation
```
ScriptableObject: https://docs.unity3d.com/Manual/class-ScriptableObject.html
Custom Editors: https://docs.unity3d.com/Manual/editor-CustomEditors.html
UIElements: https://docs.unity3d.com/Manual/UIElements.html
```

## Recommended Reading Order

1. **This guide** - Architecture overview
2. **Symmetric Armature source** - Simple component example
3. **Auto Body Hider source** - Complex component example
4. **Package Exporter source** - Editor tool example
5. **VRCFury API** - Integration patterns

## Community

Share your components:
- Create GitHub repository
- Add to VPM repository
- Share on VRChat Discord
- Submit to YUCP community showcase

## License

YUCP Components is MIT licensed. Your components can use any license.



