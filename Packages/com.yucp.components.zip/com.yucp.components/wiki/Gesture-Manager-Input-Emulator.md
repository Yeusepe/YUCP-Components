# Gesture Manager Input Emulator

**BETA: Map keyboard and controller inputs to Gesture Manager parameters for desktop testing.**

## Overview

The Gesture Manager Input Emulator component (`GestureManagerInputEmulator`) allows you to map keyboard keys and controller buttons to Gesture Manager parameters. This is incredibly useful for testing avatar features in Unity's Play mode without needing to be in VRChat.

### BETA Status

This component is experimental:
- Requires Game view focus for input detection (Unity limitation)
- Controller mapping may vary by controller type
- Some Input Manager buttons may need manual setup
- Scene view overlay is work-in-progress

### Key Features
- **Input mapping** - Map keyboard, controller buttons, axes, triggers, D-pad
- **Gesture Manager integration** - Works with BlackStartX Gesture Manager
- **Direct Animator mode** - Fallback when Gesture Manager unavailable
- **Runtime control** - Direct parameter manipulation during Play mode
- **Debug overlay** - Visual feedback in Game view
- **Configurable deadzones** - Controller axis tuning
- **Multiple mappings** - Unlimited input-to-parameter mappings

### Why Use This?

Testing avatar parameters in Unity is difficult:
- Manual parameter adjustment in Animator
- No keyboard control
- Controller input requires complex setup
- Tedious for iterative testing

This component provides:
- Press keys to control parameters
- Use controller naturally
- Real-time parameter feedback
- Rapid iteration during development

## Use Cases

- **Testing avatar toggles** - Press key to toggle clothing/features
- **Animation testing** - Control blend tree parameters with controller
- **OSC development** - Test parameter-driven features
- **Gesture testing** - Simulate VRChat gestures with keyboard
- **Expression testing** - Trigger facial expressions
- **Parameter debugging** - Real-time parameter control

## Quick Start

1. **Add Gesture Manager** to your avatar (BlackStartX Gesture Manager)
2. **Add component**: `Add Component → YUCP → Gesture Manager Input Emulator`
3. **Click "Add Mapping"**
4. **Configure mapping**:
   - Input Type: Keyboard
   - Click keyboard field, press a key (e.g., Space)
   - Parameter Name: (your parameter name)
   - Parameter Type: Bool
   - Active Value: 1, Inactive Value: 0
5. **Enter Play mode**
6. **Click into Game view** (important - must have focus)
7. **Press the key** - Parameter changes

[Image: Inspector showing Gesture Manager Input Emulator with one mapping configured]

## Component Settings

### Gesture Manager

#### Gesture Manager Component
**Type**: GameObject  
**Default**: Auto-detect  
**Description**: The GameObject containing the Gesture Manager component.

Leave empty for auto-detection.

#### Operation Mode
**Type**: Enum  
**Options**: AutoDetect, GestureManagerMode, AnimatorMode  
**Default**: GestureManagerMode  

- **GestureManagerMode** - Uses Vrc3Param system for parameter control (recommended)
- **AnimatorMode** - Directly controls Animator parameters
- **AutoDetect** - Automatically determines mode based on detected Gesture Manager

### General Settings

#### Enable Input Emulation
**Type**: Bool  
**Default**: true  
**Description**: Master enable/disable for input capture.

#### Debug Mode
**Type**: Bool  
**Default**: false  
**Description**: Enable debug logging and overlays.

### Input Mappings

Each mapping has these fields:

#### Mapping Name
**Type**: String  
**Description**: Friendly name for this mapping.

#### Input Type
**Type**: Enum  
**Options**: Keyboard, ControllerButton, ControllerAxis, ControllerTrigger, ControllerDpad  
**Description**: Type of input to listen for.

#### Input Configuration
Depends on Input Type:

**Keyboard**:
- Keyboard Key: Click button and press key

**Controller Button**:
- Button: A, B, X, Y, Start, Select, L/R Shoulder, L/R Stick, D-Pad

**Controller Axis**:
- Axis: Left Stick X/Y, Right Stick X/Y

**Controller Trigger**:
- Trigger: Left Trigger, Right Trigger

**Controller D-pad**:
- D-pad: Up, Down, Left, Right

#### Parameter Settings

#### Parameter Name
**Type**: String  
**Required**: Yes  
**Description**: Name of the parameter to control.

Must match parameter name in Gesture Manager or Animator.

#### Parameter Type
**Type**: Enum  
**Options**: Bool, Float, Int  
**Description**: Type of parameter.

#### Parameter Values

**For Bool/Int**:
- Active Value: Value when input is active (e.g., 1)
- Inactive Value: Value when input is inactive (e.g., 0)

**For Float**:
- Min Value: Value at minimum input (e.g., 0)
- Max Value: Value at maximum input (e.g., 1)

Axes and triggers interpolate between min/max.

#### Enabled
**Type**: Bool  
**Description**: Enable/disable this mapping without deleting it.

### Controller Settings

#### Controller Deadzone
**Type**: Float  
**Range**: 0.0 - 0.5  
**Default**: 0.1  
**Description**: Deadzone for controller axes and triggers.

Input below deadzone is treated as 0.

#### Axis Sensitivity
**Type**: Float  
**Range**: 0.1 - 5.0  
**Default**: 1.0  
**Description**: Sensitivity multiplier for controller axis inputs.

Higher = more sensitive.

## Step-by-Step Tutorial

### Tutorial: Basic Keyboard Toggle

Let's map the Space bar to toggle clothing on/off.

#### Step 1: Setup Gesture Manager
1. Add BlackStartX Gesture Manager to avatar
2. Gesture Manager must have parameters set up

[Image: Gesture Manager component in Inspector]

#### Step 2: Add Input Emulator
1. Add `Gesture Manager Input Emulator` to avatar (same GameObject or child)
2. Component auto-detects Gesture Manager

#### Step 3: Create Mapping
1. Click `Add Mapping`
2. Configure:
   ```
   Mapping Name: Toggle Jacket
   Input Type: Keyboard
   Keyboard Key: [Click and press Space]
   Parameter Name: Jacket (must match Gesture Manager parameter)
   Parameter Type: Bool
   Active Value: 1
   Inactive Value: 0
   Enabled: true
   ```

[Image: Input mapping configured for Space key]

#### Step 4: Enter Play Mode
1. Click Play button in Unity
2. **Click into Game view** (required for input)
3. Gesture Manager should activate

[Image: Play mode active with Game view focused]

#### Step 5: Test Input
1. Press Space bar
2. Console (if Debug Mode enabled):
   ```
   [GestureManagerInputHandler] Input detected: Space → Jacket = 1.0
   [GestureManagerInputHandler] Parameter set: Jacket = 1.0
   ```
3. Gesture Manager parameter "Jacket" is now 1
4. Release Space bar → Parameter returns to 0

#### Step 6: Verify in Gesture Manager
1. Check Gesture Manager UI
2. Parameter should change in real-time when you press Space

[Image: Gesture Manager showing parameter changing]

### Tutorial: Controller Axis to Float Parameter

Map left stick Y-axis to control a float parameter.

#### Step 1: Add Mapping
```
Mapping Name: Movement Speed
Input Type: ControllerAxis
Controller Axis: Left Stick Y
Parameter Name: Speed
Parameter Type: Float
Min Value: 0.0
Max Value: 1.0
Enabled: true
```

#### Step 2: Test
1. Enter Play mode, focus Game view
2. Move left stick up/down
3. "Speed" parameter interpolates 0.0 to 1.0

### Tutorial: Multiple Button Mappings

Map A/B/X/Y buttons to different gestures:

```
Mapping 1:
  Input: Controller Button → A
  Parameter: Gesture
  Type: Int
  Active: 1, Inactive: 0

Mapping 2:
  Input: Controller Button → B
  Parameter: Gesture
  Type: Int
  Active: 2, Inactive: 0

Mapping 3:
  Input: Controller Button → X
  Parameter: Gesture
  Type: Int
  Active: 3, Inactive: 0

Mapping 4:
  Input: Controller Button → Y
  Parameter: Gesture
  Type: Int
  Active: 4, Inactive: 0
```

## Advanced Features

### Gesture Manager Mode vs Animator Mode

**Gesture Manager Mode** (recommended):
- Uses ModuleVrc3 parameter system
- Proper Gesture Manager integration
- Handles parameter syncing
- Recommended when Gesture Manager available

**Animator Mode**:
- Direct Animator.SetFloat/SetBool/SetInteger
- Bypass Gesture Manager
- Use when Gesture Manager not available
- Simpler but less integrated

### Debug Overlay

When Debug Mode is enabled:

**Game View Overlay**:
- Shows active mappings
- Parameter values in real-time
- Input events
- Connection status

**Controls**:
- `Force Show Debug Overlay` - Show even without input
- `Force Enable Debug Mode` - Enable debugging at runtime
- `Hide Debug Overlay` - Hide overlay

**Scene View Overlay**:
- Also shows in Scene view when `Show In Scene View` enabled
- Useful for multi-window workflows

### Controller Button Mapping

The component uses plug-and-play button mapping:

```csharp
private int GetJoystickButtonIndex(string buttonName)
{
    switch (buttonName)
    {
        case "A": return 0;
        case "B": return 1;
        case "X": return 2;
        case "Y": return 3;
        case "Left Shoulder": return 4;
        case "Right Shoulder": return 5;
        case "Select": return 6;
        case "Start": return 7;
        case "Left Stick": return 8;
        case "Right Stick": return 9;
        default: return -1;
    }
}
```

**Fallback system**:
If Input Manager button not configured, falls back to direct joystick access:
```csharp
KeyCode joystickKey = (KeyCode)((int)KeyCode.Joystick1Button0 + buttonIndex);
return Input.GetKey(joystickKey) ? 1f : 0f;
```

### Controller Axis Mapping

```csharp
private string MapToStandardAxis(string axisName)
{
    switch (axisName)
    {
        case "Left Stick X": return "Horizontal";
        case "Left Stick Y": return "Vertical";
        case "Right Stick X": return "Mouse X";  // Fallback
        case "Right Stick Y": return "Mouse Y";  // Fallback
        default: return axisName;
    }
}
```

**With deadzone and sensitivity**:
```csharp
float rawValue = Input.GetAxis(axisName);

if (Mathf.Abs(rawValue) < controllerDeadzone)
    rawValue = 0f;

rawValue *= axisSensitivity;
rawValue = Mathf.Clamp(rawValue, -1f, 1f);
```

### Parameter Value Conversion

```csharp
private float ConvertInputToParameterValue(RuntimeInputMapping mapping, float inputValue)
{
    switch (mapping.parameterType)
    {
        case ParameterType.Bool:
            return inputValue > 0.5f ? mapping.activeValue : mapping.inactiveValue;
        
        case ParameterType.Float:
            // Normalize input [0,1] or [-1,1] to [min, max]
            float normalized = (inputValue + 1f) / 2f;  // [-1,1] → [0,1]
            return Mathf.Lerp(mapping.minValue, mapping.maxValue, normalized);
        
        case ParameterType.Int:
            return inputValue > 0.5f ? mapping.activeValue : mapping.inactiveValue;
    }
}
```

## Troubleshooting

### Input Not Detected

**Problem**: Pressing keys/buttons doesn't change parameters.

**Solutions**:
1. **Click into Game view** - Input requires Game view focus
2. Check `Enable Input Emulation` is true
3. Verify Play mode is active
4. Enable `Debug Mode` to see input events in Console

### Controller Not Working

**Problem**: Controller buttons/axes not responding.

**Solutions**:
1. Check controller is connected (Controller Settings shows status)
2. Try different button mappings
3. Check Input Manager has buttons configured
4. Enable Debug Mode to see what's being detected

### Parameter Not Changing

**Problem**: Input detected but parameter doesn't change.

**Solutions**:
1. Check parameter name matches exactly (case-sensitive)
2. Verify Gesture Manager is active
3. Check Gesture Manager has the parameter
4. Try Animator Mode instead of Gesture Manager Mode
5. Review Console for error messages

### "Must be clicked into Game view"

**Problem**: Notice says Game view focus required.

**Explanation**: Unity's Input system requires the Game view to have focus to capture input events. This is a Unity limitation.

**Workaround**: Keep Game view visible and clicked while testing.

## FAQ

### Q: Why do I need to click into Game view?
**A**: Unity's Input API only captures input when Game view has focus. This is a Unity engine limitation.

### Q: Can I use this in VRChat?
**A**: This is a Unity editor testing tool only. It does NOT affect the uploaded avatar. Use it for testing parameters during development.

### Q: Does this work with OSC?
**A**: This is for Unity testing only. For OSC control in VRChat, use VRChat's OSC system.

### Q: Can I map multiple keys to the same parameter?
**A**: Yes! Create multiple mappings with the same parameter name but different inputs.

### Q: What controllers are supported?
**A**: Any XInput-compatible controller (Xbox, PlayStation, most PC controllers). Mappings are plug-and-play.

### Q: Can I save my input mappings?
**A**: Yes, mappings are saved with the component. They persist across Unity sessions.

## Examples

### Example 1: Keyboard Toggle
```
Input Type: Keyboard
Keyboard Key: Space
Parameter Name: JacketToggle
Parameter Type: Bool
Active Value: 1
Inactive Value: 0
```

### Example 2: Controller Trigger to Float
```
Input Type: ControllerTrigger
Controller Trigger: Right Trigger
Parameter Name: GripStrength
Parameter Type: Float
Min Value: 0.0
Max Value: 1.0
```

### Example 3: D-Pad to Int (Menu Navigation)
```
Input Type: ControllerDpad
Controller Dpad: D-Pad Up
Parameter Name: MenuSelection
Parameter Type: Int
Active Value: 1
Inactive Value: 0
```

## For the Nerds

### Technical Architecture

**Component**: `Runtime/Components/Data/GestureManagerInputEmulator.cs`  
**Runtime Handler**: `Runtime/Components/Data/GestureManagerInputHandler.cs`  
**Processor**: `Editor/Components/Processors/GestureManagerInputEmulatorProcessor.cs`  
**Inspector**: `Editor/Header/GestureManagerInputEmulatorEditor.cs`

### Runtime Input Handling

The processor creates a runtime handler during build:

```csharp
var inputHandler = data.gameObject.AddComponent<GestureManagerInputHandler>();

inputHandler.enableInputCapture = data.enableInputEmulation;
inputHandler.debugMode = data.debugMode;
inputHandler.controllerDeadzone = data.controllerDeadzone;
inputHandler.axisSensitivity = data.axisSensitivity;
inputHandler.gestureManagerMode = detectedMode;

foreach (var mapping in activeMappings)
{
    inputHandler.AddRuntimeMapping(mapping);
}
```

### Input Processing Loop

```csharp
private void Update()
{
    if (!enableInputCapture || !Application.isPlaying)
        return;
    
    ProcessInputMappings();
}

private void ProcessInputMappings()
{
    foreach (var mapping in runtimeMappings)
    {
        if (!mapping.enabled) continue;
        
        float inputValue = GetInputValue(mapping);
        SendParameterValue(mapping, inputValue);
    }
}
```

### Gesture Manager Parameter Control

```csharp
private void SendGestureManagerParameter(RuntimeInputMapping mapping, float inputValue)
{
    if (gestureManager == null)
    {
        gestureManager = FindGestureManager();
        if (gestureManager == null) return;
    }
    
    // Access ModuleVrc3 via reflection
    if (moduleVrc3 == null)
    {
        var moduleField = gestureManager.GetType()
            .GetField("module", BindingFlags.Public | BindingFlags.Instance);
        moduleVrc3 = moduleField?.GetValue(gestureManager);
    }
    
    if (moduleVrc3 != null)
    {
        // Set parameter via Vrc3Param system
        var setMethod = moduleVrc3.GetType().GetMethod("SetParameter");
        setMethod?.Invoke(moduleVrc3, new object[] { mapping.parameterName, paramValue });
    }
}
```

Uses reflection to access internal Gesture Manager API.

### Controller Input Fallback System

```csharp
private float GetControllerButtonValue(string buttonName)
{
    try
    {
        // Try Input Manager button first
        string standardButton = MapToStandardButton(buttonName);
        if (Input.GetButton(standardButton))
            return 1f;
    }
    catch (ArgumentException)
    {
        // Button not in Input Manager - use fallback
    }
    
    // Fallback: Direct joystick KeyCode access
    int buttonIndex = GetJoystickButtonIndex(buttonName);
    if (buttonIndex >= 0)
    {
        KeyCode joystickKey = (KeyCode)((int)KeyCode.Joystick1Button0 + buttonIndex);
        return Input.GetKey(joystickKey) ? 1f : 0f;
    }
    
    return 0f;
}
```

Gracefully handles unconfigured Input Manager buttons.

### Debug Overlay Rendering

```csharp
private void OnGUI()
{
    if (!showDebugOverlay || !debugMode) return;
    
    float width = 350f;
    float height = GetContentHeight();
    Rect position = new Rect(10, 10, width, height);
    
    GUI.Box(position, "");
    GUILayout.BeginArea(position);
    
    // Header
    GUILayout.Label("Gesture Manager Input Emulator", headerStyle);
    
    // Status
    DrawStatusSection();
    
    // Active mappings with current values
    foreach (var mapping in runtimeMappings)
    {
        GUILayout.Label($"{mapping.parameterName}: {inputValues[mapping.parameterName]}");
    }
    
    GUILayout.EndArea();
}
```

### Source Code Reference

**Runtime Component**: `Runtime/Components/Data/GestureManagerInputEmulator.cs` (130 lines)  
**Runtime Handler**: `Runtime/Components/Data/GestureManagerInputHandler.cs` (886 lines)  
**Processor**: `Editor/Components/Processors/GestureManagerInputEmulatorProcessor.cs` (265 lines)  
**Inspector**: `Editor/Header/GestureManagerInputEmulatorEditor.cs` (689 lines)  
**Scene View**: `Editor/Header/GestureManagerInputHandlerSceneView.cs` (222 lines)

### Performance

**Input polling**: Every frame in Update()  
**Parameter setting**: Every frame when input changes  
**Memory**: ~100 bytes per mapping  
**CPU**: Negligible (<0.1ms per frame)

### Input Manager Dependency

Some controller inputs require Input Manager configuration. The component handles missing entries gracefully by falling back to direct KeyCode access.

**To configure Input Manager** (optional):
1. Edit → Project Settings → Input Manager
2. Add axes/buttons for controller inputs
3. Component will use them if available



