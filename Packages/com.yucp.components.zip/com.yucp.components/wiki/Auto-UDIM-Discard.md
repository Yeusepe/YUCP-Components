# Auto UDIM Discard

**BETA: Automatically detect UV regions on clothing and create corresponding UDIM discard toggles.**

## Overview

The Auto UDIM Discard component (`AutoUDIMDiscardData`) analyzes the UV layout of a clothing mesh to automatically detect separate UV islands/regions, then creates individual UDIM discard toggles for each region. This is useful for multi-part clothing where different regions should be toggleable independently (e.g., jacket sleeves, hood, body).

### BETA Status

This component is experimental:
- UV region detection may need manual adjustment
- Tile assignment may need manual override
- Best suited for clothing with clearly separated UV islands
- May require manual merging of regions

### Key Features
- **Automatic UV region detection** - Clusters vertices by UV proximity
- **Multi-region toggles** - Separate toggle for each detected region
- **UDIM tile assignment** - Assigns consecutive tiles to regions
- **Poiyomi/FastFur support** - Works with both shader systems
- **Master toggle option** - Group all regions under one menu path
- **Parameter driver mode** - Create synced parameters instead of toggles
- **Preview system** - Visualize detected regions before building

### Why Use This?

Manual multi-region setup requires:
- Manually identifying UV regions
- Creating separate UDIM configurations for each
- Setting up multiple toggles
- Managing tile assignments

Auto UDIM Discard automates this:
- Detects regions automatically
- Creates all toggles
- Manages tiles
- Configures materials

## Use Cases

- **Jackets with toggleable parts** - Sleeves, hood, collar
- **Multi-piece clothing** - Separate top/bottom toggles
- **Modular outfits** - Mix and match parts
- **Complex costumes** - Many toggleable elements
- **Layered clothing** - Different layers as regions

## Quick Start

1. **Prepare clothing** with well-separated UV islands
2. **Add component** to clothing: `Add Component → YUCP → Auto UDIM Discard`
3. **Assign body mesh**: Drag body SkinnedMeshRenderer to `Target Body Mesh`
4. **Generate preview**: Click `Generate Preview`
5. **Review regions**: Check detected region count
6. **Configure toggles**: Set menu path prefix
7. **Build avatar**

[Image: Inspector showing Auto UDIM Discard component]

## Component Settings

### Target Body

#### Target Body Mesh
**Type**: SkinnedMeshRenderer  
**Required**: Yes  
**Description**: The body mesh renderer that should be hidden under this clothing.

### Detection Settings

#### UV Channel
**Type**: Int  
**Default**: 0  
**Description**: Which UV channel to analyze for region detection.

Usually UV0 (texture UVs).

#### Merge Tolerance
**Type**: Float  
**Default**: 0.01  
**Description**: Merge UV islands that are closer than this distance.

Higher values merge more regions together.

#### Min Region Size %
**Type**: Float  
**Default**: 1.0  
**Range**: 0.1 - 100.0  
**Description**: Minimum percentage of mesh that a region must cover to be included.

Filters out small UV islands (buttons, zippers, etc.).

### UDIM Tile Assignment

#### Start Row
**Type**: Int  
**Range**: 0 - 3  
**Default**: 1  
**Description**: Starting row for tile assignment.

#### Start Column
**Type**: Int  
**Range**: 0 - 3  
**Default**: 0  
**Description**: Starting column for tile assignment.

**Regions assigned consecutively**:
```
Region 1: (1, 0)
Region 2: (1, 1)
Region 3: (1, 2)
Region 4: (1, 3)
Region 5: (2, 0)  ← Wraps to next row
...
```

### Toggle Settings

#### Create Toggles
**Type**: Bool  
**Default**: true  
**Description**: Create individual toggles for each detected region.

#### Menu Path Prefix
**Type**: String  
**Default**: "Clothing/Body Parts"  
**Description**: Prefix for toggle menu paths.

Each region gets: `{Prefix}/Region 1`, `{Prefix}/Region 2`, etc.

#### Saved
**Type**: Bool  
**Default**: true  
**Description**: Save toggle states across avatar reloads.

#### Use Master Toggle
**Type**: Bool  
**Default**: false  
**Description**: Group all region toggles under a single master toggle path.

#### Master Toggle Path
**Type**: String  
**Default**: "Clothing/Hide All Body"  
**Description**: Menu path for master toggle.

#### Use Parameter Driver
**Type**: Bool  
**Default**: false  
**Description**: Create parameter drivers instead of menu toggles.

#### Parameter Base Name
**Type**: String  
**Default**: "BodyHide"  
**Description**: Base name for parameter drivers.

Each region: `{Base}_1`, `{Base}_2`, etc.

### Advanced Options

#### Show Preview / Use Color Coding
**Type**: Bool  
**Description**: Preview regions / Use colors for region visualization.

## Step-by-Step Tutorial

### Tutorial: Jacket with Toggleable Sleeves and Hood

Let's set up a jacket where the sleeves and hood can be toggled separately.

#### Step 1: Prepare UV Layout
1. Your jacket mesh should have UV islands:
   - Body UV island
   - Left sleeve UV island
   - Right sleeve UV island
   - Hood UV island

[Image: UV layout showing separated islands in UV editor]

#### Step 2: Add Component
1. Select jacket GameObject
2. `Add Component → YUCP → Auto UDIM Discard`
3. Component requires SkinnedMeshRenderer on same GameObject

#### Step 3: Assign Body Mesh
1. Drag avatar body SkinnedMeshRenderer to `Target Body Mesh`
2. This is the mesh that will be hidden under each clothing region

[Image: Inspector with Target Body Mesh assigned]

#### Step 4: Configure Detection
```
UV Channel: 0 (texture UVs)
Merge Tolerance: 0.01 (default)
Min Region Size: 2.0 (each region must be at least 2% of mesh)
```

**Min Region Size** filters out tiny UV islands like buttons or seams.

#### Step 5: Generate Preview
1. Click `Generate Preview`
2. Component analyzes UV layout
3. Console shows: `Detected 4 UV regions`
4. Info box shows region counts and tile assignments

[Image: Inspector showing preview results with 4 detected regions]

#### Step 6: Review Detected Regions
```
Detected 4 UV regions:
Region 1: 450 vertices → UDIM (1, 0)
Region 2: 380 vertices → UDIM (1, 1)
Region 3: 370 vertices → UDIM (1, 2)
Region 4: 280 vertices → UDIM (1, 3)
```

If regions are incorrect:
- Adjust `Merge Tolerance` to combine close regions
- Adjust `Min Region Size` to filter small regions
- Fix UV layout in 3D software if needed

#### Step 7: Configure Toggles
```
Create Toggles: true
Menu Path Prefix: Clothing/Jacket
Saved: true
Use Master Toggle: false
```

Result: Four toggles created:
- Clothing/Jacket/Region 1
- Clothing/Jacket/Region 2
- Clothing/Jacket/Region 3
- Clothing/Jacket/Region 4

[Image: Inspector showing toggle configuration]

#### Step 8: Build Avatar
1. `VRChat SDK → Build & Publish`
2. Component creates:
   - UDIM discards for each region
   - Material configuration
   - VRCFury toggles

3. In-game, you can toggle each region independently

[Image: VRChat menu showing four region toggles]

## Advanced Features

### Master Toggle Mode

When enabled, all regions are grouped under one path:

```
Use Master Toggle: true
Master Toggle Path: Clothing/Jacket

Result:
- Clothing/Jacket/Region 1
- Clothing/Jacket/Region 2
- Clothing/Jacket/Region 3
- Clothing/Jacket/Region 4
```

Creates a submenu structure.

### Parameter Driver Mode

Instead of menu toggles, create synced parameters:

```
Use Parameter Driver: true
Parameter Base Name: JacketPart

Result:
- JacketPart_1 (bool parameter)
- JacketPart_2 (bool parameter)
- JacketPart_3 (bool parameter)
- JacketPart_4 (bool parameter)
```

Useful for linking to other systems or OSC control.

### Custom Tile Assignment

```
Start Row: 2
Start Column: 1

Regions assigned:
Region 1: (2, 1)
Region 2: (2, 2)
Region 3: (2, 3)
Region 4: (3, 0)
```

### UV Clustering Algorithm

```csharp
private List<List<int>> ClusterVerticesByUV(Vector2[] uvs, float tolerance)
{
    List<List<int>> clusters = new List<List<int>>();
    bool[] assigned = new bool[uvs.Length];
    
    for (int i = 0; i < uvs.Length; i++)
    {
        if (assigned[i]) continue;
        
        // Start new cluster (flood fill)
        List<int> cluster = new List<int>();
        Queue<int> toProcess = new Queue<int>();
        toProcess.Enqueue(i);
        assigned[i] = true;
        
        while (toProcess.Count > 0)
        {
            int current = toProcess.Dequeue();
            cluster.Add(current);
            
            // Find nearby vertices in UV space
            for (int j = 0; j < uvs.Length; j++)
            {
                if (assigned[j]) continue;
                
                float distance = Vector2.Distance(uvs[current], uvs[j]);
                if (distance <= tolerance)
                {
                    assigned[j] = true;
                    toProcess.Enqueue(j);
                }
            }
        }
        
        clusters.Add(cluster);
    }
    
    return clusters;
}
```

**Algorithm**: Flood-fill clustering in UV space  
**Time complexity**: O(n²) worst case, O(n log n) typical  
**Tolerance**: UV distance (0.01 = 1% of UV space)

### Region Sorting

```csharp
// Sort regions by UV center (top to bottom, left to right)
regions = regions.OrderByDescending(r => r.uvCenter.y)
                 .ThenBy(r => r.uvCenter.x)
                 .ToList();
```

**Ensures consistent region ordering** between builds.

## Troubleshooting

### Too Many Regions Detected

**Problem**: Component detects more regions than expected.

**Solutions**:
1. Increase `Merge Tolerance` to combine close regions
2. Increase `Min Region Size` to filter small islands
3. Clean up UV layout (merge UV islands in 3D software)

### Too Few Regions Detected

**Problem**: Multiple UV islands detected as one region.

**Solutions**:
1. Decrease `Merge Tolerance`
2. Ensure UV islands are actually separated in UV space
3. Check UV layout in 3D software

### No Regions Detected

**Problem**: Component finds 0 regions.

**Causes**:
1. UV channel is empty
2. Min Region Size is too high
3. Mesh has no UVs on selected channel

**Solutions**:
1. Check `UV Channel` is correct (usually 0)
2. Lower `Min Region Size` to minimum (0.1%)
3. Verify mesh has UVs in 3D software

### Toggles Not Working

**Problem**: Toggles exist but don't hide body.

**Solutions**:
1. Ensure body mesh has Poiyomi or FastFur shader
2. Check UDIM tiles are correctly assigned
3. Review Console for material configuration errors

## FAQ

### Q: What's the difference between this and Auto Body Hider?
**A**: Auto Body Hider detects hidden BODY vertices. Auto UDIM Discard detects CLOTHING UV regions. Different purposes.

### Q: Can I use this with Auto Body Hider?
**A**: Technically yes, but usually you'd use one or the other. Auto Body Hider is more common.

### Q: How do I name the regions?
**A**: Regions are auto-named "Region 1", "Region 2", etc. Manual renaming not currently supported.

### Q: Can I merge specific regions manually?
**A**: Adjust `Merge Tolerance` and positioning. For precise control, use multiple separate components or manual UDIM setup.

### Q: What if I run out of UDIM tiles?
**A**: Maximum 16 tiles (4x4 grid). Limit the number of regions or merge some in your UV layout.

## Examples

### Example 1: Simple Three-Part Outfit
```
Clothing: Dress with body, sleeves, skirt as UV islands
Settings:
- UV Channel: 0
- Merge Tolerance: 0.01
- Min Region Size: 3.0
- Start Row: 1, Col: 0
- Create Toggles: true
- Menu Path: Clothing/Dress

Result: 3 toggles for body, sleeves, skirt
```

### Example 2: Complex Jacket (Master Toggle)
```
Clothing: Jacket with 6 UV regions
Settings:
- Merge Tolerance: 0.02 (combine close regions)
- Min Region Size: 2.0
- Use Master Toggle: true
- Master Path: Clothing/Jacket Parts

Result: Submenu with 6 region toggles
```

## For the Nerds

### Technical Architecture

**Component**: `Runtime/Components/Data/AutoUDIMDiscardData.cs`  
**Processor**: `Editor/Components/Processors/AutoUDIMDiscardProcessor.cs`  
**Editor**: `Editor/Components/Header/AutoUDIMDiscardDataEditor.cs`

### Processing Pipeline

```
Build Starts
    ↓
AutoUDIMDiscardProcessor (callbackOrder: int.MinValue + 101)
    ↓ Get clothing mesh UV data
    ↓ Cluster vertices by UV proximity
    ↓ Filter clusters by min size
    ↓ Sort regions by UV position
    ↓ Assign UDIM tiles
    ↓ For each region:
        ↓ Apply UDIM discard to body mesh
        ↓ Configure material for tile
        ↓ Create toggle (if enabled)
```

### UV Bounds Calculation

```csharp
// For each cluster of vertices
Vector2 min = new Vector2(float.MaxValue, float.MaxValue);
Vector2 max = new Vector2(float.MinValue, float.MinValue);

foreach (int vertexIdx in cluster)
{
    Vector2 uv = uvs[vertexIdx];
    min = Vector2.Min(min, uv);
    max = Vector2.Max(max, uv);
}

region.uvBounds = new Bounds(
    new Vector3((min.x + max.x) / 2f, (min.y + max.y) / 2f, 0),
    new Vector3(max.x - min.x, max.y - min.y, 0)
);

region.uvCenter = new Vector2((min.x + max.x) / 2f, (min.y + max.y) / 2f);
```

### Region Sorting Logic

```csharp
regions = regions.OrderByDescending(r => r.uvCenter.y)  // Top to bottom
                 .ThenBy(r => r.uvCenter.x)              // Left to right
                 .ToList();
```

**Ensures deterministic ordering** for consistent toggle assignment.

### Toggle Creation Per Region

```csharp
for (int i = 0; i < regions.Count; i++)
{
    var region = regions[i];
    region.name = $"Region {i + 1}";
    
    string togglePath = data.useMasterToggle 
        ? data.masterTogglePath 
        : $"{data.toggleMenuPath}/{region.name}";
    
    CreateRegionToggle(data, poiyomiMaterial, region, togglePath, i);
}
```

### Material Configuration

```csharp
private void ConfigurePoiyomiMaterial(Material material, int row, int column)
{
    material.SetFloat("_EnableUDIMDiscardOptions", 1f);
    
    if (shaderName.Contains("poiyomi"))
    {
        material.EnableKeyword("POI_UDIMDISCARD");
    }
    else if (shaderName.Contains("fastfur"))
    {
        material.EnableKeyword("WFFS_FEATURES_UVDISCARD");
        material.SetFloat("_WFFS_FEATURES_UVDISCARD", 1f);
    }
    
    material.SetFloat("_UDIMDiscardMode", 0f);  // Vertex mode
    material.SetFloat("_UDIMDiscardUV", 1);     // UV1
    
    string tileProperty = $"_UDIMDiscardRow{row}_{column}";
    material.SetFloat(tileProperty, 0f);  // Base = OFF
    material.SetOverrideTag(tileProperty + "Animated", "1");
}
```

### Source Code Reference

**Runtime**: `Runtime/Components/Data/AutoUDIMDiscardData.cs` (112 lines)  
**Processor**: `Editor/Components/Processors/AutoUDIMDiscardProcessor.cs` (451 lines)  
**Editor**: `Editor/Components/Header/AutoUDIMDiscardDataEditor.cs` (319 lines)

### Performance

**UV Analysis**: O(n²) clustering  
**Build time**: ~100-500ms depending on vertex count  
**Runtime**: UDIM discard (GPU shader evaluation)



