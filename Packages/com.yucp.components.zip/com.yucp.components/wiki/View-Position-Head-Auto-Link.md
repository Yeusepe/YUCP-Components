# View Position & Head Auto-Link

**Automatically position objects at avatar view position (eye level) and link them to the head bone.**

## Overview

The View Position & Head Auto-Link component (`AttachToViewPositionData`) positions objects at your avatar's view position (where your eyes are in VR) and creates an armature link to the head bone. This is perfect for HUD elements, glasses, masks, and any accessories that should be positioned relative to where the player sees from.

### Key Features
- **View position placement** - Automatically positions at avatar's ViewPosition
- **Eye alignment** - Optionally align Z-depth to left or right eye
- **Head bone linking** - Links to head bone so object follows head movement
- **Offset support** - Fine-tune position with local-space offset
- **Baked transforms** - Position is baked at build time, no runtime calculation
- **Zero runtime overhead** - Converts to VRCFury armature link

### Why Use This?

This component solves the problem of positioning accessories at eye level:
- ViewPosition is set in the VRC Avatar Descriptor
- Manually positioning objects at the exact ViewPosition is tedious
- Eye alignment helps with stereo-correct positioning
- Head linking ensures the object moves with your head in VR

## Use Cases

- **Glasses/Goggles** - Positioned at eye level, aligned to eyes
- **Masks** - Face masks, gas masks, VR headsets
- **HUD elements** - Floating UI, status displays
- **Monocles** - Aligned to specific eye
- **Headlamps** - Positioned at forehead level
- **Face shields** - Positioned in front of face
- **Cigarettes/pipes** - Mouth-level accessories (with offset)
- **Scopes/Sights** - Aligned to dominant eye

## Quick Start

1. **Add your accessory** to the avatar hierarchy (position doesn't matter - it will be moved)
2. **Add component**: `Add Component → YUCP → View Position & Head Auto-Link`
3. **Configure**:
   - Set `Eye Alignment` if needed (None, LeftEye, RightEye)
   - Adjust `Offset` to fine-tune position
4. **Build avatar** - Component moves object to view position and links to head

[Image: Unity Inspector showing View Position & Head Auto-Link component]

## Component Settings

### Settings

#### Offset
**Type**: Vector3  
**Default**: `(0, 0, 0)`  
**Units**: Meters (local space)  
**Description**: Offset from the avatar's ViewPosition in local space.

**Local space axes** (avatar-relative):
- **X**: Right (+) / Left (-)
- **Y**: Up (+) / Down (-)
- **Z**: Forward (+) / Back (-)

**Examples**:
```
(0, 0, 0)      → Exactly at view position (eye level)
(0, 0, 0.1)    → 10cm in front of eyes
(0, -0.05, 0)  → 5cm below eyes (mouth level)
(0.05, 0, 0)   → 5cm to the right
(-0.02, 0.01, 0.05) → Custom offset (2cm left, 1cm up, 5cm forward)
```

**Tooltip**: "Offset from the avatar's ViewPosition in local space."

#### Eye Alignment
**Type**: Dropdown enum (None, LeftEye, RightEye)  
**Default**: `None`  
**Description**: Optionally align the Z-axis (forward/back depth) to a specific eye bone.

- **None** - Use ViewPosition Z as-is (centered between eyes)
- **LeftEye** - Set Z to left eye's Z position (for left eye alignment)
- **RightEye** - Set Z to right eye's Z position (for right eye alignment)

**Use cases**:
- **Monocle**: Align to LeftEye or RightEye for correct eye
- **Stereoscopic displays**: Align to specific eye
- **Asymmetric accessories**: Align to one side

**Tooltip**: "Optionally align the X-axis toward a specific eye bone."

> **Note**: Eye alignment only affects the Z-axis (depth). X and Y still use ViewPosition + Offset.

## Step-by-Step Tutorial

### Example: Adding Glasses

Let's add glasses that perfectly align with the avatar's eyes.

#### Step 1: Import the Glasses Model
1. Import your glasses 3D model into Unity
2. Add it to your avatar hierarchy
3. **Don't worry about position** - the component will move it

[Image: Glasses model anywhere in the scene, not positioned correctly yet]

#### Step 2: Add the Component
1. Select the glasses GameObject
2. `Add Component → YUCP → View Position & Head Auto-Link`

[Image: Add Component menu showing YUCP components]

#### Step 3: Configure Settings
For glasses, we typically want:
1. Set `Eye Alignment` to **"None"** (centered between eyes)
2. Set `Offset` to **`(0, 0, 0.05)`** (5cm in front of eyes)
   - Adjust Z value if glasses should be closer/further
3. Leave other settings as default

[Image: Inspector showing configured settings with offset values]

#### Step 4: Fine-Tune Position
The offset is applied in avatar local space:

**If glasses are too high/low**:
- Adjust `Offset Y` value
- Positive = up, Negative = down

**If glasses are too far/close**:
- Adjust `Offset Z` value  
- Positive = forward, Negative = back

**If glasses need to shift left/right**:
- Adjust `Offset X` value
- Positive = right, Negative = left

[Image: Scene view showing glasses repositioned at view position with offset visualization]

#### Step 5: Build and Test
1. Build your avatar
2. During build, the component will:
   - Read ViewPosition from VRC_AvatarDescriptor
   - Apply eye alignment if set
   - Add offset
   - Move glasses to calculated position
   - Create armature link to head bone

3. Check Console log:
   ```
   Moved 'Glasses' to world position (0.045, 1.624, 0.082)
   Linked 'Glasses' to Head bone with baked offset
   ```

[Image: Avatar in VRChat with glasses properly positioned]

### Example: Monocle (Eye-Aligned)

A monocle should align to one specific eye, not centered.

#### Step 1: Setup
1. Import monocle model
2. Add `View Position & Head Auto-Link` component

#### Step 2: Configure for Right Eye
```
Settings:
- Eye Alignment: RightEye
- Offset: (0.02, 0, 0.04)
  - 2cm to the right (monocle offset)
  - 4cm in front (distance from eye)
```

**What happens**:
1. ViewPosition X, Y are used
2. Z is replaced with RightEye bone's Z position
3. Offset is applied
4. Monocle positions at right eye level

[Image: Monocle positioned on right eye using eye alignment]

### Example: Face Mask

A face mask that covers the mouth and nose area.

#### Step 1: Setup
1. Import mask model
2. Add component

#### Step 2: Configure for Face Coverage
```
Settings:
- Eye Alignment: None
- Offset: (0, -0.04, 0.08)
  - 0cm horizontal (centered)
  - -4cm vertical (below eyes, at nose/mouth level)
  - 8cm forward (in front of face)
```

[Image: Face mask positioned covering lower face]

## Advanced Features

### Understanding View Position

**What is ViewPosition?**
- Set in `VRC_AvatarDescriptor` component
- Defines where your viewpoint is in VR
- Typically positioned between the eyes
- In local space relative to avatar root

**ViewPosition in VRC_AvatarDescriptor**:
[Image: VRC Avatar Descriptor showing ViewPosition field with blue sphere gizmo]

**The component reads this value**:
```csharp
var desc = GetComponentInParent<VRC_AvatarDescriptor>();
Vector3 localTarget = desc.ViewPosition;
```

### Eye Alignment Math

When eye alignment is enabled:

```csharp
if (data.eyeAlignment != EyeAlignment.None)
{
    var animator = desc.GetComponent<Animator>();
    var bone = (data.eyeAlignment == EyeAlignment.LeftEye)
        ? HumanBodyBones.LeftEye
        : HumanBodyBones.RightEye;
    
    var eyeTransform = animator.GetBoneTransform(bone);
    if (eyeTransform != null)
    {
        // Get eye position in local space
        Vector3 eyeLocal = desc.transform.InverseTransformPoint(eyeTransform.position);
        
        // Replace Z component only
        localTarget.z = eyeLocal.z;
    }
}
```

**Result**:
```
ViewPosition = (0, 1.6, 0.1)
LeftEye bone local pos = (-0.03, 1.62, 0.12)
RightEye bone local pos = (0.03, 1.62, 0.12)

With Eye Alignment = LeftEye:
  localTarget = (0, 1.6, 0.12)  ← Z from left eye
  
With Eye Alignment = None:
  localTarget = (0, 1.6, 0.1)   ← Z from ViewPosition
```

### Offset Application

Offset is added in local space BEFORE world space conversion:

```csharp
localTarget += data.offset;
Vector3 worldTarget = desc.transform.TransformPoint(localTarget);
data.transform.position = worldTarget;
```

**Coordinate space sequence**:
```
1. ViewPosition (avatar local space)
2. + Eye alignment Z adjustment (if enabled)
3. + Offset (avatar local space)
4. → World space conversion
5. → Set object position
```

**Example calculation**:
```
Avatar transform:
  Position: (0, 0, 0)
  Rotation: (0, 45°, 0) - rotated 45° around Y
  
ViewPosition: (0, 1.6, 0.1)
Offset: (0, 0, 0.05)

Local target: (0, 1.6, 0.15)
World target: Affected by avatar's 45° rotation
```

### Transform Baking

The component sets the world position, then VRCFury bakes the offset:

```csharp
// Component sets world position
data.transform.position = worldTarget;

// VRCFury armature link is created
var link = FuryComponents.CreateArmatureLink(data.gameObject);
link.LinkTo(HumanBodyBones.Head);

// VRCFury calculates the offset from head bone to object position
// This offset is baked into the armature link
```

**Result**: Object maintains its position relative to head bone in VR, even if avatar transforms change.

### VRC_AvatarDescriptor Dependency

The component requires a valid `VRC_AvatarDescriptor`:

```csharp
var desc = data.GetComponentInParent<VRC_AvatarDescriptor>();
if (desc == null)
{
    Debug.LogError($"No VRC_AvatarDescriptor found for '{data.name}'", data);
    continue;
}
```

**Search method**:
- Uses `GetComponentInParent<>()` - searches up the hierarchy
- Typically finds the descriptor on the avatar root
- If not found, processing fails for that component

## Troubleshooting

### "No VRC_AvatarDescriptor found"

**Problem**: Component can't find the avatar descriptor.

**Causes**:
1. Component is not on an object inside the avatar hierarchy
2. VRC_AvatarDescriptor is missing
3. Component is on the root object that HAS the descriptor (parent search doesn't include self)

**Solutions**:
1. Ensure component is on a child object of the avatar (not on avatar root)
2. Add VRC_AvatarDescriptor to avatar root
3. Move component to a child GameObject

### Object Positioned Incorrectly

**Problem**: Object appears at wrong position after build.

**Solutions**:
1. **Check ViewPosition**: Verify ViewPosition is set correctly in VRC_AvatarDescriptor
2. **Adjust offset**: Tweak X, Y, Z offset values
3. **Check avatar rotation**: If avatar is rotated, offset is affected by rotation
4. **Reset object position**: Component sets position at build, local position before build doesn't matter

### Eye Alignment Not Working

**Problem**: Eye alignment setting has no effect.

**Causes**:
1. Avatar doesn't have eye bones defined
2. Animator is missing
3. Eye bones are at the same Z depth as ViewPosition

**Solutions**:
1. Check avatar has LeftEye and RightEye bones in humanoid rig
2. Verify Animator component exists on avatar
3. Use larger offset to see the effect more clearly

### Object Not Following Head

**Problem**: After upload, object doesn't move with head.

**Causes**:
1. VRCFury didn't process correctly
2. Head bone not found
3. Armature link not created

**Solutions**:
1. Check Console for VRCFury errors during build
2. Verify Animator has valid humanoid rig
3. Rebuild avatar from scratch

## FAQ

### Q: What if my avatar doesn't have eye bones?
**A**: Set `Eye Alignment` to "None". The component will use the ViewPosition as-is.

### Q: Can I use this for objects that shouldn't follow the head?
**A**: No. This component always creates a head bone link. For static world-space objects, don't use this component.

### Q: How do I position objects at mouth level?
**A**: Use a negative Y offset. For example: `Offset = (0, -0.08, 0.05)` (8cm below eyes, 5cm forward).

### Q: Does this work with Desktop mode?
**A**: Yes! ViewPosition is used in both VR and Desktop modes. The object will be at eye level in both.

### Q: Can I attach multiple objects with different offsets?
**A**: Yes! Add the component to each object with different offset values.

### Q: What if ViewPosition changes after build?
**A**: The position is baked at build time. If you change ViewPosition in VRC_AvatarDescriptor, you need to rebuild the avatar.

### Q: Does rotation matter?
**A**: The component sets position only. Rotation is baked by VRCFury's armature link based on the object's rotation at build time.

### Q: Can I use this with non-humanoid avatars?
**A**: No. The component requires a humanoid avatar with a Head bone defined. For non-humanoid avatars, use Closest Bone Auto-Link instead.

## Examples

### Example 1: Simple Glasses (Centered)
```
Component Settings:
- Offset: (0, 0, 0.05)
- Eye Alignment: None

Result: Glasses positioned 5cm in front of ViewPosition, centered between eyes
```

### Example 2: Monocle (Left Eye)
```
Component Settings:
- Offset: (-0.02, 0, 0.04)
- Eye Alignment: LeftEye

Result: Monocle at left eye Z-depth, slightly left and forward
```

### Example 3: Face Mask
```
Component Settings:
- Offset: (0, -0.06, 0.07)
- Eye Alignment: None

Result: Mask 6cm below eyes, 7cm forward (covers nose/mouth)
```

### Example 4: Headlamp
```
Component Settings:
- Offset: (0, 0.05, 0.02)
- Eye Alignment: None

Result: Lamp 5cm above eyes, slightly forward (forehead)
```

### Example 5: HUD Display
```
Component Settings:
- Offset: (0.1, 0.05, 0.15)
- Eye Alignment: RightEye

Result: HUD positioned upper-right at eye level, 15cm in front
```

## For the Nerds

### Technical Architecture

The View Position & Head Auto-Link component performs coordinate space transformations and creates VRCFury armature links during build preprocessing.

#### Component Class
**File**: `Runtime/Components/Data/AttachToViewPositionData.cs`

```csharp
public enum EyeAlignment { None, LeftEye, RightEye }

public class AttachToViewPositionData : MonoBehaviour, 
    IEditorOnly, IPreprocessCallbackBehaviour
{
    public Vector3 offset = Vector3.zero;
    public EyeAlignment eyeAlignment = EyeAlignment.None;
    
    public int PreprocessOrder => 0;
    public bool OnPreprocess() => true;
}
```

**Interface implementations**:
- `IEditorOnly` - Component removed from builds (not in runtime)
- `IPreprocessCallbackBehaviour` - Marks component for preprocessing (VRCFury requirement)

#### Processor Class
**File**: `Editor/Components/Processors/AttachToViewPositionProcessor.cs`

```csharp
public class AttachToViewPositionProcessor : IVRCSDKPreprocessAvatarCallback
{
    public int callbackOrder => int.MinValue;
    
    public bool OnPreprocessAvatar(GameObject avatarRoot)
    {
        // Get VRC_AvatarDescriptor
        // Calculate target position
        // Move object to position
        // Create VRCFury head link
    }
}
```

### Position Calculation Algorithm

**Full algorithm**:

```csharp
// Step 1: Get avatar descriptor
var desc = data.GetComponentInParent<VRC_AvatarDescriptor>();
if (desc == null) return; // Error

// Step 2: Start with ViewPosition (local space)
Vector3 localTarget = desc.ViewPosition;

// Step 3: Apply eye alignment if requested
if (data.eyeAlignment != EyeAlignment.None)
{
    var animator = desc.GetComponent<Animator>();
    if (animator != null)
    {
        // Get the appropriate eye bone
        var bone = data.eyeAlignment == EyeAlignment.LeftEye
            ? HumanBodyBones.LeftEye
            : HumanBodyBones.RightEye;
        
        var eyeTransform = animator.GetBoneTransform(bone);
        if (eyeTransform != null)
        {
            // Convert eye position to avatar local space
            Vector3 eyeLocal = desc.transform.InverseTransformPoint(eyeTransform.position);
            
            // Replace ONLY the Z component
            localTarget.z = eyeLocal.z;
        }
    }
}

// Step 4: Add offset (local space)
localTarget += data.offset;

// Step 5: Convert to world space
Vector3 worldTarget = desc.transform.TransformPoint(localTarget);

// Step 6: Set object position
data.transform.position = worldTarget;
```

**Coordinate Space Transformations**:
```
ViewPosition (avatar local)
    ↓
Eye Alignment (avatar local)
    ↓
+ Offset (avatar local)
    ↓
TransformPoint() → World Space
    ↓
Set object.position
```

### Eye Alignment Implementation Details

**Z-component replacement only**:

The algorithm specifically preserves X and Y from ViewPosition and only replaces Z:

```csharp
Vector3 eyeLocal = desc.transform.InverseTransformPoint(eyeTransform.position);
localTarget.z = eyeLocal.z;  // ← Only Z is replaced
```

**Why only Z?**

ViewPosition is typically centered between eyes:
- **X**: Centered (0)
- **Y**: Eye height
- **Z**: Between eyes (depth)

Eye bones have different Z depths (forward/back relative to head):
- **LeftEye**: Slightly left (-X), same Y, specific Z
- **RightEye**: Slightly right (+X), same Y, specific Z

For monocles/eye-aligned accessories:
- We want centered X and Y (from ViewPosition)
- But specific eye's Z (depth)

**Example values**:
```
ViewPosition:    (0,    1.62, 0.10)
LeftEye bone:    (-0.03, 1.625, 0.115)
RightEye bone:   (0.03, 1.625, 0.115)

With EyeAlignment.LeftEye:
  localTarget = (0, 1.62, 0.115) ← X,Y from ViewPosition, Z from LeftEye
  
With EyeAlignment.None:
  localTarget = (0, 1.62, 0.10) ← All from ViewPosition
```

### VRCFury Armature Link Creation

After positioning, create head link:

```csharp
var link = FuryComponents.CreateArmatureLink(data.gameObject);
link.LinkTo(HumanBodyBones.Head);
```

**Why Head bone?**
- ViewPosition is relative to avatar root, but should move with head
- Head bone link ensures VR head movement affects the object
- Offset from head to object position is baked by VRCFury

**VRCFury baking process**:
```
1. Object is at world position (set by component)
2. VRCFury creates armature link to Head
3. VRCFury calculates offset:
   offset = object.position - head.position (in head's local space)
4. At runtime:
   object.position = head.position + head.rotation * offset
```

### Callback Order and Execution

**Order**: `int.MinValue` (very early)

**Execution relative to other processors**:
```
int.MinValue        → AttachToViewPositionProcessor
int.MinValue        → AttachToBodyPartProcessor
int.MinValue        → AttachToClosestBoneProcessor
int.MinValue + 50   → AutoGripProcessor
int.MinValue + 99   → AutoBodyHiderCoordinator
int.MinValue + 100  → AutoBodyHiderProcessor
```

**Why early?**
- Sets object positions before other systems run
- Ensures positions are finalized before mesh processing
- Armature links set up before anything depends on them

### Progress Window Integration

```csharp
var progressWindow = YUCPProgressWindow.Create();
progressWindow.Progress(0, "Processing view position links...");

for (int i = 0; i < dataList.Length; i++)
{
    // ... process component ...
    
    float progress = (float)(i + 1) / dataList.Length;
    progressWindow.Progress(progress, $"Processed view position link {i + 1}/{dataList.Length}");
}

progressWindow.CloseWindow();
```

### Transform Space Conversions

**Unity's transform space methods**:

```csharp
// Local → World
Vector3 worldPos = transform.TransformPoint(localPos);
// Affected by position, rotation, scale

// World → Local  
Vector3 localPos = transform.InverseTransformPoint(worldPos);
// Inverse of TransformPoint

// Local Direction → World Direction
Vector3 worldDir = transform.TransformDirection(localDir);
// Affected by rotation only

// World Direction → Local Direction
Vector3 localDir = transform.InverseTransformDirection(worldDir);
// Inverse of TransformDirection
```

**Used in this component**:
```csharp
// Eye bone world → avatar local
Vector3 eyeLocal = desc.transform.InverseTransformPoint(eyeTransform.position);

// Final local → world
Vector3 worldTarget = desc.transform.TransformPoint(localTarget);
```

### Custom Inspector Implementation

**File**: `Editor/Header/AttachToViewPositionDataInstances.cs`

Minimal inspector with info box:

```csharp
[CustomEditor(typeof(AttachToViewPositionData))]
public class AttachToViewPositionDataEditor : UnityEditor.Editor
{
    public override VisualElement CreateInspectorGUI()
    {
        var root = new VisualElement();
        root.Add(YUCPComponentHeader.CreateHeaderOverlay("View Position & Head Auto-Link"));
        
        var container = new IMGUIContainer(() => {
            serializedObject.Update();
            
            DrawSection("Settings", () => {
                EditorGUILayout.PropertyField(serializedObject.FindProperty("offset"));
                EditorGUILayout.PropertyField(serializedObject.FindProperty("eyeAlignment"));
            });
            
            EditorGUILayout.HelpBox(
                "Positions this object at the avatar's view position (eye level) and links it to the head bone.",
                MessageType.Info);
            
            serializedObject.ApplyModifiedProperties();
        });
        
        return root;
    }
}
```

### Performance Characteristics

**Build time**: <1ms per component
**Runtime**: None (IEditorOnly component)
**Memory**: ~16 bytes (Vector3 + enum)
**Calculations**: 1-2 transform space conversions per component

**No heavy operations**:
- No mesh processing
- No ray casting
- No searching
- Simple arithmetic only

### Execution Order

**DefaultExecutionOrder attribute**:
```csharp
[DefaultExecutionOrder(-100)]
public class AttachToViewPositionData : MonoBehaviour
```

**Purpose**: Ensures component's `Awake()` runs early if needed  
**Note**: Not used in current implementation (no Awake/Start logic)  
**Future-proofing**: Reserved for potential runtime preview features

### Eye Bone Fallback

If eye bone is missing:

```csharp
var eyeTransform = animator.GetBoneTransform(bone);
if (eyeTransform != null)
{
    // Apply eye alignment
}
else
{
    Debug.LogWarning($"Eye bone {bone} not found on animator", data);
    // Continue without eye alignment (uses ViewPosition Z)
}
```

**Graceful degradation**: Missing eye bones don't fail the build, just skip alignment.

### Source Code Reference

**Runtime Component**:
```
Packages/com.yucp.components/Runtime/Components/Data/AttachToViewPositionData.cs
- Component definition (25 lines)
- Simple data container
- IEditorOnly, IPreprocessCallbackBehaviour
```

**Build Processor**:
```
Packages/com.yucp.components/Editor/Components/Processors/AttachToViewPositionProcessor.cs
- Position calculation (91 lines)
- VRCFury link creation
- Eye alignment logic
```

**Custom Inspector**:
```
Packages/com.yucp.components/Editor/Header/AttachToViewPositionDataInstances.cs
- Minimal UIElements inspector (63 lines)
- Info help box
```

### Integration Points

**VRChat SDK**:
```csharp
using VRC.SDK3.Avatars.Components;
using VRC.SDKBase;

VRC_AvatarDescriptor desc = GetComponentInParent<VRC_AvatarDescriptor>();
Vector3 viewPos = desc.ViewPosition;
```

**VRCFury API**:
```csharp
using com.vrcfury.api;

var link = FuryComponents.CreateArmatureLink(GameObject target);
link.LinkTo(HumanBodyBones.Head);
```

**Unity Animator**:
```csharp
Animator animator = GetComponent<Animator>();
Transform eyeBone = animator.GetBoneTransform(HumanBodyBones.LeftEye);
```

### Logging Output

**Successful processing**:
```
[AttachToViewPositionProcessor] Preprocess: moving to view position and linking to head
Moved 'Glasses' to world position (0.045, 1.624, 0.182)
Linked 'Glasses' to Head bone with baked offset
```

**Error cases**:
```
[AttachToViewPositionProcessor] No VRC_AvatarDescriptor found for 'MyObject'
Eye bone LeftEye not found on animator
```

### Vector Math Details

**Offset addition (component-wise)**:
```csharp
localTarget += data.offset;

// Equivalent to:
localTarget.x += data.offset.x;
localTarget.y += data.offset.y;
localTarget.z += data.offset.z;
```

**TransformPoint implementation** (conceptual):
```csharp
Vector3 TransformPoint(Vector3 localPos)
{
    // Apply scale
    Vector3 scaled = Vector3.Scale(localPos, transform.lossyScale);
    
    // Apply rotation
    Vector3 rotated = transform.rotation * scaled;
    
    // Apply position
    Vector3 world = transform.position + rotated;
    
    return world;
}
```

**InverseTransformPoint implementation** (conceptual):
```csharp
Vector3 InverseTransformPoint(Vector3 worldPos)
{
    // Subtract position
    Vector3 relative = worldPos - transform.position;
    
    // Apply inverse rotation
    Vector3 rotated = Quaternion.Inverse(transform.rotation) * relative;
    
    // Apply inverse scale
    Vector3 local = new Vector3(
        rotated.x / transform.lossyScale.x,
        rotated.y / transform.lossyScale.y,
        rotated.z / transform.lossyScale.z
    );
    
    return local;
}
```

### Comparison with Other Components

| Feature | View Position | Symmetric Armature | Closest Bone |
|---------|---------------|-------------------|--------------|
| Position source | ViewPosition | Object position | Object position |
| Target bone | Always Head | Humanoid bones | Any bone |
| Position set | At build time | No (relative) | No (relative) |
| Eye alignment | Yes | No | No |
| Best for | HUD, glasses | Symmetric parts | Custom bones |

### Future Enhancements

Potential improvements:

1. **Preview gizmo** - Show ViewPosition sphere and offset in Scene view
2. **Runtime offset** - Animated offset adjustments
3. **Facial landmarks** - Align to nose, mouth, chin (beyond eyes)
4. **Distance from face** - Offset based on face bounds/mesh
5. **IPD-aware positioning** - Account for interpupillary distance
6. **Desktop vs VR offsets** - Different positioning for each mode
7. **Smooth transition** - Animated movement to position (for effects)

### Stereo Rendering Considerations

**ViewPosition in VR**:
- Single point between eyes
- Left eye camera offset: -IPD/2 (typically -3.2cm)
- Right eye camera offset: +IPD/2 (typically +3.2cm)

**Eye alignment effect**:
- LeftEye alignment: Matches left camera depth
- RightEye alignment: Matches right camera depth
- None: Centered depth (between cameras)

**For best stereo effect**:
- Monocles: Use eye alignment
- Glasses: Use centered (None)
- HUD elements: Depends on desired depth

### Build Log Analysis

**Example successful build**:
```
[AttachToViewPositionProcessor] Preprocess: moving to view position and linking to head
Moved 'Glasses' to world position (0.045, 1.624, 0.182)
Linked 'Glasses' to Head bone with baked offset
[AttachToViewPositionProcessor] Processed view position link 1/1
```

**What this tells us**:
1. Component found and processed
2. Glasses moved to world coordinates (0.045, 1.624, 0.182)
3. VRCFury link created to Head bone
4. Progress: 1 of 1 components processed

**Example with eye alignment**:
```
[AttachToViewPositionProcessor] Preprocess: moving to view position and linking to head
Moved 'Monocle_L' to world position (-0.015, 1.628, 0.195)
Linked 'Monocle_L' to Head bone with baked offset
```

**Comparing positions**:
- Glasses (no alignment): Z = 0.182
- Monocle (left eye): Z = 0.195
- **Difference**: Eye alignment pushed monocle 1.3cm forward

### Memory Layout

```
AttachToViewPositionData (MonoBehaviour)
├── offset (Vector3) - 12 bytes (3 floats)
└── eyeAlignment (int/enum) - 4 bytes

Total: 16 bytes per component
```

**Serialization**:
- Simple struct serialization
- No complex references
- No cached data
- Minimal memory footprint



