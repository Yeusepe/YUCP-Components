# Custom Object Sync

Drop this component on any object you want to sync and the YUCP build pipeline will install the full VRLabs Custom Object Sync system automatically. This implementation bundles the original VRLabs (MIT) resources so no external package is required, but please continue to credit VRLabs when you use it.

## Requirements

- Avatar must use VRChat SDK3 Avatars.
- Unity 2022.3.x (same as other YUCP components).
- Only one `CustomObjectSyncData` component is supported per avatar. Attach it to the object you want to sync.

## Usage

1. Select the mesh or prop you want to sync.
2. Add `Component > YUCP > Custom Object Sync`.
3. Configure the inspector:
   - **Quick Sync**: Sends floats directly for minimal latency. Always avatar-centered.
   - **Reference Frame**: When Quick Sync is off, choose Avatar-Centered (lower range, no late join) or World Space (large range, late join).
   - **Precision / Range**: Adjust radius (2^n meters) and position/rotation precision.
   - **Bits Per Step**: Used only when Quick Sync is disabled to trade parameter usage vs. latency.
   - **Rotation / Debug / Damping**: Toggle rotational sync, local debug visualization, and the optional damping helper.
   - **Menu Location**: Where the generated toggle should appear in your expression menu.
4. Build/upload. During `IVRCSDKPreprocessAvatarCallback`, the processor:
   - Clones the Custom Object Sync prefab into your avatar.
   - Generates/merges FX layers, expression parameters, and menu controls.
   - Sets up contacts, constraints, and optional debug layers.
5. After a build the component stores a short summary + timestamp so you can confirm the last generation in the inspector.

## Tips

- Use Quick Sync for props that stay close to you and need minimal delay.
- Use the bit-packed mode when you need to preserve expression parameters or require long-range syncing.
- Damping helps remote objects ease into new locations when the network jumps.
- The Local Debug View renders a ghost copy so you can visualize what remotes see without uploading.

## Credits

This component embeds VRLabs Custom Object Sync (MIT). All credit for the original system goes to VRLabs and jellejurre. Please support them: https://github.com/VRLabs/Custom-Object-Sync.

