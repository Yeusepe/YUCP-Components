# Auto Body Hider

> **Automatically detect and hide body parts covered by clothing using GPU-accelerated detection with toggleable multi-clothing support.**

---

## Table of Contents

- [Overview](#overview)
- [Quick Start](#quick-start)
- [Component Settings Reference](#component-settings)
- [Detection Methods](#detection-methods-comparison)
- [Step-by-Step Tutorials](#step-by-step-tutorial)
- [Advanced Features](#advanced-features)
- [Troubleshooting](#troubleshooting)
- [FAQ](#faq)
- [Examples](#examples)
- [For the Nerds](#for-the-nerds)

---

## Overview

Auto Body Hider is the flagship component of YUCP Components. It automatically detects which parts of the avatar body are hidden by clothing and either **deletes those vertices** (permanent) or **moves them to UDIM discard tiles** (toggleable). The component supports multiple detection algorithms, GPU acceleration, multi-clothing coordination, and both Poiyomi and FastFur shaders.

### Key Features

| Feature | Description |
|---------|-------------|
| **5 Detection Methods** | Raycast, Proximity, Hybrid, Smart, Manual - choose the best for your use case |
| **GPU Acceleration** | Automatic GPU usage for raycast methods when available |
| **Multi-Clothing Support** | Multiple clothing pieces coordinate UDIM tiles automatically |
| **Layered Clothing** | Overlap detection for outfits with multiple layers |
| **Tile Optimization** | Reduces UDIM tiles for fully-covered inner layers |
| **Dual Shader Support** | Works with both Poiyomi and FastFur (Warren's Fast Fur Shader) |
| **Toggleable Hiding** | UDIM mode allows menu toggles for clothing |
| **Detection Caching** | SHA-256 based caching speeds up rebuilds |
| **Real-Time Preview** | Visualize detection results before building |

### Why Use This?

#### The Problem: Manual Body Hiding is Tedious

- Manually deleting vertices requires mesh editing software
- Hard to update when clothing changes
- No easy way to make it toggleable
- Multi-clothing setups require complex UDIM coordination

#### The Solution: Auto Body Hider

- Automatic detection during build
- Update by changing settings and rebuilding
- Optional toggles with automatic UDIM management
- Multi-clothing "just works" with tile coordination

### Use Cases

| Use Case | Recommended Method | Notes |
|----------|-------------------|-------|
| **Any clothing** | Smart / Hybrid | Shirts, pants, dresses, jackets |
| **Layered outfits** | Smart + Optimization | Multiple pieces that overlap |
| **Toggleable outfits** | UDIM Mode | Mix-and-match with menu toggles |
| **Tight clothing** | Raycast | Bodysuits, leotards (tight fit) |
| **Loose clothing** | Proximity / Smart | Hoodies, coats (loose fit) |
| **Complex outfits** | Smart + Coordination | Multi-piece with overlaps |
| **Performance optimization** | Mesh Deletion | Delete hidden vertices to reduce poly count |

---

## Quick Start

### Basic Setup (Single Clothing Piece)

Follow these steps for a simple single-clothing setup:

#### Step 1: Add the Component
1. Select your **clothing GameObject** in the hierarchy
2. Click `Add Component → YUCP → Auto Body Hider`

#### Step 2: Assign Meshes
In the Auto Body Hider inspector:
- **Body Mesh**: Drag your avatar's body `SkinnedMeshRenderer` here
- **Clothing Mesh**: Drag your clothing's `SkinnedMeshRenderer` here

> These are the two meshes that will be analyzed. The body mesh will be modified, the clothing mesh is used for detection.

#### Step 3: Generate Preview
1. Click the green **`Generate Preview`** button
2. Wait for the progress bar to complete
3. Look in the **Scene view** - red highlighted faces show what will be hidden

> The preview is non-destructive. It only visualizes what will happen during build.

#### Step 4: Adjust Settings (Optional)
- **Too much hidden?** Increase `Safety Margin` to 0.005-0.01
- **Too little hidden?** Decrease `Safety Margin` to 0.001
- **Try different methods**: Switch between Raycast, Hybrid, or Smart

#### Step 5: Choose Application Mode
- **Permanent hiding**: Set `Application Mode` to `Mesh Deletion`
- **Toggleable hiding**: Set to `UDIM Discard` (requires Poiyomi/FastFur shader)

#### Step 6: Enable Toggle (Optional - UDIM Mode Only)
If using UDIM Discard mode:
1. Check **`Create Toggle`**
2. Set `Toggle Type` to **ObjectToggle** (toggles both clothing and body)
3. Set `Menu Path` to your desired location (e.g., "Clothing/Shirt")
4. Check **`Saved`** to remember toggle state across reloads

#### Step 7: Build Avatar
- Use `VRChat SDK → Build & Publish`
- Watch the Console for processing logs
- Look for success messages

---

### Multi-Clothing Setup

For outfits with multiple pieces (underwear, shirt, jacket, etc.):

#### Step 1: Add Components to All Pieces
- Add `Auto Body Hider` component to **each clothing piece**

#### Step 2: Configure Each Component
For **every** Auto Body Hider component:
- Assign the **same** `Body Mesh` (your avatar's body)
- Assign each piece's respective `Clothing Mesh`
- Set `Detection Method` to **Smart** (recommended for multi-clothing)
- Check **`Optimize Tile Usage`** (saves UDIM tiles)

#### Step 3: UDIM Tile Assignment
The system auto-assigns tiles, but you can manually set them:
- Piece 1: Row=1, Col=0
- Piece 2: Row=1, Col=1
- Piece 3: Row=1, Col=2
- etc.

> Leave as default to let the system auto-assign tiles intelligently.

#### Step 4: Configure Toggles (Optional)
For each piece that should be toggleable:
- Check **`Create Toggle`**
- Set unique menu paths (e.g., "Clothing/Underwear", "Clothing/Shirt")
- Enable **`Saved`** to remember states

#### Step 5: Build
When you build, the system automatically:
- Assigns unique UDIM tiles
- Detects overlapping regions
- Creates overlap tiles for shared vertices
- Configures materials correctly
- Creates all menu toggles

---

## Component Settings

Complete reference for all Auto Body Hider settings.

### Target Meshes

#### Body Mesh
| | |
|---|---|
| **Type** | SkinnedMeshRenderer |
| **Required** | Yes |
| **Description** | The body mesh that should have parts hidden |

This is usually your avatar's main body mesh. The component will modify this mesh to hide vertices covered by clothing.

#### Clothing Mesh
| | |
|---|---|
| **Type** | SkinnedMeshRenderer |
| **Required** | Yes (except Manual method) |
| **Description** | The clothing mesh that covers the body |

Used by automatic detection methods to determine which body parts are covered. Not needed for Manual method.

---

### Detection Settings

#### Detection Method
| | |
|---|---|
| **Type** | Enum |
| **Options** | Raycast, Proximity, Hybrid, Smart, Manual |
| **Default** | Smart |

Choose the detection algorithm:

| Method | Description | Best For |
|--------|-------------|----------|
| **Raycast** | Shoots rays from body vertices along normals | Fast, accurate for tight clothing |
| **Proximity** | Checks distance to nearest clothing vertex | Very fast, loose clothing |
| **Hybrid** | Proximity filtering + raycast verification | Balanced speed and accuracy |
| **Smart** | Multi-directional raycast with threshold | Most accurate, complex outfits |
| **Manual** | Uses a texture mask | Perfect control, repeated builds |

#### Safety Margin
| | |
|---|---|
| **Type** | Float |
| **Range** | 0 - 0.1 |
| **Default** | 0.003 |
| **Units** | Meters |

Buffer distance from detection edges. Vertices within this distance of visible vertices are kept visible.

> Prevents clipping artifacts at clothing boundaries. Increase if you see clipping, decrease if too much body is visible.

**Common Values**:
- **0.001** - Minimal margin (tight fit)
- **0.003** - Default (balanced)
- **0.005-0.01** - Conservative (loose fit)

#### Proximity Threshold
| | |
|---|---|
| **Type** | Float |
| **Default** | 0.02 |
| **Units** | Meters |
| **Used by** | Proximity, Hybrid |

Body vertices within this distance from clothing are hidden.

#### Raycast Distance
| | |
|---|---|
| **Type** | Float |
| **Default** | 0.1 |
| **Units** | Meters |
| **Used by** | Raycast, Hybrid, Smart |

Maximum distance to check for occlusion. Should be large enough to span the gap between body and clothing.

#### Hybrid Expansion Factor
| | |
|---|---|
| **Type** | Float |
| **Default** | 1.5 |
| **Used by** | Hybrid |

Multiplier for proximity threshold in hybrid mode's first pass. Higher values cast a wider net for candidates.

---

### Smart Detection Settings

These settings appear when `Detection Method` is set to **Smart**.

#### Ray Directions
| | |
|---|---|
| **Type** | Int |
| **Range** | 8 - 128 |
| **Default** | 32 |

Number of rays to cast per vertex using Fibonacci sphere distribution.

> More rays = more accurate detection, but slower processing.

**Recommended Values**:
- **16** - Fast preview
- **32** - Default (balanced)
- **64** - High accuracy
- **128** - Maximum accuracy (slow)

#### Occlusion Threshold
| | |
|---|---|
| **Type** | Float |
| **Range** | 0.0 - 1.0 |
| **Default** | 0.7 |

Percentage of rays that must hit clothing for a vertex to be hidden.

| Value | Meaning | Use Case |
|-------|---------|----------|
| **0.5** | 50% of rays must hit | Aggressive hiding |
| **0.7** | 70% of rays must hit | Recommended default |
| **0.9** | 90% of rays must hit | Conservative (tight clothing only) |

#### Use Normals
| | |
|---|---|
| **Type** | Bool |
| **Default** | true |

Only cast rays in the hemisphere facing outward from the surface (based on vertex normal).

> Recommended to keep enabled. Prevents hiding vertices that face away from clothing.

#### Require Bidirectional
| | |
|---|---|
| **Type** | Bool |
| **Default** | false |

Require rays from both directions (inward and outward) to hit clothing before hiding a vertex.

> More conservative - only hides truly enclosed vertices. Use for loose clothing.

#### Ray Offset
| | |
|---|---|
| **Type** | Float |
| **Default** | 0.005 |
| **Units** | Meters |

Distance to offset rays from the surface to prevent self-intersection with the body mesh.

#### Conservative Mode
| | |
|---|---|
| **Type** | Bool |
| **Default** | false |

Weight occlusion by distance - closer hits count more than distant hits.

> Enable for more accurate detection with loose or flowing clothing.

#### Min Distance to Clothing
| | |
|---|---|
| **Type** | Float |
| **Default** | 0.01 |
| **Units** | Meters |

Minimum distance to clothing required to hide a vertex.

> Prevents hiding vertices that are very close to the clothing surface (potential clipping).

---

### Manual Mask Settings

These settings appear when `Detection Method` is set to **Manual**.

#### Manual Mask
| | |
|---|---|
| **Type** | Texture2D |
| **Required** | Yes (for Manual method) |

Grayscale texture where **bright pixels** mark vertices to hide.

> Texture is sampled using the body mesh's UV0 coordinates. Paint bright areas where you want body hidden.

**How to Create**:
1. Export body mesh UVs as template
2. Paint white where body should be hidden
3. Paint black where body should stay visible
4. Import texture and assign here

#### Manual Mask Threshold
| | |
|---|---|
| **Type** | Float |
| **Range** | 0.0 - 1.0 |
| **Default** | 0.5 |

Brightness threshold for the mask. Pixels brighter than this value will be hidden.

| Value | Effect |
|-------|--------|
| **0.5** | Default - hides anything 50% brightness or higher |
| **0.2** | Aggressive - hides even darker gray areas |
| **0.8** | Conservative - only hides very bright areas |

---

### Application Mode

#### Mode
| | |
|---|---|
| **Type** | Enum |
| **Options** | AutoDetect, UDIMDiscard, MeshDeletion |
| **Default** | AutoDetect |

Choose how hidden vertices are handled:

| Mode | Description | Pros | Cons |
|------|-------------|------|------|
| **AutoDetect** | Auto-chooses based on shader | Automatic | May not match intent |
| **UDIMDiscard** | Moves vertices to UDIM tile | Toggleable, reversible | Requires Poiyomi/FastFur |
| **MeshDeletion** | Permanently deletes vertices | Works with any shader, better performance | Not toggleable |

> **Recommendation**: Use UDIM Discard for toggleable clothing, Mesh Deletion for permanent hiding.

---

### UDIM Discard Settings

These settings appear when `Application Mode` is set to **UDIMDiscard**.

#### UV Channel
| | |
|---|---|
| **Type** | Int |
| **Default** | 1 |
| **Options** | 0, 1, 2, 3 |

Which UV channel to use for UDIM discard coordinates.

> **Default (UV1)** is recommended. UV0 is typically used for textures.

#### Row
| | |
|---|---|
| **Type** | Int |
| **Range** | 0 - 3 |
| **Default** | 1 |

UDIM tile row position.

> **Avoid Row 0** (especially tile 0,0) as it can conflict with normal texture space.

#### Column
| | |
|---|---|
| **Type** | Int |
| **Range** | 0 - 3 |
| **Default** | 0 |

UDIM tile column position.

> For multi-clothing, the system auto-assigns unique tiles. Manual assignment is optional.

---

### UDIM Toggle Settings

These settings appear when `Application Mode` is **UDIMDiscard**.

#### Create Toggle
| | |
|---|---|
| **Type** | Bool |
| **Default** | false |

Automatically create a VRCFury toggle for this clothing piece.

> Disabled if VRCFury Toggle or UV Discard Toggle component is already present on the GameObject.

#### Toggle Type
| | |
|---|---|
| **Type** | Enum |
| **Options** | ObjectToggle, HiddenToggle |
| **Default** | ObjectToggle |

| Type | Behavior |
|------|----------|
| **ObjectToggle** | Toggles both clothing visibility AND body hiding |
| **HiddenToggle** | Only toggles body hiding (clothing always visible) |

> **ObjectToggle** is recommended for most use cases.

#### Menu Path
| | |
|---|---|
| **Type** | String |
| **Default** | "" |
| **Example** | "Clothing/Shirt" |

Menu path for the toggle in the avatar's expression menu.

> Required for local toggles. Optional for synced toggles with custom parameter.

#### Synced
| | |
|---|---|
| **Type** | Bool |
| **Default** | false |

Sync toggle state across all players (network synced).

> Enable for toggles that all players should see. Leave disabled for local-only toggles.

#### Parameter Name
| | |
|---|---|
| **Type** | String |
| **Default** | "" (auto-generated) |

Custom parameter name for the toggle. Leave empty to auto-generate.

> Only needed if you want to control the toggle from other animators or scripts.

#### Saved
| | |
|---|---|
| **Type** | Bool |
| **Default** | false |

Save toggle state across avatar reloads and world changes.

#### Default ON
| | |
|---|---|
| **Type** | Bool |
| **Default** | false |

Start with the toggle in the ON state when avatar loads.

---

### Advanced Toggle Options

Additional toggle configuration options (appears in foldout).

| Setting | Type | Description |
|---------|------|-------------|
| **Use Slider** | Bool | Use a slider control instead of a button |
| **Hold Button** | Bool | Hold to activate instead of toggle latch |
| **Exclusive Off State** | Bool | Only one toggle in group can be ON |
| **Exclusive Tags** | String | Mutual exclusivity with tag-matched toggles |
| **Custom Icon** | Texture2D | Custom icon for the menu button |
| **Debug Save Animation** | Bool | Save generated animation clip to Assets/ |

---

### Advanced Options

Additional detection and processing options (appears in foldout).

#### Mirror Symmetry
| | |
|---|---|
| **Type** | Bool |
| **Default** | false |

Mirror detection results across the X-axis for symmetric clothing.

> Use when clothing is symmetric and you want both sides to be hidden identically.

#### Use Bone Filtering
| | |
|---|---|
| **Type** | Bool |
| **Default** | false |

Only hide vertices weighted to specific bones.

> Enable to show a bone picker. Useful for partial hiding (e.g., only torso, not arms).

#### Optimize Tile Usage
| | |
|---|---|
| **Type** | Bool |
| **Default** | false |

Reduce UDIM tiles for layered outfits by skipping overlap tiles for fully-covered inner layers.

> **Enable for multi-clothing setups** to save UDIM tiles. Inner layers that are 95%+ covered by outer layers won't get overlap tiles.

#### Debug Mode
| | |
|---|---|
| **Type** | Bool |
| **Default** | false |

Enable verbose debug logging in the Console.

> Useful for troubleshooting detection issues.

#### Show Preview
| | |
|---|---|
| **Type** | Bool |
| **Default** | false |

Show preview visualization in Scene view (red highlighted faces).

> Automatically enabled when you click "Generate Preview".

## Detection Methods Comparison

Choose the right detection method for your use case.

### Quick Comparison Table

| Method | Speed | Accuracy | GPU Support | Best For |
|--------|-------|----------|-------------|----------|
| **Proximity** | Very Fast | Fair | No | Quick previews, loose clothing |
| **Raycast** | Fast | Good | Yes | Tight-fitting clothing, bodysuits |
| **Hybrid** | Medium | Very Good | Partial | General purpose, balanced approach |
| **Smart** | Slow | Excellent | Yes | Complex multi-layer outfits, maximum accuracy |
| **Manual** | Instant | Perfect* | No | Precise control, repeated builds, custom masks |

\* *Manual method accuracy depends on mask quality*

---

### Method Details

#### Proximity Detection
```
Checks distance from each body vertex to nearest clothing vertex
```

**How it works**:
- Measures distance between each body vertex and closest clothing vertex
- Hides vertices within `Proximity Threshold` distance

**Performance**:
- Time complexity: O(n × m) where n=body vertices, m=clothing vertices
- Memory: Minimal
- Speed: Very fast (500ms for 10k vertices)

**Best for**:
- Quick previews during setup
- Loose-fitting clothing (hoodies, jackets)
- Fast iteration

**Limitations**:
- Less accurate for tight clothing
- Can miss vertices in folds or gaps

---

#### Raycast Detection
```
Casts rays from body vertices along their normals
```

**How it works**:
- Shoots a ray from each body vertex outward along its normal
- Hides vertices where ray hits clothing within `Raycast Distance`

**Performance**:
- Time complexity: O(n × t) where n=body vertices, t=clothing triangles
- Memory: GPU buffers (if available)
- Speed: Fast with GPU (200ms), slower on CPU (2s)

**Best for**:
- Tight-fitting clothing (bodysuits, leotards)
- GPU-accelerated systems
- Quick, accurate detection

**Limitations**:
- Only checks one direction (outward normal)
- May miss vertices in complex folds

---

#### Hybrid Detection
```
Combines proximity filtering with raycast verification
```

**How it works**:
- **Phase 1**: Proximity check to identify candidate vertices
- **Phase 2**: Raycast verification only for candidates

**Performance**:
- Time complexity: O(n × m) + O(c × t) where c=candidates
- Memory: Moderate
- Speed: Medium (150ms with GPU)

**Best for**:
- General purpose use
- Balance of speed and accuracy
- Most clothing types

**Advantages**:
- Faster than Smart detection
- More accurate than Proximity alone
- Good middle ground

---

#### Smart Detection
```
Multi-directional raycasting with occlusion threshold
```

**How it works**:
- Casts multiple rays per vertex using Fibonacci sphere distribution
- Calculates percentage of rays that hit clothing
- Hides vertex if percentage exceeds `Occlusion Threshold`

**Performance**:
- Time complexity: O(n × d × t) where d=directions (32 default)
- Memory: Large GPU buffers
- Speed: Slow (1.5s with GPU, 30s on CPU)

**Best for**:
- Complex multi-layer outfits
- Maximum accuracy required
- Final builds (not quick iteration)

**Advantages**:
- Most accurate method
- Handles loose clothing well
- Configurable threshold for partial coverage

**Settings**:
- `Ray Directions`: More rays = more accurate
- `Occlusion Threshold`: Higher = more conservative
- `Use Normals`: Limit rays to outward hemisphere
- `Require Bidirectional`: Extra conservative (enclosed only)

---

#### Manual Detection
```
Uses a texture mask to mark vertices for hiding
```

**How it works**:
- Samples a grayscale texture using body mesh UV0
- Hides vertices where texture brightness exceeds `Manual Mask Threshold`

**Performance**:
- Time complexity: O(n) - very fast
- Memory: Texture in memory
- Speed: Instant (50ms)

**Best for**:
- Precise manual control
- Repeated builds with same hiding pattern
- Custom or artistic hiding patterns

**Advantages**:
- Perfect accuracy (if mask is correct)
- Very fast
- Completely customizable

**How to use**:
1. Export body mesh UVs as template
2. Paint mask texture (white=hide, black=keep)
3. Import texture and assign to component

---

### Decision Flowchart

```
Is this a repeated build with known pattern?
  └─ YES → Use Manual (with pre-made mask)
  └─ NO ↓

Is maximum accuracy critical?
  └─ YES → Use Smart (slower, most accurate)
  └─ NO ↓

Is clothing tight-fitting?
  └─ YES → Use Raycast (fast, accurate for tight clothing)
  └─ NO ↓

Need quick preview?
  └─ YES → Use Proximity (fastest)
  └─ NO → Use Hybrid (balanced, general purpose)
```

---

## Step-by-Step Tutorial

Detailed walkthroughs for common use cases.

---

### Tutorial 1: Basic Hoodie (Smart Detection)

Learn the complete workflow with a simple hoodie example.

#### Step 1: Prepare the Scene
1. **Import** hoodie clothing into your Unity project
2. **Position and scale** hoodie on avatar body (fit it properly)
3. **Verify** both body and hoodie have `SkinnedMeshRenderer` components

> Make sure the hoodie is positioned correctly before detection. The component analyzes the current scene positions.

---

#### Step 2: Add Component
1. Select the **hoodie GameObject** in the Hierarchy
2. In Inspector, click `Add Component`
3. Navigate to `YUCP → Auto Body Hider`

> The component should be on the clothing object, not the body.

---

#### Step 3: Assign Meshes
1. In Inspector, locate the **Auto Body Hider** component
2. Find the **Body Mesh** field
   - Drag your avatar's body `SkinnedMeshRenderer` here
3. Find the **Clothing Mesh** field
   - Drag the hoodie's `SkinnedMeshRenderer` here

> **Tip**: You can also use the object picker (circle icon) to select meshes from the scene.

---

#### Step 4: Configure Detection
1. Set **Detection Method** to **Smart** (best accuracy for hoodies)
2. Leave **Safety Margin** at default (0.003m) for now
3. Leave Smart Detection settings at their defaults:
   - Ray Directions: 32
   - Occlusion Threshold: 0.7

> Smart detection is slower but most accurate for loose clothing like hoodies.

---

#### Step 5: Generate Preview
1. Click the green **`Generate Preview`** button at the bottom
2. Wait for the progress bar to complete (may take 5-30 seconds)
3. Look in the **Scene view** - red highlighted faces show what will be hidden

> The preview is non-destructive. It only visualizes detection results.

**What to look for**:
- Red faces should cover the torso/arms under the hoodie
- No red faces should appear on visible body parts
- Edges should look clean without gaps

---

#### Step 6: Adjust if Needed

If the detection isn't quite right:

| Problem | Solution |
|---------|----------|
| **Too much hidden** | Increase `Safety Margin` to 0.005-0.01 |
| **Too little hidden** | Decrease `Safety Margin` to 0.001-0.002 |
| **Gaps at edges** | Increase `Safety Margin` |
| **Visible body clipping through** | Decrease `Safety Margin` or increase `Occlusion Threshold` |

After adjusting, click **`Generate Preview`** again to see updated results.

---

#### Step 7: Choose Application Mode

Decide how to apply the hiding:

**Option A: Permanent Hiding (Mesh Deletion)**
- Set `Application Mode` to **Mesh Deletion**
- Best for: Always-worn clothing, performance optimization
- Result: Vertices permanently deleted, works with any shader

**Option B: Toggleable Hiding (UDIM Discard)**
- Set `Application Mode` to **UDIM Discard**
- Best for: Optional clothing, toggleable outfits
- Requires: Poiyomi or FastFur shader on body mesh

---

#### Step 8: Add Toggle (Optional - UDIM Mode Only)

If using UDIM Discard mode and want a menu toggle:

1. Check **`Create Toggle`**
2. Set **Toggle Type** to **ObjectToggle** (toggles both hoodie and body hiding)
3. Set **Menu Path** to `"Clothing/Hoodie"`
4. Check **`Saved`** to remember toggle state across reloads
5. (Optional) Check **`Default ON`** to start with hoodie visible

> The toggle will appear in your avatar's expression menu at the specified path.

---

#### Step 9: Build Avatar

1. Open VRChat SDK: `VRChat SDK → Build & Publish`
2. Click **Build & Publish for Windows**
3. Watch the Console for processing logs:
   ```
   [AutoBodyHider] Processing clothing: Hoodie
   [AutoBodyHider] Detected 1,234 hidden vertices
   [AutoBodyHider] Applied UDIM discard to tile (1,0)
   [AutoBodyHider] Created toggle: Clothing/Hoodie
   ```
4. Look for success message

> If you see errors, check the Troubleshooting section below.

---

#### Step 10: Test In-Game (UDIM Mode)

If you created a toggle:
1. Upload and load your avatar in VRChat
2. Open your expression menu
3. Navigate to `Clothing → Hoodie`
4. Toggle it on/off to verify body hiding works correctly

---

### Tutorial 2: Multi-Layer Outfit (3 Pieces)

Set up a complete 3-piece outfit with automatic coordination: **underwear, shirt, jacket**.

#### Overview
This tutorial covers:
- Multiple clothing pieces on the same body
- Automatic UDIM tile coordination
- Overlap detection for layered clothing
- Tile optimization to save UDIM space
- Independent toggles for each piece

---

#### Step 1: Add Components to All Pieces

Add Auto Body Hider to each clothing piece:

1. Select **underwear GameObject**
   - `Add Component → YUCP → Auto Body Hider`
2. Select **shirt GameObject**
   - `Add Component → YUCP → Auto Body Hider`
3. Select **jacket GameObject**
   - `Add Component → YUCP → Auto Body Hider`

> Each piece needs its own Auto Body Hider component.

---

#### Step 2: Configure Underwear

On the underwear's Auto Body Hider:

| Setting | Value |
|---------|-------|
| **Body Mesh** | Avatar body SkinnedMeshRenderer |
| **Clothing Mesh** | Underwear SkinnedMeshRenderer |
| **Detection Method** | Smart |
| **Safety Margin** | 0.003 (default) |
| **Application Mode** | UDIM Discard |
| **Optimize Tile Usage** | ✓ Enabled |

**Toggle Settings**:
- ✓ **Create Toggle**
- **Menu Path**: `"Clothing/Underwear"`
- ✓ **Saved**

---

#### Step 3: Configure Shirt

On the shirt's Auto Body Hider:

| Setting | Value |
|---------|-------|
| **Body Mesh** | Avatar body SkinnedMeshRenderer (same as underwear) |
| **Clothing Mesh** | Shirt SkinnedMeshRenderer |
| **Detection Method** | Smart |
| **Safety Margin** | 0.003 (default) |
| **Application Mode** | UDIM Discard |
| **Optimize Tile Usage** | ✓ Enabled |

**Toggle Settings**:
- ✓ **Create Toggle**
- **Menu Path**: `"Clothing/Shirt"`
- ✓ **Saved**

---

#### Step 4: Configure Jacket

On the jacket's Auto Body Hider:

| Setting | Value |
|---------|-------|
| **Body Mesh** | Avatar body SkinnedMeshRenderer (same as others) |
| **Clothing Mesh** | Jacket SkinnedMeshRenderer |
| **Detection Method** | Smart |
| **Safety Margin** | 0.003 (default) |
| **Application Mode** | UDIM Discard |
| **Optimize Tile Usage** | ✓ Enabled |

**Toggle Settings**:
- ✓ **Create Toggle**
- **Menu Path**: `"Clothing/Jacket"`
- ✓ **Saved**

---

#### Step 5: UDIM Tile Assignment (Optional)

The system auto-assigns tiles, but you can manually set them:

| Clothing | Row | Column | Tile Coordinates |
|----------|-----|--------|------------------|
| Underwear | 1 | 0 | (1,0) |
| Shirt | 1 | 1 | (1,1) |
| Jacket | 1 | 2 | (1,2) |

> **Recommendation**: Leave at default (all 1,0) and let the system auto-assign during build.

---

#### Step 6: Generate Previews (Optional)

To verify detection before building:

1. Select underwear → Click `Generate Preview`
2. Select shirt → Click `Generate Preview`
3. Select jacket → Click `Generate Preview`

Check in Scene view that each piece hides appropriate body regions.

---

#### Step 7: Build Avatar

1. `VRChat SDK → Build & Publish`
2. Watch Console for coordination logs:
   ```
   [AutoBodyHider] Found 3 clothing pieces targeting same body mesh
   [AutoBodyHider] Auto-assigning UDIM tiles...
   [AutoBodyHider] Underwear: Tile (1,0)
   [AutoBodyHider] Shirt: Tile (1,1)
   [AutoBodyHider] Jacket: Tile (1,2)
   [AutoBodyHider] Detecting overlaps...
   [AutoBodyHider] Overlap detected: Underwear + Shirt (245 vertices)
   [AutoBodyHider] Overlap detected: Shirt + Jacket (189 vertices)
   [AutoBodyHider] Overlap tile: (1,3) for Underwear + Shirt
   [AutoBodyHider] Optimization: Skipping overlap tile for Underwear (95% covered)
   [AutoBodyHider] Final tiles used: 3 (saved 1 with optimization)
   ```

---

#### Step 8: What Happens Automatically

The system automatically:

1. **Assigns unique tiles** to each clothing piece
   - Underwear → (1,0)
   - Shirt → (1,1)
   - Jacket → (1,2)

2. **Detects overlaps** between clothing
   - Finds vertices hidden by multiple pieces
   - Creates overlap tiles for shared regions

3. **Optimizes tiles** (with `Optimize Tile Usage` enabled)
   - Skips overlap tiles when inner layer is 95%+ covered
   - Saves UDIM tiles for other clothing

4. **Configures materials**
   - Sets body material properties
   - Enables UDIM discard features
   - Sets tile states

5. **Creates toggles**
   - Three independent menu toggles
   - Animations for body hiding
   - Proper toggle coordination

---

#### Step 9: Test In-Game

Upload and test your avatar:

**Menu Check**:
- Open expression menu
- Navigate to `Clothing/`
- Verify three toggles: Underwear, Shirt, Jacket

**Toggle Combinations**:
| Underwear | Shirt | Jacket | Expected Result |
|-----------|-------|--------|-----------------|
| ON | ON | ON | All clothing visible, body hidden under each |
| OFF | ON | ON | Underwear hidden, shirt+jacket visible |
| ON | OFF | ON | Shirt hidden, underwear+jacket visible |
| ON | ON | OFF | Jacket hidden, underwear+shirt visible |

**Body Hiding Check**:
- Toggle each piece individually
- Verify body appears/disappears correctly
- Check that no body parts clip through clothing
- Verify overlapping regions work correctly

---

## Advanced Features

Deep dive into advanced capabilities and workflows.

---

### Multi-Clothing Coordination

When multiple Auto Body Hider components target the same body mesh, they automatically coordinate to manage UDIM tiles efficiently.

#### Automatic UDIM Tile Assignment

Each clothing piece gets its own unique UDIM tile:

```
Clothing 1 (Underwear): → Tile (1,0)
Clothing 2 (Shirt):     → Tile (1,1)
Clothing 3 (Jacket):    → Tile (1,2)
Clothing 4 (Coat):      → Tile (1,3)
...
Up to 16 clothing pieces (4×4 UDIM grid)
```

**How it works**:
1. Coordinator runs first and scans all components
2. Groups components by target body mesh
3. Assigns unique tiles automatically
4. Resolves any manual conflicts

> Manual tile assignments are respected unless they conflict, then auto-assigned.

---

#### Overlap Detection

When clothing pieces hide the same body vertices, the system creates overlap tiles:

```
Scenario:
  Clothing 1 (Underwear) hides torso vertices
  Clothing 2 (Shirt) also hides torso vertices
  → 245 vertices are hidden by BOTH pieces

System creates:
  Individual tile 1: (1,0) for underwear-only vertices
  Individual tile 2: (1,1) for shirt-only vertices
  Overlap tile:      (1,3) for shared vertices

Toggle behavior:
  Underwear ON  → Activates tiles (1,0) + (1,3)
  Shirt ON      → Activates tiles (1,1) + (1,3)
  Both ON       → Activates tiles (1,0) + (1,1) + (1,3)
  Both OFF      → All tiles inactive (body fully visible)
```

**Why overlap tiles?**
- Allows independent toggle control
- Prevents gaps when one piece is toggled off
- Ensures body is hidden when ANY covering clothing is ON

---

#### Tile Optimization

With `Optimize Tile Usage` enabled, the system reduces tile count for fully-covered inner layers:

```
Scenario:
  Underwear: 1000 hidden vertices, no toggle
  Dress:     2500 hidden vertices, has toggle
  Shared:    980 vertices (98% of underwear coverage)

Without optimization:
  Tile (1,0): Underwear-only (20 vertices)
  Tile (1,1): Dress-only (1520 vertices)
  Tile (1,2): Overlap (980 vertices)
  Total: 3 tiles

With optimization:
  Since underwear has no toggle and is 98% covered by dress:
  → Skip underwear-only tile
  → Skip overlap tile
  → Use dress tile for entire region
  
  Tile (1,1): Dress covers everything
  Total: 1 tile (saved 2 tiles!)
```

**Optimization conditions**:
- Inner layer has **no toggle** (permanent clothing)
- Inner layer is **95%+ covered** by outer layer
- Only applies to fully-covered layers

> This saves precious UDIM tiles for other clothing pieces.

---

### Toggle Integration Modes

Auto Body Hider supports three toggle integration modes depending on your setup.

#### Mode 1: Standalone Toggle (Component Creates It)

The component creates and manages the toggle automatically.

**Setup**:
```
1. Enable: Create Toggle = true
2. Set: Menu Path = "Clothing/Shirt"
3. Configure: Toggle options (saved, synced, etc.)
```

**What happens**:
- Component creates a VRCFury Toggle automatically
- UDIM animation is added to the toggle
- Object toggle animation added (if ObjectToggle type)
- Toggle appears in expression menu at specified path

**Best for**:
- Simple single-action toggles
- Quick setup
- Clothing-only animation

---

#### Mode 2: VRCFury Toggle Integration

Integrate with an existing VRCFury Toggle for complex multi-action toggles.

**Setup**:
```
1. Manually add VRCFury Toggle component to clothing GameObject
2. Configure toggle settings:
   - Menu path
   - Saved/synced options
   - Advanced options
3. Add any custom animations:
   - Blend shapes
   - Material swaps
   - Other GameObject toggles
4. Add Auto Body Hider component
5. Leave "Create Toggle" = false
```

**What happens**:
- Auto Body Hider detects existing VRCFury Toggle
- UDIM animation is added to toggle's action list
- Your custom animations are preserved
- Everything runs as one unified toggle

**Best for**:
- Complex multi-action toggles
- Clothing with blend shapes or material swaps
- Custom animation requirements

**Example**:
```
Toggle actions when clothing ON:
1. Show clothing GameObject (your manual setup)
2. Activate clothing blend shapes (your manual setup)
3. Hide body vertices (Auto Body Hider adds this)
```

---

#### Mode 3: UV Discard Toggle Integration

Use a dedicated UV Discard Toggle component (advanced).

**Setup**:
```
1. Add UV Discard Toggle component to clothing
2. Configure UV Discard Toggle settings
3. Add Auto Body Hider component
4. Auto Body Hider detects UV Discard Toggle
```

**What happens**:
- Auto Body Hider skips toggle creation
- UV Discard Toggle handles all toggle logic
- Auto Body Hider only processes UDIM coordinates

**Best for**:
- Advanced users with custom toggle systems
- Integration with other UDIM-based tools
- Special toggle requirements

---

### Integration Decision Chart

```
Do you need blend shapes or material swaps with the toggle?
  └─ YES → Use Mode 2 (VRCFury Toggle Integration)
  └─ NO ↓

Do you have a custom UV Discard Toggle system?
  └─ YES → Use Mode 3 (UV Discard Toggle Integration)
  └─ NO → Use Mode 1 (Standalone Toggle)
```

---

### Shader Support

Auto Body Hider works with **Poiyomi** and **FastFur** shaders for UDIM discard mode.

#### Supported Shaders

| Shader | Version | UDIM Support | Notes |
|--------|---------|--------------|-------|
| **Poiyomi Toon Shader** | 8.0+ | Full | Most popular choice |
| **Warren's Fast Fur Shader** | V5+ | Full | FastFur support |
| **Other shaders** | N/A | Mesh Deletion only | UDIM mode not available |

---

#### Poiyomi Shader Configuration

Auto Body Hider automatically configures these material properties:

**Material Properties**:
```hlsl
_EnableUDIMDiscardOptions = 1        // Enable UDIM discard feature
_UDIMDiscardMode = 0                 // Vertex mode (UV-based)
_UDIMDiscardUV = 1                   // Use UV1 for discard coords
_UDIMDiscardRow{row}_{col} = 0 or 1  // Tile activation state
```

**Example** for tile (1,0):
```hlsl
_UDIMDiscardRow1_0 = 0  // Base state: OFF (body visible)

When toggle ON:
_UDIMDiscardRow1_0 = 1  // Animated state: ON (body hidden)
```

**Shader Keywords**:
```hlsl
POI_UDIMDISCARD  // Enables UDIM discard feature in shader
```

---

#### FastFur Shader Configuration

Auto Body Hider automatically configures these material properties:

**Material Properties**:
```hlsl
_EnableUDIMDiscardOptions = 1        // Enable UDIM discard
_WFFS_FEATURES_UVDISCARD = 1         // Enable FastFur UDIM feature
_UDIMDiscardMode = 0                 // Vertex mode (UV-based)
_UDIMDiscardUV = 1                   // Use UV1 for discard coords
_UDIMDiscardRow{row}_{col} = 0 or 1  // Tile activation state
```

**Shader Keywords**:
```hlsl
WFFS_FEATURES_UVDISCARD  // Enables UDIM feature in FastFur
```

---

#### Why These Shaders Work

Both Poiyomi and FastFur use **identical property naming** for UDIM discard:
- Same property names (`_UDIMDiscardRow{row}_{col}`)
- Same UV channel support
- Same vertex discard logic

> The component automatically detects which shader you're using and configures it correctly.

---

#### Using Other Shaders

If your body mesh uses a shader **other than** Poiyomi or FastFur:
- UDIM Discard mode is **not available**
- Use **Mesh Deletion** mode instead
- Mesh Deletion works with **any shader**

---

### Detection Caching

The component caches detection results to dramatically speed up rebuilds.

#### How Caching Works

**Cache Key Generation**:
The system creates a SHA-256 hash from:
- Mesh GUID and vertex count
- Detection method and all parameters
- Transform positions, rotations, and scales
- Manual mask GUID (if Manual method)
- Safety margin and other settings

> If ANY of these change, cache is invalidated and detection re-runs.

**Cache Location**:
```
Project/Library/YUCPCache/BodyHiderCache.json
```

**Cache File Structure**:
```json
{
  "entries": [
    {
      "hash": "a3f2c8e9...",
      "hiddenVertices": [true, false, true, ...],
      "hiddenCount": 1234,
      "timestamp": 1698345600000
    }
  ]
}
```

---

#### Cache Behavior

| Event | Action |
|-------|--------|
| **After detection** | Auto-saves cache to disk |
| **Before build** | Auto-loads cache if hash matches |
| **Cache hit** | Skips detection, uses cached result |
| **Cache miss** | Runs full detection, saves new cache |
| **7+ days old** | Auto-deleted on next access |

**Manual Cache Management**:
- **Clear Cache** button in Inspector (per-component)
- **Delete cache file** to clear all entries
- Cache survives Unity restarts

---

#### Performance Impact

| Scenario | Uncached | Cached | Improvement |
|----------|----------|--------|-------------|
| **Proximity** (10k verts) | ~500ms | <50ms | 10x faster |
| **Raycast** (10k verts) | ~200ms | <50ms | 4x faster |
| **Smart** (10k verts, 32 rays) | ~1.5s | <100ms | 15x faster |
| **Manual** (any size) | ~50ms | <50ms | Minimal |

> Caching provides the biggest speedup for Smart detection with high vertex counts.

---

### Preview System

The preview system lets you visualize detection results before building.

#### Real-Time Preview

**How to use**:
1. Configure detection settings
2. Click **`Generate Preview`** button
3. Wait for detection to complete
4. View results in Scene view

**Preview Visualization**:
- **Red highlighted faces** = Will be hidden
- **Normal appearance** = Will remain visible
- **Hover over mesh** in Scene view to see preview overlay

**Preview Updates**:
Preview automatically regenerates when you change:
- Safety Margin
- Mirror Symmetry
- Other detection parameters

**Clear Preview**:
- Click **`Clear Preview`** button
- Or change Detection Method
- Preview clears automatically on build

---

#### Preview vs Build Comparison

| Aspect | Preview | Build |
|--------|---------|-------|
| **Algorithm** | Same detection method | Same detection method |
| **Results** | Visualization only | Actually modifies mesh |
| **Mesh modification** | No changes | UV modifications or deletion |
| **Toggles** | Not created | Created and configured |
| **Materials** | Not modified | UDIM properties set |
| **Speed** | Same as first build | Cached on subsequent builds |

> **Important**: Preview shows what WILL happen, but doesn't actually make changes. Only building applies modifications.

---

#### Preview Tips

**Best practices**:
1. **Always preview first** before building with new clothing
2. **Check edges carefully** - zoom in on clothing boundaries
3. **Verify no visible body** is marked red
4. **Test different detection methods** via preview
5. **Adjust Safety Margin** until preview looks correct

**Common preview issues**:
| Issue | Likely Cause |
|-------|--------------|
| No red faces | Meshes not assigned or detection failed |
| Entire body red | Detection threshold too aggressive |
| Gaps at edges | Safety Margin too large |
| Clipping visible | Safety Margin too small |

---

## Troubleshooting

Common issues and their solutions.

---

### No Hidden Vertices Detected

**Symptom**: Preview or build shows "0 hidden vertices detected"

**Possible Causes**:

| Cause | Solution |
|-------|----------|
| **Meshes not assigned** | Check both Body Mesh and Clothing Mesh are assigned |
| **Clothing doesn't cover body** | Verify clothing actually overlaps body in Scene view |
| **Detection threshold too strict** | Increase `Proximity Threshold` or `Raycast Distance` |
| **Wrong detection method** | Try different method (Smart is most reliable) |
| **Mesh transforms** | Verify clothing is scaled/positioned correctly |
| **Flipped normals** | Check clothing normals face outward |

**Debug steps**:
1. Open Scene view and verify clothing overlaps body visually
2. Try Smart detection method with default settings
3. Increase `Raycast Distance` to 0.2 meters
4. Check Console for error messages
5. Enable `Debug Mode` for detailed logging

---

### Too Many Vertices Hidden

**Symptom**: Detection hides more body than expected (including visible parts)

**Possible Causes**:

| Cause | Solution |
|-------|----------|
| **Safety margin too small** | Increase `Safety Margin` to 0.01-0.02 |
| **Detection too aggressive** | Increase `Occlusion Threshold` (Smart) to 0.8-0.9 |
| **Wrong detection method** | Try more conservative method (Raycast instead of Proximity) |
| **Loose clothing** | Enable `Conservative Mode` (Smart detection) |

**Debug steps**:
1. Generate preview to visualize what's being hidden
2. Gradually increase `Safety Margin` in 0.002m increments
3. For Smart: Increase `Occlusion Threshold` to 0.8 or 0.9
4. Enable `Use Normals` (Smart detection)
5. Try Hybrid method instead of Smart

---

### Too Few Vertices Hidden (Clipping)

**Symptom**: Body clips through clothing in-game

**Possible Causes**:

| Cause | Solution |
|-------|----------|
| **Safety margin too large** | Decrease `Safety Margin` to 0.001-0.002 |
| **Detection not thorough** | Use Smart detection with more rays |
| **Clothing has gaps** | Check clothing mesh is closed/watertight |
| **Cached old results** | Click "Clear Cache" and regenerate |

**Debug steps**:
1. Generate preview - check edges carefully
2. Decrease `Safety Margin` in small increments
3. Increase `Ray Directions` to 64 (Smart detection)
4. Clear cache and regenerate preview
5. Verify clothing mesh has no holes/gaps

---

### UDIM Tile Limit Exceeded

**Symptom**: Dialog shows "UDIM Tile Limit Exceeded (16 tiles maximum)"

**Cause**: More than 16 clothing pieces targeting the same body mesh

**Solutions**:

| Solution | When to Use |
|----------|-------------|
| **Enable `Optimize Tile Usage`** | First try - often saves 2-4 tiles |
| **Merge always-worn pieces** | Underwear + bra → single piece |
| **Use Mesh Deletion for some** | Base clothing that's never toggled off |
| **Split across body parts** | Separate upper/lower body meshes |
| **Remove redundant clothing** | Delete unused clothing pieces |

**Tile usage example**:
```
Without optimization:
- 5 clothing pieces = 5 tiles
- 4 overlaps = 4 tiles
- Total: 9 tiles

With optimization:
- 5 clothing pieces = 5 tiles
- 2 overlaps = 2 tiles (2 skipped via optimization)
- Total: 7 tiles (saved 2!)
```

---

### Toggle Not Working In-Game

**Symptom**: Menu toggle appears but doesn't hide body parts

**Diagnostic checklist**:

1. **Shader Check**:
   ```
   Body material must use Poiyomi or FastFur shader
   Other shaders don't support UDIM discard
   ```

2. **Application Mode Check**:
   ```
   Component must be set to "UDIM Discard" mode
   Mesh Deletion mode is not toggleable
   ```

3. **Material Property Check**:
   - Open body material in Inspector
   - Look for `_UDIMDiscardRow1_0` (or similar) properties
   - Should be set to 0 (OFF) in base state
   - Should have "Animated" tag

4. **Toggle Animation Check**:
   - Enable `Debug Save Animation`
   - Check saved animation clips in Assets/
   - Verify animation targets correct material properties

5. **Console Error Check**:
   ```
   Look for:
   [AutoBodyHider] ERROR: Could not configure material
   [AutoBodyHider] WARNING: Shader does not support UDIM discard
   ```

**Solutions**:

| Issue | Fix |
|-------|-----|
| Wrong shader | Apply Poiyomi or FastFur to body material |
| Wrong mode | Set Application Mode to UDIM Discard |
| Material not configured | Rebuild avatar, check Console for errors |
| Animation not created | Verify `Create Toggle` is enabled |
| VRCFury conflict | Check for multiple toggle components |

---

### GPU Acceleration Not Working

**Symptom**: Detection is very slow (10+ seconds) despite having a capable GPU

**Check Console logs**:

**✓ Working GPU**:
```
[GPURaycast] GPU raycasting initialized successfully.
[GPURaycast] Compute shader loaded: VertexRaycastShader
[GPURaycast] Processing 10000 vertices on GPU...
[GPURaycast] GPU raycast completed in 234ms
```

**✗ Not working**:
```
[GPURaycast] Compute shaders not supported on this platform
[GPURaycast] Could not load compute shader: VertexRaycastShader
[GPURaycast] Falling back to CPU raycast
```

**Causes and Solutions**:

| Cause | Solution |
|-------|---------|
| **Graphics API not supported** | Unity → Edit → Project Settings → Graphics → Use DX11/DX12 |
| **Compute shader missing** | Reinstall YUCP Components package |
| **Old Unity version** | Unity 2019.4.31f1+ required for compute shaders |
| **GPU doesn't support compute** | Use CPU-friendly methods (Proximity, Manual) |
| **Mac/Linux** | Compute shader support varies by platform |

---

### Preview Not Showing

**Symptom**: Click "Generate Preview" but no red faces appear

**Possible Causes**:

| Cause | Solution |
|-------|----------|
| **Detection returned 0 vertices** | See "No Hidden Vertices Detected" above |
| **Preview disabled** | Check `Show Preview` is enabled |
| **Scene view not visible** | Make sure Scene view is open and visible |
| **Mesh renderer disabled** | Check body mesh is enabled |
| **Detection failed** | Check Console for errors |

---

### Build Errors

**Symptom**: Errors during avatar build

**Common errors**:

#### "NullReferenceException: Body mesh is null"
```
Solution: Assign Body Mesh field before building
```

#### "InvalidOperationException: Mesh is not readable"
```
Solution: Enable Read/Write in mesh import settings
```

#### "ArgumentException: Mesh has no UV1 channel"
```
This is normal - component creates UV1 automatically
If error persists, verify mesh has UV0 (texture coordinates)
```

#### "VRCFury not found"
```
Solution: Install VRCFury package (required for toggles)
Or use Mesh Deletion mode (no toggles)
```

---

### Performance Issues

**Symptom**: Build takes very long (5+ minutes per clothing piece)

**Optimization steps**:

| Issue | Solution |
|-------|----------|
| **Smart detection + CPU** | Use GPU-compatible system or switch to Hybrid method |
| **Too many rays** | Reduce `Ray Directions` to 16-32 |
| **High poly meshes** | Optimize mesh (reduce vertex count) |
| **Cache disabled** | Enable caching (it's automatic, but check it's not corrupted) |
| **Debug mode enabled** | Disable Debug Mode for production builds |

**Expected build times** (10k body vertices, 5k clothing triangles):

| Method | Time | Notes |
|--------|------|-------|
| Proximity | < 1s | Very fast |
| Raycast (GPU) | 1-2s | Fast |
| Hybrid (GPU) | 2-3s | Moderate |
| Smart (GPU, 32 rays) | 5-10s | Slow but accurate |
| Smart (CPU, 32 rays) | 30-60s | Very slow |

---

## FAQ

Frequently asked questions about Auto Body Hider.

---

### Q: UDIM mode vs Mesh Deletion - which should I use?

**A**: It depends on your needs:

| Aspect | UDIM Discard | Mesh Deletion |
|--------|--------------|---------------|
| **Toggleable** | ✓ Yes | ✗ No (permanent) |
| **Shader requirement** | Poiyomi or FastFur | Any shader |
| **Runtime performance** | Same poly count | Better (fewer vertices) |
| **VRAM usage** | Slightly higher | Lower |
| **VRChat rank impact** | Neutral | Positive (fewer polys) |
| **Setup complexity** | Medium | Simple |

**Recommendations**:
- **Use UDIM** for: Mix-and-match outfits, toggleable clothing, fashion shows
- **Use Mesh Deletion** for: Always-worn clothing, performance optimization, any shader

---

### Q: How many clothing pieces can I have with UDIM mode?

**A**: **Maximum 16 clothing pieces** per body mesh (4×4 UDIM grid limit).

**With tile optimization enabled**, you can effectively use more:
- Optimization skips tiles for 95%+ covered inner layers
- Typically saves 2-4 tiles in multi-layer outfits
- Allows more clothing pieces within the 16-tile limit

**Example**:
```
Without optimization: 8 clothing pieces = 14 tiles (pieces + overlaps)
With optimization: 8 clothing pieces = 10 tiles (saved 4 tiles)
```

---

### Q: Does this work with any shader?

**A**: Depends on the mode:

**UDIM Discard mode**:
- ✓ Poiyomi Toon Shader 8.0+
- ✓ Warren's Fast Fur Shader V5+
- ✗ Other shaders (not supported)

**Mesh Deletion mode**:
- ✓ **Any shader** (Standard, lilToon, Mochie, custom, etc.)
- No shader requirements
- Always works

> If your body uses a different shader, use Mesh Deletion mode.

---

### Q: Will this affect my avatar's performance rank?

**A**: 

**Mesh Deletion mode**: **Improves** rank
- Reduces polygon count
- Fewer vertices to render
- Better GPU performance
- Positive impact on VRChat ranking

**UDIM Discard mode**: **Neutral** impact
- Same polygon count (vertices moved, not deleted)
- Slightly higher VRAM usage
- Runtime discard in shader
- No rank penalty

---

### Q: Can I use this with Modular Avatar?

**A**: **Partially**:

- ✓ **Mesh Deletion mode**: Works perfectly with Modular Avatar
- ✗ **UDIM mode toggles**: Require VRCFury (not compatible with MA-only setups)

**Workarounds for Modular Avatar**:
1. Use Mesh Deletion mode (no toggles)
2. Manually create Modular Avatar toggles + use UDIM mode without auto-toggle
3. Install VRCFury alongside Modular Avatar

---

### Q: What happens if I change clothing after building?

**A**: **You need to rebuild** the avatar.

Detection and hiding happen at **build time**, not runtime:
- Detection analyzes mesh positions during build
- UDIM coordinates are baked into the mesh
- Mesh deletion permanently modifies the mesh asset

**To update**:
1. Make your clothing changes
2. Clear cache (if major changes)
3. Rebuild the avatar
4. Re-upload to VRChat

---

### Q: Can I manually control which vertices are hidden?

**A**: **Yes!** Use the Manual detection method:

1. Set `Detection Method` to **Manual**
2. Create a texture mask:
   - Export body mesh UVs
   - Paint white where body should hide
   - Paint black where body should stay visible
3. Assign texture to `Manual Mask` field
4. Adjust `Manual Mask Threshold` if needed
5. Build avatar

**Benefits**:
- Perfect control over hiding
- Very fast (no detection calculation)
- Reusable for repeated builds
- Artistic/custom patterns possible

---

### Q: Does Safety Margin affect build performance?

**A**: **Slightly**, but the impact is minimal:

**Time complexity**: O(n × e) where n=hidden vertices, e=edge vertices
- Worst case: O(n²) if all vertices are edges
- Typical case: <500ms for 10k vertices

**Real-world impact**:
- 1000 vertices: ~50ms
- 10,000 vertices: ~500ms
- 50,000 vertices: ~2-3s

> The benefit (preventing clipping) far outweighs the small performance cost.

---

### Q: Can I use multiple Auto Body Hiders on the same clothing piece?

**A**: **No**. The component is marked `DisallowMultipleComponent`.

**For complex multi-action toggles**, use VRCFury Toggle integration:
1. Add VRCFury Toggle to clothing
2. Add your custom animations (blend shapes, etc.)
3. Add Auto Body Hider component
4. Auto Body Hider adds body hiding to existing toggle

This gives you one toggle with multiple actions.

---

### Q: Does this work for partial body hiding (e.g., only torso)?

**A**: **Yes!** Use **Bone Filtering**:

1. Enable `Use Bone Filtering` in Advanced Options
2. Select specific bones (e.g., spine bones for torso)
3. Only vertices weighted to those bones will be hidden

**Example**:
```
Shirt that only hides torso (not arms):
- Select spine bones: Spine, Chest, Upper Chest
- Vertices on arms (weighted to arm bones) stay visible
```

---

### Q: Can I preview changes without building?

**A**: **Yes!** Use the preview system:

1. Configure detection settings
2. Click **`Generate Preview`**
3. Red faces in Scene view show what will be hidden
4. Adjust settings and regenerate until satisfied
5. Then build

> Preview is fast and non-destructive - use it liberally!

---

### Q: What if I need more than 16 clothing pieces?

**A**: Several options:

1. **Enable `Optimize Tile Usage`** - Often saves 2-4 tiles
2. **Combine pieces** - Merge clothing that's always worn together
3. **Use Mesh Deletion** - For permanent base clothing (no tile needed)
4. **Split body mesh** - Separate upper/lower body into different meshes
5. **Prioritize** - Keep toggleable clothing, make others permanent

---

### Q: Does this work with blend shapes?

**A**: **Yes!**

**Mesh Deletion mode**:
- Blend shapes are preserved
- Only affects vertices that are deleted
- Blend shape deltas updated correctly

**UDIM Discard mode**:
- Blend shapes work normally
- UDIM only affects visibility
- No blend shape modifications needed

---

### Q: Can I use this on Quest avatars?

**A**: **Yes**, but with considerations:

**Mesh Deletion mode**: ✓ **Recommended for Quest**
- Works on any platform
- Reduces poly count (helps performance)
- No shader dependencies

**UDIM Discard mode**: ⚠️ **Check shader compatibility**
- Poiyomi: Check Quest-compatible version
- FastFur: May not work on Quest
- Verify shader works on Quest before using

---

## Examples

Real-world configuration examples for common scenarios.

---

### Example 1: Simple T-Shirt (Mesh Deletion)

**Scenario**: Basic t-shirt that's always worn, want to optimize performance.

**Configuration**:
```yaml
Target Meshes:
  Body Mesh: Body
  Clothing Mesh: TShirt

Detection Settings:
  Detection Method: Hybrid
  Safety Margin: 0.003
  Proximity Threshold: 0.02

Application:
  Application Mode: Mesh Deletion
  
Advanced Options:
  (all defaults)
```

**Result**:
- Torso vertices permanently deleted
- ~500-800 triangles saved
- Better avatar performance rank
- Works with any shader
- Build time: ~2 seconds

---

### Example 2: Toggleable Jacket (UDIM)

**Scenario**: Jacket with menu toggle for on/off control.

**Configuration**:
```yaml
Target Meshes:
  Body Mesh: Body (with Poiyomi Toon Shader)
  Clothing Mesh: Jacket

Detection Settings:
  Detection Method: Smart
  Safety Margin: 0.003
  Smart Detection:
    Ray Directions: 32
    Occlusion Threshold: 0.7
    Use Normals: true

Application:
  Application Mode: UDIM Discard
  UDIM Settings:
    UV Channel: 1
    Row: 1
    Column: 0

Toggle Settings:
  Create Toggle: true
  Toggle Type: ObjectToggle
  Menu Path: "Clothing/Jacket"
  Synced: false
  Saved: true
  Default ON: true
```

**Result**:
- Toggleable jacket in expression menu
- Body hiding automatically coordinated with jacket toggle
- ~1,200 body vertices hidden when jacket is ON
- Build time: ~8 seconds (Smart detection)

---

### Example 3: Three-Piece Outfit (Multi-Clothing)

**Scenario**: Complete outfit with underwear, dress, and jacket - all toggleable independently.

#### Piece 1: Underwear
```yaml
Body Mesh: Body (shared)
Clothing Mesh: Underwear
Detection Method: Smart
Application Mode: UDIM Discard
UDIM: Row 1, Col 0 (auto-assigned)
Toggle: "Outfits/Underwear"
Optimize Tile Usage: true
Saved: true
```

#### Piece 2: Dress
```yaml
Body Mesh: Body (shared)
Clothing Mesh: Dress
Detection Method: Smart
Application Mode: UDIM Discard
UDIM: Row 1, Col 1 (auto-assigned)
Toggle: "Outfits/Dress"
Optimize Tile Usage: true
Saved: true
```

#### Piece 3: Jacket
```yaml
Body Mesh: Body (shared)
Clothing Mesh: Jacket
Detection Method: Smart
Application Mode: UDIM Discard
UDIM: Row 1, Col 2 (auto-assigned)
Toggle: "Outfits/Jacket"
Optimize Tile Usage: true
Saved: true
```

**Automatic Coordination**:
```
Individual tiles assigned:
  - Underwear: (1,0)
  - Dress: (1,1)
  - Jacket: (1,2)

Overlap detection:
  - Underwear + Dress: 245 shared vertices
  - Dress + Jacket: 189 shared vertices
  
With optimization:
  - Underwear 98% covered by dress → skip overlap tile
  - Final tiles used: 5 (instead of 7)
```

**Result**:
- Three independent toggles in expression menu
- All combinations work correctly
- Optimized tile usage saves 2 tiles
- Total build time: ~18 seconds

---

### Example 4: Symmetric Skirt

**Scenario**: Symmetric skirt where both sides should hide identically.

**Configuration**:
```yaml
Target Meshes:
  Body Mesh: Body
  Clothing Mesh: Skirt

Detection Settings:
  Detection Method: Hybrid
  Safety Margin: 0.005
  Proximity Threshold: 0.025

Application:
  Application Mode: Mesh Deletion

Advanced Options:
  Mirror Symmetry: true
```

**Result**:
- Detection automatically mirrored across X-axis
- Left and right leg hiding is perfectly symmetric
- ~600 vertices hidden total
- Build time: ~3 seconds

---

### Example 5: Manual Mask (Custom Pattern)

**Scenario**: Custom body hiding pattern for artistic effect.

**Setup Process**:
1. Export body mesh UVs as template image
2. In Photoshop/GIMP: Paint white (#FFFFFF) where body should hide
3. Save as PNG texture
4. Import to Unity

**Configuration**:
```yaml
Target Meshes:
  Body Mesh: Body
  Clothing Mesh: (none - not needed for Manual)

Detection Settings:
  Detection Method: Manual
  Manual Mask: CustomBodyMask.png
  Manual Mask Threshold: 0.5

Application:
  Application Mode: Mesh Deletion
```

**Mask Texture**:
```
White (#FFFFFF) = Hide body
Black (#000000) = Keep body visible
Gray = Depends on threshold setting
```

**Result**:
- Precise control over hidden regions
- Artistic/custom patterns possible
- Very fast detection (<100ms)
- Reusable for multiple builds
- Perfect for repeated prototyping

---

### Example 6: Tight Bodysuit (Raycast)

**Scenario**: Skin-tight bodysuit that follows body contours closely.

**Configuration**:
```yaml
Target Meshes:
  Body Mesh: Body
  Clothing Mesh: Bodysuit

Detection Settings:
  Detection Method: Raycast
  Safety Margin: 0.001 (minimal)
  Raycast Distance: 0.05

Application:
  Application Mode: UDIM Discard
  UDIM: Row 1, Col 0

Toggle Settings:
  Create Toggle: true
  Menu Path: "Clothing/Bodysuit"
  Saved: true
```

**Why Raycast?**
- Tight clothing = body very close to clothing surface
- Raycast is fastest for tight fits
- Less prone to false positives than Proximity
- GPU-accelerated for speed

**Result**:
- ~2,500 body vertices hidden
- Clean edges with minimal safety margin
- Build time: ~2 seconds (GPU raycast)

---

### Example 7: Loose Hoodie with Blend Shapes

**Scenario**: Hoodie with hood-up/hood-down blend shape animation.

**Setup**:
1. Add VRCFury Toggle component to hoodie
2. Configure toggle with blend shape animations
3. Add Auto Body Hider component (detects existing toggle)

**Auto Body Hider Configuration**:
```yaml
Target Meshes:
  Body Mesh: Body
  Clothing Mesh: Hoodie

Detection Settings:
  Detection Method: Smart
  Smart Ray Directions: 32
  Occlusion Threshold: 0.7

Application:
  Application Mode: UDIM Discard
  UDIM: Row 1, Col 0

Toggle Settings:
  Create Toggle: false  (using existing VRCFury Toggle)
```

**VRCFury Toggle Actions**:
```
1. Toggle hoodie GameObject (manual setup)
2. Animate hood blend shape 0→100 (manual setup)
3. Hide body vertices (Auto Body Hider adds this)
```

**Result**:
- Single toggle controls hoodie visibility AND body hiding
- Blend shape animation works normally
- Body hiding automatically synchronized

---

## For the Nerds

> **Deep technical dive into Auto Body Hider's internals, algorithms, and implementation details.**

This section is for developers, technical users, and anyone who wants to understand how Auto Body Hider works under the hood. We'll cover system architecture, algorithms, performance characteristics, and implementation details.

---

### System Architecture

The Auto Body Hider system consists of three main components working together during the avatar build process:

| Component | Role | Execution Order |
|-----------|------|----------------|
| **AutoBodyHiderData** | Runtime data component (user-facing) | N/A (data only) |
| **AutoBodyHiderCoordinator** | UDIM tile assignment and conflict resolution | First (callbackOrder: int.MinValue + 99) |
| **AutoBodyHiderProcessor** | Detection, processing, material config, toggles | Second (callbackOrder: int.MinValue + 100) |

#### Processing Pipeline

```
Build Starts
    ↓
AutoBodyHiderCoordinator (callbackOrder: int.MinValue + 99)
    ↓ Groups components by body mesh
    ↓ Assigns unique UDIM tiles
    ↓ Prepares for overlap detection
    ↓
AutoBodyHiderProcessor (callbackOrder: int.MinValue + 100)
    ↓ Detects hidden vertices for each clothing
    ↓ Sorts by coverage (if optimization enabled)
    ↓ Detects actual overlaps
    ↓ Merges UDIM discards OR applies mesh deletion
    ↓ Configures materials
    ↓ Creates toggles
    ↓
VRCFury Processors (run later)
    ↓ Process armature links
    ↓ Process toggles
    ↓ Build animator controllers
```

---

### UDIM Tile Coordinate System

Understanding how UDIM tiles work in Poiyomi and FastFur shaders.

#### Tile Grid Layout

**Tile Grid** (Poiyomi/FastFur):
```
    Column 0    Column 1    Column 2    Column 3
Row 0  (0,0)      (0,1)       (0,2)       (0,3)    ← Avoid Row 0
Row 1  (1,0)      (1,1)       (1,2)       (1,3)    ← Recommended start
Row 2  (2,0)      (2,1)       (2,2)       (2,3)
Row 3  (3,0)      (3,1)       (3,2)       (3,3)    ← Safest: (3,3)
```

**UV Offset Calculation**:
```csharp
float uOffset = column;
float vOffset = row;

uv1[i] = new Vector2(uv1[i].x + uOffset, uv1[i].y + vOffset);
```

**Example**:
```
Original UV0: (0.5, 0.3)  - Texture coordinates
Tile (1, 2):
  uOffset = 2
  vOffset = 1
Result UV1: (2.5, 1.3)  - Discard coordinates

Shader checks:
  Is UV1.x in range [2.0, 3.0]? Yes
  Is UV1.y in range [1.0, 2.0]? Yes
  Tile (1,2) is active? Yes
  → Discard this vertex
```

**Why avoid Row 0?**
```
UV0 range: [0, 1] - Main texture
Row 0, Col 0: UV1 range [0, 1] - Overlaps with main texture
Row 1+: UV1 range [1+, 2+] - No overlap
```

---

### Multi-UDIM Coordination Algorithm

The algorithm that manages multiple clothing pieces and their UDIM tiles.

**Implementation File**: `Editor/Components/Processors/AutoBodyHiderCoordinator.cs`

#### Phase 1: Tile Assignment (Coordinator)
```csharp
foreach (var data in group.clothingPieces)
{
    var tile = (data.udimDiscardRow, data.udimDiscardColumn);
    
    if (usedTiles.Contains(tile))
    {
        // Conflict - auto-assign new tile
        while (usedTiles.Contains((nextRow, nextCol)))
        {
            nextCol++;
            if (nextCol >= 4) { nextCol = 0; nextRow++; }
            if (nextRow >= 4) { /* Error - out of tiles */ break; }
        }
        tile = (nextRow, nextCol);
    }
    
    usedTiles.Add(tile);
    group.assignedTiles[data] = tile;
}
```

#### Phase 2: Overlap Detection (Processor)
```csharp
for (each clothing pair i, j)
{
    var hidden1 = hiddenVerticesMap[clothing_i];
    var hidden2 = hiddenVerticesMap[clothing_j];
    
    // Count shared vertices
    int sharedCount = 0;
    for (int v = 0; v < vertexCount; v++)
    {
        if (hidden1[v] && hidden2[v])
            sharedCount++;
    }
    
    if (sharedCount > 0)
    {
        // Create overlap tile
        allocate_next_available_tile();
        overlapRegions.Add(new Overlap(clothing_i, clothing_j, tile));
    }
}
```

#### Phase 3: UV Assignment (Processor)
```csharp
for (int v = 0; v < vertexCount; v++)
{
    int coverCount = 0;
    List<Clothing> owners = [];
    
    // Which clothing pieces hide this vertex?
    foreach (var clothing in allClothing)
    {
        if (hiddenVertices[clothing][v])
        {
            owners.Add(clothing);
            coverCount++;
        }
    }
    
    if (coverCount == 0)
    {
        // Not covered - leave in UV0 space
        continue;
    }
    else if (coverCount == 1)
    {
        // Single clothing - use its individual tile
        uv1[v] = uv0[v] + offset(owners[0].tile);
    }
    else
    {
        // Multiple clothing - use overlap tile
        var overlap = FindOverlap(owners);
        uv1[v] = uv0[v] + offset(overlap.tile);
    }
}
```

---

### Optimization Algorithm

How tile optimization reduces UDIM tile usage for layered clothing.

#### Coverage-Based Sorting
```csharp
// Sort clothing by coverage (descending)
validComponents = validComponents
    .OrderByDescending(c => hiddenVertexCount[c])
    .ToList();

// Process largest first
// Claim vertices for larger pieces
// Skip overlap tiles when smaller piece has no toggle and is 95%+ covered
```

#### Optimization Decision Logic
```csharp
if (!smallerPiece.createToggle)
{
    float coverageRatio = sharedVertices / smallerPieceTotalCoverage;
    
    if (coverageRatio >= 0.95f)
    {
        // Skip overlap tile
        // Smaller piece fully covered by larger piece
        // Smaller piece has no toggle, so overlap not needed
        continue;
    }
}
```

#### Example Scenario
```
Clothing A (underwear): 1000 vertices hidden, no toggle
Clothing B (dress): 2000 vertices hidden, has toggle
Shared vertices: 980 (98% of underwear)

Coverage ratio: 980/1000 = 0.98 (98%)
Optimization: SKIP overlap tile
Result: Dress tile handles both regions
```

---

### Detection Algorithm Details

Deep dive into detection algorithms and their implementations.

#### Smart Detection (GPU)

The most accurate detection method using multi-directional raycasting.

##### Fibonacci Sphere Ray Distribution
```csharp
Vector3[] GenerateFibonacciSphere(int samples)
{
    Vector3[] points = new Vector3[samples];
    float phi = Mathf.PI * (3f - Mathf.Sqrt(5f)); // Golden angle
    
    for (int i = 0; i < samples; i++)
    {
        float y = 1f - (i / (float)(samples - 1)) * 2f;
        float radius = Mathf.Sqrt(1f - y * y);
        float theta = phi * i;
        
        float x = Mathf.Cos(theta) * radius;
        float z = Mathf.Sin(theta) * radius;
        
        points[i] = new Vector3(x, y, z).normalized;
    }
    
    return points;
}
```

**Provides evenly distributed rays on a sphere** - better coverage than random or grid patterns.

##### Compute Shader Implementation

**File**: `VertexRaycastShader.compute`
```hlsl
[numthreads(64, 1, 1)]
void CSSmartRaycast(uint3 id : SV_DispatchThreadID)
{
    uint index = id.x;
    float3 worldPos = BodyVertices[index];
    float3 worldNormal = BodyNormals[index];
    float3 rayStart = worldPos + worldNormal * RayOffset;
    
    int occludedCount = 0;
    int validDirections = 0;
    
    for (int dirIdx = 0; dirIdx < DirectionCount; dirIdx++)
    {
        float3 direction = TestDirections[dirIdx];
        
        if (UseNormals == 1)
        {
            if (dot(direction, worldNormal) < -0.1) continue;
        }
        
        validDirections++;
        
        // Cast ray and check intersection
        if (RayHitsClothing(rayStart, direction, RaycastDistance))
        {
            occludedCount++;
        }
    }
    
    float occlusionPercentage = (float)occludedCount / (float)validDirections;
    Results[index] = (occlusionPercentage >= OcclusionThreshold) ? 1 : 0;
}
```

##### GPU Buffer Sizes
```
BodyVertices: n × 12 bytes (float3)
BodyNormals: n × 12 bytes (float3)
ClothingTriangles: t × 36 bytes (9 floats)
TestDirections: d × 12 bytes (float3)
Results: n × 4 bytes (int)

Total: n×28 + t×36 + d×12 bytes

Example (10k verts, 5k tris, 32 dirs):
= 10000×28 + 5000×36 + 32×12
= 280KB + 180KB + 384 bytes
= ~460KB GPU memory
```

---

### Material Property Animation

How body hiding toggles are implemented using material property animations.

#### Toggle Animation Format
```csharp
AnimationClip clip = new AnimationClip();
clip.name = "UDIM_Discard_Toggle_Clothing";

string rendererPath = "Armature/Body";  // Path to body renderer
string propertyName = "material._UDIMDiscardRow1_0";  // Tile property

EditorCurveBinding binding = EditorCurveBinding.FloatCurve(
    rendererPath,
    typeof(SkinnedMeshRenderer),
    propertyName
);

AnimationCurve curve = new AnimationCurve();
curve.AddKey(0f, 1f);  // At time 0, set to 1 (discard ON)
curve.AddKey(1f/60f, 1f);  // At time 1/60s, set to 1

AnimationUtility.SetEditorCurve(clip, binding, curve);
```

#### Material Base State
```csharp
material.SetFloat("_UDIMDiscardRow1_0", 0f);  // Base = OFF (body visible)
material.SetOverrideTag("_UDIMDiscardRow1_0Animated", "1");  // Mark as animated
```

#### Toggle Behavior
```
Toggle OFF:
  → Material base value used (0)
  → Tile discard OFF
  → Body visible
  
Toggle ON:
  → Animation plays
  → Property set to 1
  → Tile discard ON
  → Body hidden
```

---

### Reflection-Based VRCFury Integration

How Auto Body Hider integrates with VRCFury toggles using C# reflection.

#### Why Reflection?

VRCFury's toggle model is internal and not exposed via public API. We use reflection to access and modify toggle internals:

```csharp
var toggle = FuryComponents.CreateToggle(gameObject);

// Access internal model via reflection
var toggleType = toggle.GetType();
var cField = toggleType.GetField("c", BindingFlags.NonPublic | BindingFlags.Instance);
var toggleModel = cField.GetValue(toggle);

// Set advanced properties
var holdButtonField = toggleModel.GetType().GetField("holdButton", BindingFlags.Public | BindingFlags.Instance);
holdButtonField.SetValue(toggleModel, true);

// Add animation to state.actions
var stateField = toggleModel.GetType().GetField("state", BindingFlags.Public | BindingFlags.Instance);
var state = stateField.GetValue(toggleModel);
var actionsField = state.GetType().GetField("actions", BindingFlags.Public | BindingFlags.Instance);
var actionsList = actionsField.GetValue(state) as IList;

// Create AnimationClipAction
var animActionType = Type.GetType("VF.Model.StateAction.AnimationClipAction, VRCFury");
var animAction = Activator.CreateInstance(animActionType);
var motionField = animActionType.GetField("motion", BindingFlags.Public | BindingFlags.Instance);
motionField.SetValue(animAction, animationClip);

actionsList.Add(animAction);
```

---

### Detection Cache Implementation

SHA-256 based caching system for detection results.

**Implementation File**: `Editor/MeshUtils/DetectionCache.cs`

#### Hash Generation
```csharp
private static string GenerateHash(AutoBodyHiderData data, Mesh bodyMesh, Mesh clothingMesh)
{
    using (var sha256 = SHA256.Create())
    {
        var sb = new StringBuilder();
        
        sb.Append(GetMeshHash(bodyMesh));  // Mesh GUID + vertex count
        sb.Append(GetMeshHash(clothingMesh));
        sb.Append(data.detectionMethod.ToString());
        sb.Append(data.safetyMargin.ToString("F4"));
        sb.Append(data.proximityThreshold.ToString("F4"));
        // ... all detection parameters ...
        sb.Append(bodyTransform.position.ToString());
        sb.Append(bodyTransform.rotation.ToString());
        // ... transform data ...
        
        byte[] inputBytes = Encoding.UTF8.GetBytes(sb.ToString());
        byte[] hashBytes = sha256.ComputeHash(inputBytes);
        
        return BitConverter.ToString(hashBytes).Replace("-", "").ToLower();
    }
}
```

#### Cache Entry Structure
```csharp
class CachedDetectionResult
{
    string hash;              // SHA-256 hash (64 chars)
    bool[] hiddenVertices;    // Detection result
    int hiddenCount;          // Count for quick reference
    long timestamp;           // For auto-cleanup
}
```

**Cache Storage**: JSON serialization to `Library/YUCPCache/BodyHiderCache.json`

---

### Symmetry Mirror Algorithm

How detection results are mirrored across the X-axis for symmetric clothing.

```csharp
private bool[] ApplySymmetryMirror(bool[] hiddenVertices, Vector3[] vertices)
{
    bool[] result = new bool[hiddenVertices.Length];
    Array.Copy(hiddenVertices, result, hiddenVertices.Length);
    
    for (int i = 0; i < hiddenVertices.Length; i++)
    {
        if (hiddenVertices[i])
        {
            // Find mirror vertex (flip X)
            Vector3 targetPos = new Vector3(-vertices[i].x, vertices[i].y, vertices[i].z);
            
            float minDistance = float.MaxValue;
            int closestIndex = -1;
            
            for (int j = 0; j < vertices.Length; j++)
            {
                float dist = Vector3.Distance(vertices[j], targetPos);
                if (dist < minDistance && dist < 0.001f)  // 1mm tolerance
                {
                    minDistance = dist;
                    closestIndex = j;
                }
            }
            
            if (closestIndex >= 0)
                result[closestIndex] = true;  // Hide mirror vertex too
        }
    }
    
    return result;
}
```

**Time complexity**: O(n²) where n = vertex count  
**Tolerance**: 1mm (0.001m) - vertices must be very close to mirror position

---

### Safety Margin Algorithm

How safety margin creates a buffer zone around detection boundaries.

```csharp
private bool[] ApplySafetyMargin(bool[] hiddenVertices, Vector3[] vertices, AutoBodyHiderData data)
{
    bool[] shrunk = new bool[hiddenVertices.Length];
    Array.Copy(hiddenVertices, shrunk, hiddenVertices.Length);
    
    // Convert to world space
    Vector3[] worldVertices = new Vector3[vertices.Length];
    for (int i = 0; i < vertices.Length; i++)
    {
        worldVertices[i] = data.targetBodyMesh.transform.TransformPoint(vertices[i]);
    }
    
    // Shrink hidden region
    for (int i = 0; i < vertices.Length; i++)
    {
        if (hiddenVertices[i])
        {
            bool isNearEdge = false;
            
            // Check if near any visible vertex
            for (int j = 0; j < vertices.Length; j++)
            {
                if (!hiddenVertices[j])  // j is visible
                {
                    float dist = Vector3.Distance(worldVertices[i], worldVertices[j]);
                    if (dist < data.safetyMargin)
                    {
                        isNearEdge = true;
                        break;
                    }
                }
            }
            
            if (isNearEdge)
                shrunk[i] = false;  // Keep this vertex (too close to edge)
        }
    }
    
    return shrunk;
}
```

**Effect**: Creates a buffer zone around detection boundaries  
**Time complexity**: O(n²) worst case (all vertices hidden)  
**Typical**: O(n × e) where e = edge vertices (~10-20% of hidden region)

---

### Mesh Deletion Implementation

How hidden vertices are permanently deleted from the mesh.

**Implementation File**: `Editor/MeshUtils/MeshDeleter.cs`

```csharp
public static Mesh DeleteHiddenVertices(Mesh originalMesh, bool[] hiddenVertices)
{
    // Create vertex mapping (old → new indices)
    int[] vertexMapping = new int[hiddenVertices.Length];
    int newVertexCount = 0;
    
    for (int i = 0; i < hiddenVertices.Length; i++)
    {
        if (!hiddenVertices[i])
        {
            vertexMapping[i] = newVertexCount;
            newVertexCount++;
        }
        else
        {
            vertexMapping[i] = -1;  // Deleted
        }
    }
    
    // Copy all vertex data (positions, normals, UVs, bone weights, etc.)
    CopyVertexData(source, dest, hiddenVertices, vertexMapping, newVertexCount);
    
    // Rebuild triangles (skip triangles with any hidden vertex)
    for (each triangle)
    {
        if (all vertices visible)
        {
            newIndices.Add(vertexMapping[v0]);
            newIndices.Add(vertexMapping[v1]);
            newIndices.Add(vertexMapping[v2]);
        }
    }
    
    // Copy blend shapes
    CopyBlendShapes(source, dest, hiddenVertices, vertexMapping, newVertexCount);
    
    return newMesh;
}
```

#### Mesh Data Preserved

The deletion process preserves all mesh data for remaining vertices:
- Vertex positions, normals, tangents, colors
- All UV channels (UV0, UV1, UV2, UV3)
- Bone weights and bind poses
- Blend shapes (all frames)
- Submeshes and materials

---

### Source Code Reference

Complete reference to all implementation files and their purposes.

#### Runtime Component (334 lines)
```
Runtime/Components/Data/AutoBodyHiderData.cs
```
User-facing component with all settings and configuration.

#### Coordinator (254 lines)
```
Editor/Components/Processors/AutoBodyHiderCoordinator.cs
```
**Responsibilities**:
- UDIM tile assignment
- Conflict resolution
- Overlap preparation

#### Processor (1600 lines)
```
Editor/Components/Processors/AutoBodyHiderProcessor.cs
```
**Responsibilities**:
- Detection execution
- UDIM merging
- Material configuration
- Toggle creation

#### Detection Algorithms (617 lines)
```
Editor/MeshUtils/VertexDetection.cs
```
**Implements**:
- All 5 detection methods
- GPU/CPU fallback logic

#### GPU Shaders (227 lines)
```
Editor/MeshUtils/VertexRaycastShader.compute
```
**Kernels**:
- CSRaycast - Single direction raycast
- CSSmartRaycast - Multi-directional raycast

#### Mesh Utilities

| File | Lines | Purpose |
|------|-------|---------|
| `UDIMManipulator.cs` | 193 | UDIM coordinate operations |
| `MeshDeleter.cs` | 270 | Mesh deletion implementation |
| `DetectionCache.cs` | 280 | SHA-256 caching system |
| `GPURaycast.cs` | 324 | GPU raycast wrapper and fallback |

#### Custom Inspector (853 lines)
```
Editor/Header/AutoBodyHiderDataEditor.cs
```
**Features**:
- Preview generation UI
- Real-time updates
- Settings validation
- VRCFury integration UI

---

### Performance Benchmarks

Real-world performance measurements for typical avatar configurations.

#### Detection Times

**Test Configuration**: 10,000 body vertices, 5,000 clothing triangles
```
Proximity:  ~500ms (CPU only)
Raycast:    ~200ms (GPU) / ~2s (CPU)
Hybrid:     ~150ms (GPU) / ~1.5s (CPU)
Smart:      ~1.5s (GPU, 32 rays) / ~30s (CPU)
Manual:     ~50ms (texture lookup)
```

#### UDIM Processing Times

**Test Configuration**: 3 clothing pieces with optimization enabled
```
Detection (cached): ~50ms
Coordination:       ~5ms
UV merging:         ~10ms
Material config:    ~5ms
Toggle creation:    ~10ms
─────────────────────────
Total:              ~80ms
```

#### Memory Usage

| Component | Memory Usage |
|-----------|--------------|
| **Detection** | n bytes (hiddenVertices boolean array) |
| **Preview** | ~40n bytes (vertices + triangles + faces) |
| **Cache** | ~n bytes compressed (JSON file) |
| **GPU Buffers** | See GPU Buffer Sizes section above |

Where n = number of body vertices

---

## End of Documentation

This documentation covers all aspects of Auto Body Hider from basic usage to advanced technical details. For additional support, consult the source code or contact the developer.

