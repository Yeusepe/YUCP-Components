# YUCP Components Wiki

Welcome to the YUCP Components documentation. This wiki provides comprehensive guides for all components, from quick start tutorials to deep technical details.

## Table of Contents

### Armature Components
These components handle automatic attachment and linking to avatar bones.

- **[Symmetric Armature Auto-Link](Symmetric-Armature-Auto-Link.md)** - Automatically attach objects to left/right body parts with smart side detection
- **[Closest Bone Auto-Link](Closest-Bone-Auto-Link.md)** - Find and attach to the nearest bone, including custom bones like ears and tails
- **[View Position & Head Auto-Link](View-Position-Head-Auto-Link.md)** - Position objects at avatar view position with optional eye alignment

### Mesh Components
These components manipulate meshes for optimized clothing and body hiding.

- **[Auto Body Hider](Auto-Body-Hider.md)** - Automatically hide body parts under clothing with GPU-accelerated detection
- **[Auto UDIM Discard](Auto-UDIM-Discard.md)** (BETA) - Detect UV regions and create UDIM discard toggles automatically
- **[UV Discard Toggle](UV-Discard-Toggle.md)** (BETA) - Manual UDIM discard toggle for clothing/body coordination

### Animation Components
These components generate animations automatically.

- **[Auto Grip Generator](Auto-Grip-Generator.md)** (BETA) - Generate hand grip animations using finger tip positioning

### Input Components
These components handle input mapping and emulation.

- **[Gesture Manager Input Emulator](Gesture-Manager-Input-Emulator.md)** (BETA) - Map keyboard and controller inputs to Gesture Manager parameters

### Developer Tools
Tools for package creators and advanced users.

- **[Package Exporter](Package-Exporter.md)** - Export Unity packages with obfuscation, dependencies, and batch processing
- **[Developer Guide](Developer-Guide.md)** - Create your own YUCP-compatible components

## Quick Reference

### Installation

**Via VCC (Recommended):**
1. Add VPM repository: `http://vpm.yucp.club/index.json`
2. Open your project in VCC
3. Install "YUCP Components" from the package list

**Manual:**
1. Download `.unitypackage` from [Releases](https://github.com/Yeusepe/YUCP-Components/releases)
2. Import into Unity
3. Install VRCFury from https://vrcfury.com/download

### Requirements
- Unity 2022.3.x or later
- VRChat SDK3 Avatars
- VRCFury >= 1.0.0 (auto-installed via VPM)

### Getting Started

1. **Add a component** - Right-click your avatar object → `Add Component` → `YUCP` → Select component
2. **Configure settings** - Set up required references (body mesh, clothing, etc.)
3. **Build avatar** - Components process automatically during build
4. **No extra setup needed** - VRCFury handles all integration

## Component Comparison

### When to Use Each Armature Component

| Component | Best For | Auto-Detects |
|-----------|----------|--------------|
| Symmetric Armature | Symmetric accessories (earrings, knee pads) | Left/Right side |
| Closest Bone | Dynamic accessories (piercings, tails) | Nearest bone |
| View Position | HUD elements, glasses, masks | Eye alignment |

### When to Use Each Body Hiding Method

| Component | Best For | Toggleable | Multi-Clothing |
|-----------|----------|------------|----------------|
| Auto Body Hider | General clothing with automatic detection | Yes | Yes |
| Auto UDIM Discard | Multi-part outfits (detected regions) | Yes | Limited |
| UV Discard Toggle | Manual control, simple outfits | Yes | Manual |

### Detection Method Comparison (Auto Body Hider)

| Method | Speed | Accuracy | Best For |
|--------|-------|----------|----------|
| Raycast | Fast | Good | Tight-fitting clothing |
| Proximity | Very Fast | Fair | Loose clothing, quick previews |
| Hybrid | Medium | Very Good | General purpose |
| Smart | Slow | Excellent | Complex multi-layer outfits |
| Manual | Instant | Perfect* | Precise control (*when mask is correct) |

## Common Workflows

### Basic Clothing Setup
1. Add clothing to avatar
2. Add `Auto Body Hider` to clothing object
3. Assign Body Mesh and Clothing Mesh
4. Click "Generate Preview" to test
5. Enable "Create Toggle" for menu control
6. Build avatar

### Multi-Layer Outfit Setup
1. Add all clothing pieces to avatar
2. Add `Auto Body Hider` to each piece
3. All pieces reference the same Body Mesh
4. Enable "Optimize Tile Usage" for tile efficiency
5. Components automatically coordinate UDIM tiles
6. Overlap tiles created for layered regions
7. Build avatar

### Custom Attachment Setup
1. Position accessory where you want it
2. Add appropriate attachment component
3. Configure filters if needed (Closest Bone only)
4. Build avatar - component handles the rest

## Performance Tips

- **Use UDIM mode** for toggleable clothing (no vertex deletion)
- **Use Mesh Deletion mode** for permanent clothing (better runtime performance)
- **Enable GPU acceleration** - Automatically used when available
- **Cache detection results** - Automatic caching speeds up rebuilds
- **Optimize tile usage** - Enable for multi-layer outfits to reduce UDIM tiles
- **Proximity detection** - Fastest for preview generation
- **Smart detection** - Most accurate but slower, recommended for final builds

## Beta Components

Components marked as BETA are experimental and may have limitations:

- **Auto Grip Generator** - Grip generation is functional but may need manual adjustments
- **Auto UDIM Discard** - UV region detection works but may need manual tile assignment
- **Gesture Manager Input Emulator** - Requires Game view focus for input detection
- **UV Discard Toggle** - Works well but less automated than Auto Body Hider

## Support & Resources

- **GitHub Issues**: [Report bugs or request features](https://github.com/yucp-club/YUCP-Components/issues)
- **VRCFury Docs**: [VRCFury Documentation](https://vrcfury.com/)
- **VRChat SDK**: [VRChat Creator Docs](https://creators.vrchat.com/)

## Changelog

See [CHANGELOG.md](../CHANGELOG.md) for version history and recent updates.

## License

MIT License - See [LICENSE.md](../LICENSE.md)



