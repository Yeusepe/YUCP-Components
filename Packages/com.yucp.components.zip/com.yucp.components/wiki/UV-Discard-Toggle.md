# UV Discard Toggle

**BETA: Manually controlled UDIM discard toggle for clothing with body mesh coordination.**

## Overview

The UV Discard Toggle component (`UVDiscardToggleData`) merges clothing into the body mesh and creates a UDIM discard toggle. Unlike Auto Body Hider which automatically detects hidden vertices, this component gives you manual control over UDIM tile assignment while still providing automatic mesh merging and toggle creation.

### BETA Status

This component is experimental:
- Manual UDIM configuration required
- Best for simple clothing setups
- Auto Body Hider is recommended for most use cases
- Less automation than Auto Body Hider

### Key Features
- **Manual control** - You specify exactly which UDIM tile to use
- **Mesh merging** - Automatically merges clothing mesh into body mesh
- **Toggle creation** - Creates VRCFury toggle automatically
- **Poiyomi/FastFur support** - Works with both shader systems
- **Parameter control** - Optional global parameter for syncing
- **Flexible toggle options** - Slider, hold button, security, exclusive tags

### Why Use This?

Use UV Discard Toggle when:
- You want precise control over UDIM tiles
- Clothing UVs are already in the discard tile
- Simple clothing setup (1-2 pieces)
- Integrating with custom UDIM systems

Use Auto Body Hider when:
- Automatic detection preferred
- Multiple clothing pieces
- Need detection preview
- Want multi-clothing coordination

## Use Cases

- **Simple clothing** - One-piece outfits with manual UDIM
- **Pre-configured UVs** - Clothing already has UVs in discard tile
- **Custom UDIM systems** - Integration with existing UDIM setups
- **Performance testing** - Bypass automatic detection

## Quick Start

1. **Prepare clothing**: Ensure clothing mesh UVs are set up for UDIM
2. **Add component**: `Add Component → YUCP → UV Discard Toggle`
3. **Assign meshes**:
   - Body Mesh: Avatar body
   - Clothing Mesh: Clothing to merge
4. **Set UDIM tile**:
   - Row: 1-3 (avoid 0)
   - Column: 0-3
5. **Set menu path**: "Clothing/My Outfit"
6. **Build avatar**

[Image: UV Discard Toggle Inspector]

## Component Settings

### Target Meshes

#### Target Body Mesh
**Type**: SkinnedMeshRenderer  
**Required**: Yes  
**Description**: The body mesh to merge clothing into.

#### Clothing Mesh
**Type**: SkinnedMeshRenderer  
**Required**: Yes  
**Description**: The clothing mesh to be merged and toggled.

### UDIM Discard Settings

#### UV Channel
**Type**: Int  
**Default**: 1  
**Description**: Which UV channel to use for UDIM discard.

UV1 is standard for discard logic (UV0 for textures).

#### Row / Column
**Type**: Int  
**Range**: 0 - 3  
**Default**: Row 3, Column 3  
**Description**: Which UDIM tile to use.

Avoid Row 0 (especially 0,0). Safest: (3,3).

### VRCFury Toggle Settings

#### Menu Path
**Type**: String  
**Required**: Yes (or Global Parameter)  
**Description**: Menu path for the toggle.

#### Global Parameter
**Type**: String  
**Default**: ""  
**Description**: Optional global parameter name for network sync.

Leave empty for local toggle, or set for synced toggle.

#### Saved / Default On
**Type**: Bool  
**Description**: Save state / Start enabled.

### Advanced Toggle Options (Foldout)

- **Use Slider**: Slider instead of button
- **Hold Button**: Hold instead of latch
- **Security Enabled**: Prevent others from toggling
- **Exclusive Tags**: Mutual exclusivity
- **Custom Icon**: Menu icon texture

### Debug Settings

#### Debug Save Animation
**Type**: Bool  
**Default**: false  
**Description**: Save generated animation to Assets/Generated/ for debugging.

## Step-by-Step Tutorial

### Tutorial: Simple Jacket with Manual UDIM

#### Step 1: Prepare Jacket
1. Import jacket with clothing mesh already positioned
2. Ensure jacket's UVs are in UV0 (texture UVs)

[Image: Jacket mesh on avatar]

#### Step 2: Add Component
1. Select jacket GameObject
2. `Add Component → YUCP → UV Discard Toggle`

#### Step 3: Assign Meshes
```
Target Body Mesh: Body (avatar body renderer)
Clothing Mesh: Jacket (jacket renderer)
```

[Image: Both meshes assigned in Inspector]

#### Step 4: Configure UDIM Tile
```
UV Channel: 1 (UV1 for discard)
Row: 1
Column: 0
```

This clothing will use UDIM tile (1,0).

#### Step 5: Configure Toggle
```
Menu Path: Clothing/Jacket
Global Parameter: (empty - local toggle)
Saved: true
Default On: false
```

[Image: Toggle settings configured]

#### Step 6: Build
1. Build avatar
2. Component:
   - Merges jacket mesh into body mesh
   - Sets up UV1 with UDIM offset
   - Configures body material for UDIM discard
   - Creates VRCFury toggle

3. Test in-game

## Advanced Features

### Global Parameter Mode

**Without menu path** (parameter only):
```
Menu Path: (empty)
Global Parameter: MyJacketToggle
```

Creates synced parameter without menu item. Control via OSC or other systems.

**With menu path** (synced toggle):
```
Menu Path: Clothing/Jacket
Global Parameter: JacketSync
```

Menu item controls global parameter, synced across players.

### Integration with Auto Body Hider

If clothing has Auto Body Hider component:
```
Clothing GameObject:
├── SkinnedMeshRenderer
├── AutoBodyHiderData (detects hidden body vertices)
└── UVDiscardToggleData (creates toggle)
```

Both components work together:
- Auto Body Hider: Handles body vertex hiding
- UV Discard Toggle: Handles toggle creation
- Use same UDIM tile on both

### Mesh Merging Process

```csharp
// Get mesh data
Vector3[] bodyVertices = bodyMesh.vertices;
Vector3[] clothingVertices = clothingMesh.vertices;

// Transform clothing to body's local space
Matrix4x4 clothingToBody = bodyTransform.worldToLocalMatrix * clothingTransform.localToWorldMatrix;
Vector3[] transformedClothingVertices = TransformVertices(clothingVertices, clothingToBody);

// Combine
Vector3[] newVertices = bodyVertices.Concat(transformedClothingVertices).ToArray();

// Create UV1 with UDIM offset for clothing vertices
Vector2[] newUV1 = new Vector2[newVertices.Length];
for (int i = bodyVertices.Length; i < newVertices.Length; i++)
{
    newUV1[i] = new Vector2(uv0[i].x + column, uv0[i].y + row);
}

// Merge submeshes and materials
combinedMesh.vertices = newVertices;
combinedMesh.SetUVs(1, newUV1);
```

**Result**: Single mesh with clothing vertices in UDIM tile.

## Troubleshooting

### Merged Mesh Looks Wrong

**Problem**: After build, combined mesh is deformed.

**Solutions**:
1. Check bone weights are correct
2. Verify clothing and body use same armature
3. Ensure transforms are applied correctly in 3D software

### Toggle Doesn't Hide Clothing

**Problem**: Toggle exists but clothing always visible.

**Solutions**:
1. Check body has Poiyomi/FastFur shader
2. Verify UDIM tile is configured in material
3. Check UV Channel matches (usually 1)
4. Review Console for material errors

### Material Not Found Error

**Problem**: No Poiyomi or FastFur material found.

**Solution**: Body mesh must have a material with UDIM support. Use standard material or add Poiyomi/FastFur.

## FAQ

### Q: When should I use this vs Auto Body Hider?
**A**: Use Auto Body Hider for most cases. Use UV Discard Toggle only when you need manual UDIM control or pre-configured UV setups.

### Q: Can I use this without merging meshes?
**A**: No, this component specifically merges clothing into body for UDIM-based toggling.

### Q: Does this work with multiple clothing pieces?
**A**: Yes, but each piece needs its own UDIM tile. Auto Body Hider handles multi-clothing better with automatic coordination.

### Q: Can I control which parts of clothing are in the tile?
**A**: Yes - set up your clothing mesh's UV1 manually before build, or use Auto UDIM Discard for automatic region detection.

## For the Nerds

### Technical Architecture

**Component**: `Runtime/Components/Data/UVDiscardToggleData.cs` (99 lines)  
**Processor**: `Editor/Components/Processors/UVDiscardToggleProcessor.cs` (397 lines)  
**Inspector**: `Editor/Header/UVDiscardToggleDataEditor.cs` (211 lines)

### Processing Pipeline

```
AutoUDIMDiscardProcessor (callbackOrder: int.MinValue + 102)
    ↓ Validate meshes
    ↓ Merge clothing into body
    ↓ Apply UDIM offset to clothing UVs
    ↓ Configure body material
    ↓ Create VRCFury toggle
```

### Mesh Merging Implementation

```csharp
// Transform matrix: clothing local → body local
Matrix4x4 clothingToBody = targetBodyMesh.transform.worldToLocalMatrix * 
                           clothingMesh.transform.localToWorldMatrix;

// Transform vertices
for (int i = 0; i < clothingVertices.Length; i++)
{
    transformedVertices[i] = clothingToBody.MultiplyPoint3x4(clothingVertices[i]);
    transformedNormals[i] = clothingToBody.MultiplyVector(clothingNormals[i]).normalized;
}

// Offset triangles
for (int j = 0; j < clothingTriangles.Length; j++)
{
    transformedTriangles[j] = clothingTriangles[j] + bodyVertexCount;
}

// Combine bone weights
combinedWeights = bodyWeights.Concat(clothingWeights).ToArray();
```

**Preserves**:
- All vertex attributes
- Bone weights
- Submeshes (combined material array)
- Blend shapes (if present)

### Material Configuration

```csharp
materialCopy.SetFloat("_EnableUDIMDiscardOptions", 1f);

if (shaderName.Contains("poiyomi"))
    materialCopy.EnableKeyword("POI_UDIMDISCARD");
else if (shaderName.Contains("fastfur"))
{
    materialCopy.EnableKeyword("WFFS_FEATURES_UVDISCARD");
    materialCopy.SetFloat("_WFFS_FEATURES_UVDISCARD", 1f);
}

materialCopy.SetFloat("_UDIMDiscardMode", 0f);
materialCopy.SetFloat("_UDIMDiscardUV", udimUVChannel);

string tileProperty = $"_UDIMDiscardRow{row}_{column}";
materialCopy.SetFloat(tileProperty, 0f);  // Base OFF
materialCopy.SetOverrideTag(tileProperty + "Animated", "1");
```

### Animation Clip Format

```csharp
AnimationClip clip = new AnimationClip();
string rendererPath = GetRelativePath(bodyRenderer, avatarRoot);
string tileProperty = $"_UDIMDiscardRow{row}_{column}";
string propertyPath = $"material.{tileProperty}";

EditorCurveBinding binding = EditorCurveBinding.FloatCurve(
    rendererPath,
    typeof(SkinnedMeshRenderer),
    propertyPath
);

AnimationCurve curve = AnimationCurve.Constant(0f, 1f/60f, 1f);
AnimationUtility.SetEditorCurve(clip, binding, curve);
```

**Property path format**: `material._UDIMDiscardRow{row}_{col}`  
**Value**: 1.0 = discard ON (hide), 0.0 = discard OFF (visible)



