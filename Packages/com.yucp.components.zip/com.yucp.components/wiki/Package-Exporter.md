# Package Exporter

> **Complete Unity package export system with ConfuserEx obfuscation, dependency management, and batch processing.**

---

## Table of Contents

- [Overview](#overview)
- [Quick Start](#quick-start)
- [Export Profile Settings](#export-profile-settings)
- [Step-by-Step Tutorials](#step-by-step-tutorial)
- [Advanced Features](#advanced-features)
- [Exporter Window UI](#exporter-window-ui)
- [Troubleshooting](#troubleshooting)
- [FAQ](#faq)
- [For the Nerds](#for-the-nerds)

---

## Overview

The YUCP Package Exporter is a complete system for creating professional Unity packages. It provides export profiles, automatic dependency management, ConfuserEx obfuscation, folder filtering, package icon injection, and batch export capabilities. Perfect for package creators who want a streamlined, reproducible export workflow.

### Key Features

| Feature | Description |
|---------|-------------|
| **Export Profiles** | Reusable configurations saved as ScriptableObjects |
| **ConfuserEx Obfuscation** | Protect your code with automatic DLL obfuscation |
| **Dependency Management** | Bundle or reference dependencies automatically |
| **Folder Selection** | Choose which folders to include in export |
| **Exclusion Filters** | Exclude files/folders by pattern |
| **Package Icon** | Inject custom icons into packages |
| **Batch Export** | Export multiple profiles at once |
| **VPM Compatibility** | Generate package.json with dependencies |
| **Version Control** | Auto-increment versions, track export count |
| **Direct VPM Installer** | Auto-install VPM dependencies on package import |
| **Smart Bundling** | Bundle dependencies with delayed compilation |
| **Templates** | Example export profiles for quick setup |

### Why Use This?

#### The Problem: Unity's Built-in Export is Limited

- No code obfuscation
- No dependency tracking
- No reusable configurations
- No batch processing
- Manual process every time

#### The Solution: Package Exporter

- One-click export with saved settings
- Automatic code protection
- Dependency auto-detection
- Batch workflows
- Professional package quality

### What Makes It Special

#### Zero-Setup Package Distribution

Export packages that **automatically install their own dependencies**:
- Users import a single `.unitypackage` file
- DirectVpmInstaller prompts to install VPM dependencies
- Everything downloads and configures automatically
- **No VCC (VRChat Creator Companion) required!**

#### Production-Ready Re-Import System

Safe iterative development with robust conflict prevention:
- **Fresh GUID generation** prevents conflicts on re-import
- **Smart file replacement** preserves user modifications
- **Automatic cleanup** removes all orphaned files
- **Version detection** handles upgrades intelligently

#### Intelligent Dependency Bundling

Mix bundled and referenced dependencies intelligently:
- **Smart Bundling** delays compilation with `.yucp_disabled`
- **Repository detection** from VCC settings
- **Hybrid mode** bundles code, references frameworks
- **Zero compilation errors** even with complex dependencies

### Use Cases

| Use Case | Description |
|----------|-------------|
| **Selling Unity Assets** | Protect code with obfuscation before selling |
| **Open-Source Packages** | Manage dependencies and versioning professionally |
| **VRChat Packages** | VPM-compatible exports with proper dependencies |
| **Internal Tools** | Share packages within teams with reproducible configs |
| **Version Management** | Track exports and auto-increment versions |

---

## Quick Start

Get started with Package Exporter in minutes.

### First Time Setup

Follow these steps to create and export your first package:

#### Step 1: Open Package Exporter
- Navigate to `Tools → YUCP → Package Exporter`
- The Package Exporter window opens

#### Step 2: Create Profile
- Click **`Create New Profile`** button
- New profile appears in the left sidebar

#### Step 3: Configure Profile
Set the basic package information:

| Setting | Example Value |
|---------|---------------|
| **Package Name** | "My Package" |
| **Version** | "1.0.0" |
| **Author** | "Your Name" |

#### Step 4: Add Folders
1. Click **`Add Folder`** button
2. Browse to your package folder
3. Select the folder
4. Folder appears in the list

> You can add multiple folders to include different parts of your package.

#### Step 5: Scan Dependencies
- Click **`Scan Dependencies`** button
- All installed packages are detected and listed
- Enable the ones your package needs

#### Step 6: Export
1. Click **`Export Package`** button (bottom of window)
2. Wait for export to complete
3. Package saved to Desktop (or configured export path)

> Your package is now ready to distribute!

---

### Creating an Export Profile

There are two ways to create an export profile:

#### Method 1: Via Assets Menu

1. **Right-click** in Project window
2. Select `Create → YUCP → Export Profile`
3. **Name** the profile
4. **Double-click** to edit in Inspector

> Profiles are saved as ScriptableObject assets in your project.

#### Method 2: Via Exporter Window

1. Open Package Exporter window
2. Click **`Create New Profile`**
3. Profile automatically created in `Assets/ExportProfiles/`

> This method is faster and automatically opens the profile for editing.

---

## Export Profile Settings

Complete reference for all export profile settings.

---

### Package Metadata

#### Package Name
| | |
|---|---|
| **Type** | String |
| **Required** | Yes |
| **Description** | Package file name (without .unitypackage extension) |

This is used as:
- The exported `.unitypackage` filename
- The package.json `name` field (lowercase, dots instead of spaces)

**Example**: "My Avatar Tools" becomes `my.avatar.tools` in package.json

#### Version
| | |
|---|---|
| **Type** | String |
| **Default** | "1.0.0" |
| **Format** | Semantic versioning (major.minor.patch) |

Package version following semantic versioning standards.

> Can auto-increment after exports when **Auto Increment Version** is enabled.

**Valid formats**:
- `1.0.0` - Standard format
- `1.2.3` - Major.Minor.Patch
- `2.0.0-beta` - Pre-release versions

#### Author
| | |
|---|---|
| **Type** | String |
| **Optional** | Yes |

Package author name, used in package.json generation.

#### Description
| | |
|---|---|
| **Type** | String (multiline) |
| **Optional** | Yes |

Package description text, used in package.json generation.

> Provide a clear description of what your package does for users.

---

### Package Icon

#### Icon
| | |
|---|---|
| **Type** | Texture2D (PNG) |
| **Optional** | Yes |
| **Recommended Size** | 256x256 pixels |

Optional PNG icon for the package, injected into .unitypackage for better presentation in Package Manager.

**Requirements**:
- Must be PNG format
- Recommended: 256x256 pixels
- Maximum file size: 1MB

---

### Export Folders

#### Folders to Export
| | |
|---|---|
| **Type** | List of folder paths |
| **Required** | Yes (at least one folder) |

Folder paths to include in the export (relative to project root).

**Examples**:
```
Packages/com.mycompany.mypackage
Assets/MyPackageAssets
Assets/Editor/MyTools
```

**Supported paths**:
- `Packages/` folders (recommended for UPM packages)
- `Assets/` folders (for traditional assets)
- Any project subfolder

#### Add Folder Button
Opens folder browser to select folders to add to the export list.

> **Tip**: You can add multiple folders from different locations in your project.

#### Remove Folder (X button)
Removes the selected folder from the export list.

---

### Unity Export Options

These settings control Unity's built-in export behavior.

#### Include Dependencies
| | |
|---|---|
| **Type** | Bool |
| **Default** | true |

Include dependencies of selected assets automatically.

> Uses Unity's automatic dependency tracking to find and include referenced assets.

**Recommended**: Keep enabled to ensure all necessary files are included.

#### Recurse Folders
| | |
|---|---|
| **Type** | Bool |
| **Default** | true |

Recursively include all files and subfolders in selected folders.

> When enabled, all contents of export folders are included. When disabled, only top-level files are exported.

---

### Exclusion Filters

Control which files and folders are excluded from the export.

#### Exclude File Patterns
| | |
|---|---|
| **Type** | List of strings |
| **Supports** | Wildcards (`*`) |

File patterns to exclude from export. Supports wildcard matching.

**Examples**:
```
*.tmp           # All temporary files
*.log           # All log files
*.meta.bak      # Backup meta files
*~              # Editor backup files
test_*.cs       # Test scripts
```

**Common patterns**:
| Pattern | Matches |
|---------|---------|
| `*.tmp` | All `.tmp` files |
| `*_backup.*` | Files ending with `_backup` |
| `test_*` | Files starting with `test_` |
| `*.md` | All markdown files |

#### Exclude Folder Names
| | |
|---|---|
| **Type** | List of strings |
| **Match Type** | Exact name match |

Folder names to exclude (exact match, any location).

**Examples**:
```
.git            # Version control
.vs             # Visual Studio
Temp            # Temporary files
Documentation   # Internal docs
Tests           # Test folders
```

> **Note**: These are exact name matches. A folder named "Documentation" at any level will be excluded.

---

### Package Dependencies

Configure how your package handles dependencies on other packages.

#### Dependencies List
| | |
|---|---|
| **Type** | List of PackageDependency |
| **Configurable** | Per-dependency settings |

Configure how each package dependency is handled.

**Each dependency has**:

| Field | Description | Example |
|-------|-------------|---------|
| **Package Name** | Package identifier | `com.vrcfury` |
| **Version** | Minimum version required | `1.0.0` |
| **Display Name** | Friendly name | `VRCFury` |
| **Export Mode** | Bundle or Dependency | See below |
| **Enabled** | Include in export | Checkbox |

#### Export Modes

| Mode | Description | Use When |
|------|-------------|----------|
| **Bundle** | Include package files directly in exported package | Small dependencies, not on VPM |
| **Dependency** | Add to package.json (users download separately) | Large dependencies, available on VPM |

**Bundle Mode**:
- Package files included in your `.unitypackage`
- Larger file size
- No additional downloads needed

**Dependency Mode**:
- Referenced in package.json
- Smaller file size
- Users download via VPM or Direct VPM Installer

#### Smart Bundling

When using **Bundle** mode, the Package Exporter uses intelligent bundling to prevent compilation errors:

**How Smart Bundling Works**:
1. Bundled package files are added with `.yucp_disabled` extension
2. **Fresh GUIDs generated** for disabled files (prevents conflicts on re-import)
3. `.cs` and `.asmdef` files won't compile immediately
4. DirectVpmInstaller installs required VPM dependencies first
5. After dependencies ready, installer enables bundled files
6. **Smart replacement** - Only overwrites if new version is newer
7. **Automatic cleanup** - Deletes all `.yucp_disabled` files after enabling
8. Bundled packages compile successfully with all dependencies present

**Why This Matters**:
Without Smart Bundling, bundled packages would try to compile before their dependencies are installed, causing compilation errors.

**GUID Management**:
```
Original file: MyExtension.cs (GUID: abc123)
  ↓
Bundled as: MyExtension.cs.yucp_disabled (GUID: NEW_xyz789)
  ↓
User imports package
  ↓
Both versions can coexist temporarily (different GUIDs)
  ↓
Installer enables: MyExtension.cs.yucp_disabled → MyExtension.cs
  ↓
Cleanup deletes .yucp_disabled version
  ↓
No GUID conflicts!
```

**Example**:
```
Your package bundles a VRCFury extension script
  ↓
Script initially imported as: MyExtension.cs.yucp_disabled (fresh GUID)
  ↓
DirectVpmInstaller downloads and installs VRCFury
  ↓
Installer enables to: MyExtension.cs (preserves GUID)
  ↓
Cleanup deletes MyExtension.cs.yucp_disabled
  ↓
Script compiles successfully with VRCFury available
```

> **Automatic**: You don't need to configure this - it happens automatically when you use Bundle mode.

**Re-Import Safety**:
When user re-imports the same package:
- New GUIDs prevent conflicts with existing files
- Smart replacement checks file versions before overwriting
- Only updates files that are newer
- Preserves user modifications to older bundled files

#### Scan Dependencies Button
Auto-detects all installed packages in the project and populates the dependencies list.

> Click this to populate the list with all available packages, then configure each one.

#### Auto-Detect Used Button
Analyzes export folders for script references and enables only used dependencies.

> This is smarter than manual selection - it scans your code to find which packages you actually use.

**How it works**:
1. Scans all files in export folders
2. Finds script GUIDs
3. Maps GUIDs to packages
4. Enables only packages you actually reference

#### Generate Package.json
| | |
|---|---|
| **Type** | Bool |
| **Default** | true |

Generate or update package.json with dependency information during export.

> **Recommendation**: Keep enabled for VPM compatibility and proper package management.

---

### Direct VPM Installer

Automatically install VPM dependencies when users import your package.

#### How It Works

When you export a package with VPM dependencies in **Dependency** mode, the Package Exporter automatically:

1. **Bundles an installer script** - `DirectVpmInstaller.cs` is added to the package
2. **Bundles package.json** - Contains dependency information and VPM repository URLs
3. **Auto-runs on import** - When user imports your package, installer detects missing dependencies
4. **Prompts user** - Shows dialog asking to install required VPM packages
5. **Downloads and installs** - Automatically downloads from VPM repositories
6. **Self-cleans** - Installer removes itself after successful installation

**This means users don't need VCC (VRChat Creator Companion) to install VPM dependencies!**

#### VPM Repositories

The system automatically detects and includes repository URLs for VPM packages.

**Auto-Detection Sources**:

| Source | Location | Priority |
|--------|----------|----------|
| **VCC Settings** | `%LocalAppData%/VRChatCreatorCompanion/settings.json` | First |
| **VPM Manifest** | `Packages/vpm-manifest.json` | Second |
| **Built-in Repos** | Hard-coded common repositories | Fallback |

**Repository Detection Process**:
```
1. Read VCC settings.json (user's configured repos)
2. Read project's vpm-manifest.json (installed packages)
3. For each VPM dependency:
   a. Query each repository to find the package
   b. Record which repository hosts the package
   c. Add repository URL to package.json
4. Include only repositories that host your dependencies
```

**Built-in Repository URLs**:

| Repository | URL | Packages |
|------------|-----|----------|
| **VRChat Official** | https://packages.vrchat.com/official?download | com.vrchat.* |
| **VRChat Curated** | https://packages.vrchat.com/curated?download | Community packages |
| **VRCFury** | https://vpm.vrcfury.com/index.json | com.vrcfury.* |

> The installer checks all configured repositories to find the best version matching the requirement.

**Why This Matters**:
- DirectVpmInstaller knows where to download each package
- No hardcoded repository URLs in your package
- Works with custom VPM repositories automatically
- Users don't need to configure repos manually

#### User Experience

When someone imports your package:

1. Package imports normally
2. On next domain reload, installer script runs
3. Dialog appears: "This package requires the following VPM dependencies..."
4. User clicks **Install** or **Cancel**
5. If Install: Dependencies download and install automatically
6. Project reloads with all dependencies ready
7. Installer scripts delete themselves

**Zero manual setup required for end users!**

#### Requirements for Direct Install

For this feature to work, your dependencies must:
- Be available on a public VPM repository
- Have proper `package.json` files
- Be downloadable as .zip files

> Most VRChat ecosystem packages (SDK, VRCFury, etc.) work out of the box.

---

### Assembly Obfuscation

Protect your code with ConfuserEx obfuscation.

#### Enable Obfuscation
| | |
|---|---|
| **Type** | Bool |
| **Default** | false |

Enable ConfuserEx obfuscation for selected assemblies.

> **Note**: ConfuserEx will be auto-downloaded on first use if not already installed.

#### Obfuscation Preset
| | |
|---|---|
| **Type** | Enum |
| **Options** | Mild, Normal, Aggressive |
| **Default** | Normal |

Obfuscation protection level.

**Preset Comparison**:

| Preset | Protection Level | Speed | Compatibility | Best For |
|--------|-----------------|-------|---------------|----------|
| **Mild** | Basic | Fast | High | Open-source with light protection |
| **Normal** | Balanced | Medium | Good | Most commercial packages |
| **Aggressive** | Maximum | Slow | May have issues | High-value commercial code |

**Preset Details**:

| Feature | Mild | Normal | Aggressive |
|---------|------|--------|------------|
| Symbol renaming | ✓ | ✓ | ✓ |
| Control flow | Basic | ✓ | ✓ |
| Constants encryption | ✗ | ✓ | ✓ |
| Resources encryption | ✗ | ✓ | ✓ |
| Reference proxy | ✗ | ✗ | ✓ |
| Anti-tamper | ✗ | ✗ | ✓ |

#### Assemblies to Obfuscate
| | |
|---|---|
| **Type** | List of AssemblyObfuscationSettings |

Which assembly DLLs to obfuscate.

**Each assembly entry**:
- **Enabled**: ☑ Include in obfuscation
- **Assembly Name**: Name from .asmdef file
- **Asmdef Path**: Path to .asmdef file

> Only enable assemblies that contain your proprietary code. Don't obfuscate third-party dependencies.

#### Scan Assemblies Button
Finds all `.asmdef` files in export folders and populates the assembly list.

> **Workflow**: Add folders → Click Scan Assemblies → Check assemblies to obfuscate

#### Strip Debug Symbols
| | |
|---|---|
| **Type** | Bool |
| **Default** | true |

Remove debug symbols (PDB files) from obfuscated assemblies.

> **Recommendation**: Keep enabled for release builds. Reduces file size and removes debugging information.

---

### Export Settings

Configure export behavior and automation.

#### Export Path
| | |
|---|---|
| **Type** | String |
| **Default** | "" (Desktop) |

Default export path for packages.

**Options**:
- **Empty**: Exports to Desktop folder
- **Relative path**: Relative to project root
- **Absolute path**: Full path (e.g., `C:/MyPackages/Releases`)

**Examples**:
```
""                           # Desktop (default)
"Builds/Packages"           # Project/Builds/Packages/
"C:/Releases"               # Absolute path
```

#### Auto Increment Version
| | |
|---|---|
| **Type** | Bool |
| **Default** | false |

Automatically increment patch version (third number) after each successful export.

**Version progression**:
```
1.0.0  →  (export)  →  1.0.1
1.0.1  →  (export)  →  1.0.2
1.0.2  →  (export)  →  1.0.3
```

> **Use case**: Automated builds where version tracking is important.

---

### Statistics (Read-only)

Track export history for the profile.

#### Last Export Time
| | |
|---|---|
| **Type** | String (readonly) |

Timestamp of the last successful export.

**Format**: `2024-01-15 14:30:25`

#### Export Count
| | |
|---|---|
| **Type** | Int (readonly) |

Total number of times this profile has been exported successfully.

> Useful for tracking how many releases have been made.

---

### Export Profile Templates

Quick-start templates to get you exporting immediately.

#### Using Templates

The Package Exporter includes an example export profile template to help you get started:

**Location**: `Packages/com.yucp.components/Editor/PackageExporter/Templates/Example_ExportProfile.asset`

**How to Use**:
1. **Duplicate** the example profile
2. **Rename** it for your project (e.g., "MyAvatar_Export.asset")
3. **Configure** settings in Inspector:
   - Update package name and version
   - Set export folders to your content
   - Scan for dependencies
   - Configure obfuscation if needed
4. **Export** your package!

#### Recommended Organization

For best results, organize your export profiles in your project:

```
Assets/
└── YUCP/
    └── ExportProfiles/
        ├── Avatar_Export.asset
        ├── Clothing_Export.asset
        └── Props_Export.asset
```

> Keeping profiles in one location makes them easy to find and version control.

#### Template Configurations

**Example Template Includes**:
- Package Name: "MyPackage" (change this!)
- Version: 1.0.0 (semantic versioning)
- Include Dependencies: ✓ Enabled
- Recurse Folders: ✓ Enabled
- Generate package.json: ✓ Enabled
- Obfuscation: ✗ Disabled by default
- Export Path: Empty (Desktop by default)

#### Common Profile Types

| Profile Type | Typical Settings |
|--------------|------------------|
| **Avatar Package** | Folders: `Assets/MyAvatar`<br>Dependencies: VRCFury, YUCP (Dependency mode)<br>Obfuscation: Not needed<br>Icon: Avatar thumbnail |
| **Tool/Script Package** | Folders: `Packages/com.company.tool`<br>Dependencies: Minimal<br>Obfuscation: ✓ Recommended<br>Icon: Tool logo |
| **Clothing Package** | Folders: `Assets/Clothing/MyOutfit`<br>Dependencies: Auto-detect (VRCFury, Poiyomi)<br>Obfuscation: Not needed<br>Icon: Clothing preview |

---

## Step-by-Step Tutorial

### Tutorial: Basic Package Export

#### Step 1: Create Profile
1. Open Package Exporter: `Tools → YUCP → Package Exporter`
2. Click `Create New Profile`
3. Profile appears in list (left sidebar)

[Image: Package Exporter window with new profile created]

#### Step 2: Configure Metadata
```
Package Name: MyAvatarTools
Version: 1.0.0
Author: YourName
Description: Useful tools for avatar creation
```

[Image: Metadata section filled out]

#### Step 3: Add Folders
1. Click `Add Folder`
2. Browse to your package folder (e.g., `Packages/com.mycompany.mytools`)
3. Click Select Folder
4. Folder added to list

[Image: Folder added to export list]

#### Step 4: Configure Exclusions
```
Exclude File Patterns:
- *.tmp
- *.log
- *~

Exclude Folder Names:
- .git
- Documentation
```

This prevents unwanted files from being included.

#### Step 5: Export
1. Click `Export Package` (bottom of window)
2. Wait for export to complete
3. Package saved to Desktop (or configured export path)

[Image: Export progress bar]

#### Step 6: Verify
Check Desktop for:
```
MyAvatarTools_1.0.0.unitypackage
```

Import into a test project to verify contents.

---

### Tutorial: Package with VPM Auto-Install

Create a package that automatically installs its VPM dependencies when imported.

#### Step 1: Configure Basic Settings
```yaml
Package Name: MyVRChatTools
Version: 1.0.0
Author: Your Name
Folders: Packages/com.yourname.vrchattools
```

#### Step 2: Scan Dependencies
1. Click **`Scan Dependencies`** button
2. All installed packages populate the list

#### Step 3: Configure VPM Dependencies

For each VPM dependency (VRCFury, VRChat SDK):

| Setting | Value |
|---------|-------|
| **Package Name** | com.vrcfury |
| **Export Mode** | **Dependency** (important!) |
| **Version** | >=1.0.0 |
| **Enabled** | ✓ |

**Why Dependency mode?**
- Triggers DirectVpmInstaller to be bundled
- Smaller package size
- Users get latest compatible version

#### Step 4: Enable Package.json Generation
```
✓ Generate Package.json
```

This is critical - DirectVpmInstaller needs package.json to know what to install.

#### Step 5: Export
1. Click **`Export Package`**
2. Watch Console for:
   ```
   [PackageBuilder] Adding DirectVpmInstaller.cs to package
   [PackageBuilder] Adding FullDomainReload.cs to package
   [PackageBuilder] Added package.json with vpmDependencies
   ```

#### Step 6: Test Installation
1. Create a **new test Unity project** (important - must be clean)
2. Import your exported .unitypackage
3. **Wait for domain reload**
4. Dialog appears: "Install VPM Dependencies?"
   ```
   This package requires:
     - com.vrchat.avatars >= 3.5.0
     - com.vrcfury >= 1.0.0
   
   Would you like to install them now?
   ```
5. Click **Install**
6. Watch Console for installation progress:
   ```
   [DirectVpmInstaller] Downloading com.vrchat.avatars...
   [DirectVpmInstaller] Installed com.vrchat.avatars@3.5.2
   [DirectVpmInstaller] Downloading com.vrcfury...
   [DirectVpmInstaller] Installed com.vrcfury@1.856.0
   [DirectVpmInstaller] Installation complete!
   ```
7. Project reloads automatically
8. Dependencies are ready to use!

**Success**: Your package and all dependencies installed with zero manual setup!

---

### Tutorial: Package with Dependencies

Let's create a package that depends on VRCFury.

#### Step 1: Configure Basic Settings
```
Package Name: MyVRCFuryTools
Version: 1.0.0
Folders: Packages/com.mycompany.vrcfurytools
```

#### Step 2: Scan Dependencies
1. Click `Scan Dependencies` button
2. All installed packages populate the list

[Image: Dependencies list populated with installed packages]

#### Step 3: Configure VRCFury Dependency
Find VRCFury in list:
```
Package Name: com.vrcfury
Version: 1.0.0
Display Name: VRCFury
Export Mode: Dependency (reference, not bundle)
Enabled: true
```

**Dependency mode** means:
- VRCFury files NOT included in package
- package.json references VRCFury
- Users must have VRCFury installed (auto-download via VPM)

[Image: VRCFury dependency configured]

#### Step 4: Auto-Detect Used Dependencies
1. Click `Auto-Detect Used` button
2. Component analyzes export folders for script references
3. Enables only dependencies actually used
4. Disables unused dependencies

[Image: Auto-detection results showing enabled/disabled dependencies]

#### Step 5: Export with Package.json
1. Ensure `Generate Package.json` is checked
2. Click `Export Package`
3. Result package includes package.json:
   ```json
   {
     "name": "com.mycompany.vrcfurytools",
     "displayName": "MyVRCFuryTools",
     "version": "1.0.0",
     "dependencies": {
       "com.vrcfury": "1.0.0"
     }
   }
   ```

### Tutorial: Obfuscated Package

Protect your code with ConfuserEx obfuscation.

#### Step 1: Configure Export
```
Package Name: MyProtectedPackage
Folders: Packages/com.mycompany.protected
```

#### Step 2: Enable Obfuscation
1. Check `Enable Obfuscation`
2. Set `Obfuscation Preset` to **Normal**
3. Check `Strip Debug Symbols`

[Image: Obfuscation settings enabled]

#### Step 3: Scan Assemblies
1. Click `Scan Assemblies`
2. All .asmdef files in export folders are found
3. List populates with assemblies

[Image: Assemblies list showing detected .asmdef files]

#### Step 4: Select Assemblies to Obfuscate
Check the assemblies you want obfuscated:
```
☑ com.mycompany.protected.Runtime
☑ com.mycompany.protected.Editor
☐ ThirdParty.Dependency (don't obfuscate dependencies)
```

#### Step 5: Export with Obfuscation
1. Click `Export Package`
2. If ConfuserEx not installed:
   - Dialog prompts to download
   - Auto-downloads from GitHub
   - Extracts to Packages/com.yucp.components/Tools/
3. Progress bar shows:
   ```
   Preparing assemblies for obfuscation...
   Running ConfuserEx (Normal preset)...
   Copying obfuscated assemblies...
   Obfuscation complete!
   ```

[Image: Export progress showing obfuscation steps]

#### Step 6: Verify Obfuscation
- Check Console for ConfuserEx output
- Obfuscated DLLs are larger (due to protection)
- Decompiling shows renamed symbols, encrypted strings

### Tutorial: Batch Export Multiple Profiles

Export all your packages at once.

#### Step 1: Create Multiple Profiles
Create profiles for each package:
- Profile 1: MyAvatarTools
- Profile 2: MyWorldTools
- Profile 3: MyEditorTools

[Image: Multiple profiles in left sidebar]

#### Step 2: Configure Each Profile
Set up folders, dependencies, obfuscation for each.

#### Step 3: Batch Export
1. Click `Export All Profiles` button (top of window)
2. Confirmation dialog shows all profiles to export
3. Click OK
4. Progress bar shows current profile being exported

[Image: Batch export progress showing "Exporting 2 of 3..."]

#### Step 4: Results
All packages exported:
```
Desktop/
├── MyAvatarTools_1.0.0.unitypackage
├── MyWorldTools_1.2.0.unitypackage
└── MyEditorTools_0.5.0.unitypackage
```

## Advanced Features

Deep dive into advanced capabilities.

---

### Direct VPM Installer (Auto-Install Dependencies)

The Package Exporter can bundle an automatic installer that downloads and installs VPM dependencies when users import your package.

#### When It's Used

The Direct VPM Installer is automatically added when:
- You have VPM dependencies configured
- Dependencies are in **Dependency** mode (not Bundle)
- **Generate Package.json** is enabled

> No additional configuration needed - it's completely automatic!

#### What Gets Bundled

When exporting, the system adds:

| File | Purpose | Location in Package |
|------|---------|---------------------|
| `YUCP_TempInstall_{guid}.json` | Package info with dependencies | `Assets/` |
| `YUCP_Installer_{guid}.cs` | Installer script | `Assets/Editor/` |
| `YUCP_Installer_{guid}.asmdef` | Isolated assembly def | `Assets/Editor/` |
| `YUCP_FullDomainReload_{guid}.cs` | Reload helper | `Assets/Editor/` |

> All files use unique GUIDs to prevent conflicts between multiple package imports.

#### Installation Flow Diagram

```
User imports your .unitypackage
    ↓
Unity imports all files
    ↓
DirectVpmInstaller.cs runs on domain reload
    ↓
Finds YUCP_TempInstall_*.json
    ↓
Parses VPM dependencies
    ↓
Checks which packages are missing
    ↓
Shows dialog: "Install VPM Dependencies?"
    ↓
User clicks "Install"
    ↓
Locks assemblies (prevents mid-install compilation)
    ↓
Downloads packages from VPM repositories
    ↓
Extracts to Packages/ folder
    ↓
Updates vpm-manifest.json
    ↓
Enables bundled packages (removes .yucp_disabled)
    ↓
Unlocks assemblies
    ↓
Forces full domain reload
    ↓
Deletes all installer files
    ↓
Installation complete!
```

#### Manual Installation Menu

If user cancels the installer or needs to reinstall:

**Menu**: `Tools → YUCP → Manual - Install VPM Dependencies`

This manually triggers the installer to check for and install missing dependencies.

---

### Smart Bundling (Delayed Compilation)

Prevents compilation errors when bundling packages that have their own dependencies.

#### The Problem It Solves

**Without Smart Bundling**:
```
1. User imports your package
2. Your bundled script "VRCFuryExtension.cs" tries to compile
3. VRCFury not installed yet
4. Compilation ERROR: "Type VRCFury.Toggle not found"
```

**With Smart Bundling**:
```
1. User imports your package
2. Bundled script imports as "VRCFuryExtension.cs.yucp_disabled"
3. Won't compile yet (disabled)
4. DirectVpmInstaller installs VRCFury
5. Installer renames to "VRCFuryExtension.cs"
6. Compilation SUCCESS: VRCFury is now available
```

#### File Extension Handling

| File Type | Bundled As | Reason |
|-----------|------------|--------|
| `.cs` files | `.cs.yucp_disabled` | Prevent compilation |
| `.asmdef` files | `.asmdef.yucp_disabled` | Prevent assembly creation |
| Other files | Original name | No compilation issues |

#### Bundle + Dependency Hybrid

You can mix Bundle and Dependency modes:

**Example Configuration**:
```
Your custom utility scripts:
  Export Mode: Bundle (.yucp_disabled)

VRCFury (large framework):
  Export Mode: Dependency (DirectVpmInstaller)

VRChat SDK (huge):
  Export Mode: Dependency (DirectVpmInstaller)
```

**Result**:
- User imports one .unitypackage
- DirectVpmInstaller downloads VRCFury + SDK
- Your bundled scripts enable after dependencies ready
- Everything compiles successfully

> Best of both worlds: Bundle small custom code, reference large dependencies.

---

### Version Auto-Increment

```
Settings:
- Auto Increment Version: true
- Version: 1.0.0

After first export:  Version → 1.0.1
After second export: Version → 1.0.2
...
```

Automatically increments patch version (last number).

### Package Icon Injection

When icon is set:
```
Icon: MyIcon.png (256x256 recommended)
```

Export process:
1. Export Unity package normally
2. Extract .tar.gz
3. Inject icon.png
4. Repackage .tar.gz

Result: Package shows custom icon in Package Manager.

### Custom Export Path

```
Export Path: C:/MyPackages/Releases

Result: Packages export to custom directory instead of Desktop
```

Useful for automated build systems.

### ConfuserEx Presets

**Mild** - Fast obfuscation, minimal compatibility issues:
```xml
<protection id="rename" />
<protection id="ctrl flow" />
```

**Normal** - Balanced protection (recommended):
```xml
<protection id="rename" />
<protection id="ctrl flow" />
<protection id="constants" />
<protection id="resources" />
```

**Aggressive** - Maximum protection, may have issues:
```xml
<protection id="rename" />
<protection id="ctrl flow" />
<protection id="constants" />
<protection id="resources" />
<protection id="ref proxy" />
<protection id="anti tamper" />
```

### Dependency Auto-Detection

Scans export folders for MonoScript GUIDs:

```csharp
// Read asset files
string assetContent = File.ReadAllText(assetPath);

// Find script GUIDs
var guidMatches = Regex.Matches(assetContent, @"guid:\s*([a-f0-9]{32})");

// Map GUIDs to packages
foreach (Match match in guidMatches)
{
    string scriptPath = AssetDatabase.GUIDToAssetPath(match.Groups[1].Value);
    
    // Check which package this script belongs to
    if (scriptPath.StartsWith("Packages/com.vrcfury/"))
        usedPackages.Add("com.vrcfury");
}

// Enable only used dependencies
foreach (var dep in profile.dependencies)
{
    dep.enabled = usedPackages.Contains(dep.packageName);
}
```

### Wildcard Exclusion Patterns

**File patterns** support wildcards:
```
*.tmp          → Matches all .tmp files
*_backup.*     → Matches files ending with _backup
test_*.cs      → Matches C# files starting with test_
```

**Folder names** are exact matches:
```
.git           → Excludes any folder named ".git"
Temp           → Excludes any folder named "Temp"
Documentation  → Excludes "Documentation" folders
```

## Exporter Window UI

### Left Sidebar: Profile List

Shows all export profiles in project:
```
Profile List
├── MyPackage (v1.2.0)
├── OtherPackage (v2.0.0)
└── TestPackage (v0.1.0)
```

Click profile to select and view details.

### Main Panel: Profile Configuration

Selected profile details:
- Package metadata (editable)
- Folder list with Add/Remove buttons
- Dependencies with checkboxes
- Obfuscation settings
- Export buttons

### Bottom Bar: Export Controls

- **Export Package** - Export selected profile
- **Export All Profiles** - Batch export all profiles
- **Clone Profile** - Duplicate selected profile
- **Delete Profile** - Remove profile (with confirmation)

[Image: Package Exporter window layout diagram]

## Step-by-Step Tutorial

### Tutorial: Professional VRChat Package

Create a professional VRChat package with obfuscation and VPM compatibility.

#### Step 1: Create Export Profile
1. `Tools → YUCP → Package Exporter`
2. `Create New Profile`
3. Name: "MyVRChatTools"

#### Step 2: Configure Metadata
```
Package Name: MyVRChatTools
Version: 1.0.0
Author: YourName
Description: Advanced tools for VRChat avatar creation
Icon: [Upload 256x256 PNG]
```

#### Step 3: Add Package Folder
```
Folders to Export:
- Packages/com.yourname.vrchattools
```

Click `Add Folder`, select your package folder.

#### Step 4: Set Up Exclusions
```
Exclude File Patterns:
- *.md (exclude markdown docs)
- *.tmp
- *~

Exclude Folder Names:
- .git
- Documentation
- Examples
```

#### Step 5: Configure Dependencies
1. Click `Scan Dependencies`
2. Find and configure:
   ```
   VRCFury:
   - Enabled: true
   - Export Mode: Dependency
   - Version: >=1.0.0
   
   VRChat SDK:
   - Enabled: true
   - Export Mode: Dependency
   - Version: >=3.5.0
   ```

3. Click `Auto-Detect Used` to enable only used dependencies

[Image: Dependencies configured with Bundle/Dependency modes]

#### Step 6: Enable Obfuscation
```
Enable Obfuscation: true
Obfuscation Preset: Normal
Strip Debug Symbols: true
```

Click `Scan Assemblies`:
```
Assemblies to Obfuscate:
☑ com.yourname.vrchattools.Runtime
☑ com.yourname.vrchattools.Editor
```

[Image: Obfuscation settings with assemblies selected]

#### Step 7: Configure Export
```
Export Path: (empty - uses Desktop)
Auto Increment Version: true
Generate Package.json: true
```

#### Step 8: Export
1. Click `Export Package`
2. Wait for progress bar
3. Check Desktop for package file

#### Step 9: Verify Package
1. Create new Unity project
2. Import MyVRChatTools_1.0.0.unitypackage
3. Check package.json was included
4. Verify dependencies are listed
5. Try decompiling DLL - should show obfuscated code

[Image: Decompiled obfuscated code showing renamed symbols]

## Advanced Features

### Profile Cloning

Clone existing profile:
1. Select profile in list
2. Click `Clone Profile`
3. New profile created with same settings
4. Modify as needed (e.g., different version or obfuscation level)

Use cases:
- Dev vs Release configurations
- Different obfuscation levels
- Platform-specific variants

### Multi-Profile Workflow

Create specialized profiles:

**Profile: Development**
```
Enable Obfuscation: false
Include: All folders including tests
Export Path: Desktop/Dev
```

**Profile: Release**
```
Enable Obfuscation: true
Obfuscation Preset: Normal
Include: Only production folders
Exclude: Tests, examples
Export Path: Desktop/Release
```

**Profile: Source**
```
Enable Obfuscation: false
Include: All folders
Exclude: .git only
Export Path: Desktop/Source
```

Export all at once for different distribution channels.

### ConfuserEx Installation

**First use**:
1. Export with obfuscation enabled
2. System checks for ConfuserEx
3. If not found:
   - Downloads from GitHub (v1.6.0)
   - Extracts to Packages/com.yucp.components/Tools/ConfuserEx
   - Ready to use

**Manual check**:
- `Tools → YUCP → Package Exporter → Check ConfuserEx Installation`

**Location**: `Packages/com.yucp.components/Tools/ConfuserEx/Confuser.CLI.exe`

### Bundle vs Dependency Mode Detailed

Complete comparison of the two export modes with Smart Bundling support.

#### Bundle Mode (With Smart Bundling)

**Configuration**:
```
Export Mode: Bundle
```

**What happens**:
- Dependency package files included directly in .unitypackage
- Scripts/asmdefs get `.yucp_disabled` extension (Smart Bundling)
- Files remain disabled until VPM dependencies install
- DirectVpmInstaller enables them after dependencies ready

**Characteristics**:

| Aspect | Details |
|--------|---------|
| **Package size** | Larger (includes dependency files) |
| **User downloads** | None (everything bundled) |
| **Installation** | Automatic with Smart Bundling |
| **VPM required** | No (bundled directly) |
| **Compilation** | Delayed until dependencies ready |

**Best for**:
- Small custom dependencies
- Packages not available via VPM
- Proprietary code you want bundled
- Dependencies with additional assets (prefabs, textures)

**Example Use Case**:
```
You have custom VRCFury extension scripts:
- Bundle your scripts with .yucp_disabled
- VRCFury set to Dependency mode
- User imports package
- DirectVpmInstaller downloads VRCFury
- Your scripts enable and compile successfully
```

---

#### Dependency Mode (With Direct VPM Installer)

**Configuration**:
```
Export Mode: Dependency
```

**What happens**:
- Added to package.json vpmDependencies
- DirectVpmInstaller script bundled in package
- Not included in .unitypackage
- Automatically downloads when user imports

**Characteristics**:

| Aspect | Details |
|--------|---------|
| **Package size** | Smaller (references only) |
| **User downloads** | Automatic via DirectVpmInstaller |
| **Installation** | Downloads from VPM repository |
| **VPM required** | No (DirectVpmInstaller handles it) |
| **Compilation** | After automatic installation |

**Best for**:
- Large dependencies (VRCFury, VRChat SDK)
- Packages available on public VPM repositories
- Frequently updated dependencies
- Reducing package file size

**Example Use Case**:
```
Your package uses VRCFury and VRChat SDK:
- Both set to Dependency mode
- Your package exports as small .unitypackage
- User imports package
- DirectVpmInstaller downloads both dependencies
- Everything installs and compiles automatically
```

---

#### Hybrid Approach (Recommended)

The most powerful approach combines both modes:

**Configuration**:
```yaml
Your custom scripts:
  Mode: Bundle
  Result: Bundled as .yucp_disabled files

Small custom dependency:
  Mode: Bundle
  Result: Bundled as .yucp_disabled files

VRCFury:
  Mode: Dependency
  Result: Downloaded via DirectVpmInstaller

VRChat SDK:
  Mode: Dependency
  Result: Downloaded via DirectVpmInstaller
```

**Timeline**:
```
User imports package
  ↓
All files import (your scripts as .yucp_disabled)
  ↓
DirectVpmInstaller runs
  ↓
Downloads VRCFury + SDK from VPM repos
  ↓
Removes .yucp_disabled from your bundled scripts
  ↓
Everything compiles successfully
```

**Benefits**:
- Small package size (large deps downloaded)
- Your code is bundled (no separate download)
- Zero compilation errors
- Single .unitypackage for distribution

---

#### Decision Chart

```
Is the dependency available on a public VPM repository?
  ├─ YES → Is it large (>5MB)?
  │         ├─ YES → Use Dependency mode
  │         └─ NO → Either mode works
  └─ NO → Use Bundle mode

Is it your own code that depends on VPM packages?
  └─ YES → Use Bundle mode (with Smart Bundling)
  
Is it a frequently updated package?
  └─ YES → Use Dependency mode (users get latest)
```

---

#### Mode Comparison Table

| Factor | Bundle Mode | Dependency Mode |
|--------|-------------|-----------------|
| **File inclusion** | ✓ In .unitypackage | ✗ Referenced only |
| **Package size** | Larger | Smaller |
| **Smart Bundling** | ✓ Uses .yucp_disabled | N/A |
| **DirectVpmInstaller** | Optional | ✓ Auto-bundled |
| **User internet required** | No* | Yes (for download) |
| **VPM repo required** | No | Yes |
| **Updates** | Must re-export | Users get latest |
| **Best for** | Custom code, small deps | Large deps, frameworks |

\* *If your bundled code has VPM dependencies, DirectVpmInstaller still runs to install those*

---

### Recommendations by Package Type

| Package Type | Your Code | VRCFury | VRChat SDK | Other Deps |
|--------------|-----------|---------|------------|------------|
| **Avatar Package** | N/A | Dependency | Dependency | Auto-detect |
| **Clothing Package** | N/A | Dependency | Dependency | Bundle (if small) |
| **Tool Package** | Bundle | Dependency | Dependency | Bundle/Dependency |
| **Framework Package** | Bundle | Bundle or Dep | Dependency | Bundle |

---

### VPM Dependencies and Repositories

For VRChat packages, the system generates both `vpmDependencies` and `vpmRepositories`.

#### Generated Package.json Structure

```json
{
  "name": "com.yourname.package",
  "displayName": "Your Package",
  "version": "1.0.0",
  "description": "Your package description",
  "author": {
    "name": "Your Name"
  },
  "unity": "2022.3",
  "dependencies": {
    "com.unity.textmeshpro": "3.0.6"
  },
  "vpmDependencies": {
    "com.vrchat.avatars": ">=3.5.0",
    "com.vrcfury": ">=1.0.0"
  },
  "vpmRepositories": {
    "VRChat Official": "https://packages.vrchat.com/official",
    "VRCFury": "https://vpm.vrcfury.com/index.json"
  }
}
```

#### Section Breakdown

**dependencies**: Standard UPM packages
- Unity built-in packages
- Non-VPM third-party packages

**vpmDependencies**: VRChat ecosystem packages
- VRChat SDK
- VRCFury
- Other VPM packages

**vpmRepositories**: VPM repository URLs
- Automatically added for DirectVpmInstaller
- Maps packages to their download sources
- Built-in for common packages (VRChat, VRCFury)

#### Auto-Detection

The system automatically:
1. Detects VRChat-related packages by name pattern (`com.vrchat.*`)
2. Places them in `vpmDependencies` instead of `dependencies`
3. Adds corresponding repository URLs to `vpmRepositories`
4. DirectVpmInstaller uses these URLs to download packages

**Example**:
```
You enable com.vrcfury as a dependency
  ↓
System detects it's a VPM package
  ↓
Adds to vpmDependencies: "com.vrcfury": ">=1.0.0"
  ↓
Adds to vpmRepositories: "VRCFury": "https://vpm.vrcfury.com/index.json"
  ↓
DirectVpmInstaller knows where to download from
```

---

## Troubleshooting

Common issues and their solutions.

---

### Export Failed

**Symptom**: Export process fails with an error message.

**Diagnostic Steps**:
1. Check Console for specific error message
2. Verify all folders in export list exist
3. Check file and folder permissions
4. Ensure no files are locked by other programs

**Common Errors**:

| Error | Cause | Solution |
|-------|-------|----------|
| "Folder not found" | Export folder doesn't exist | Verify folder path is correct |
| "Access denied" | Permission issue | Check folder permissions |
| "File in use" | File locked by another program | Close programs using the files |
| "Invalid path" | Path contains invalid characters | Use valid folder path |

---

### Obfuscation Failed

**Symptom**: Obfuscation step fails during export.

**Diagnostic Steps**:
1. Verify ConfuserEx is installed correctly
2. Check that assemblies exist (compile scripts first)
3. Review ConfuserEx output in Console
4. Try a different obfuscation preset

**Solutions**:

| Issue | Fix |
|-------|-----|
| ConfuserEx not found | Click "Check ConfuserEx Installation" in menu |
| Assembly DLL not found | Compile scripts first, check Library/ScriptAssemblies/ |
| Obfuscation errors | Try **Mild** preset instead of Aggressive |
| Compatibility issues | Disable obfuscation for problematic assemblies |

**ConfuserEx Installation Check**:
- Location: `Packages/com.yucp.components/Tools/ConfuserEx/`
- File needed: `Confuser.CLI.exe`
- Auto-download: Happens automatically on first obfuscation

---

### Package Icon Not Showing

**Symptom**: Icon doesn't appear in Package Manager after import.

**Possible Causes**:

| Cause | Check | Solution |
|-------|-------|----------|
| **Wrong format** | Is it PNG? | Convert to PNG format |
| **Too large** | File size >1MB? | Reduce image file size |
| **Wrong dimensions** | Not square? | Use square image (256x256 recommended) |
| **Injection failed** | Check Console | Look for icon injection errors |

**Requirements**:
- Format: PNG only
- Size: Recommend 256x256 pixels
- File size: <1MB
- Color: RGB or RGBA

---

### Dependencies Not Auto-Detected

**Symptom**: "Auto-Detect Used" doesn't find dependencies.

**Possible Causes**:

| Cause | Solution |
|-------|----------|
| **Scripts not compiled** | Recompile all scripts first |
| **No references in export folders** | Add assets that use dependencies |
| **GUID mapping failed** | Manually enable dependencies |
| **Package not installed** | Install package first, then scan |

**Diagnostic Steps**:
1. Ensure project compiles without errors
2. Check that export folders contain assets using dependencies
3. Verify dependencies are installed in project
4. Try "Scan Dependencies" first, then "Auto-Detect Used"

---

### Version Not Incrementing

**Symptom**: Version doesn't auto-increment after export.

**Check**:
- Is "Auto Increment Version" enabled?
- Did export complete successfully?
- Is profile saved after export?

**Solution**: Enable "Auto Increment Version" in Export Settings.

---

### Batch Export Hangs

**Symptom**: Batch export stops or hangs on a profile.

**Solutions**:
1. Check Console for errors
2. Try exporting problem profile individually
3. Fix issues with individual profile
4. Retry batch export

---

### Package.json Not Generated

**Symptom**: Exported package doesn't include package.json.

**Check**:
- Is "Generate Package.json" enabled?
- Are there any dependencies configured?
- Check Console for generation errors

**Solution**: Enable "Generate Package.json" in Package Dependencies section.

---

### Direct VPM Installer Not Working

**Symptom**: Dependencies don't auto-install when importing package.

**Diagnostic Checklist**:

1. **Check installer was bundled**:
   - Look for `YUCP_Installer_*.cs` in imported files
   - Check Console for `[DirectVpmInstaller]` logs

2. **Check package.json was bundled**:
   - Look for `YUCP_TempInstall_*.json` in Assets/

3. **Check dependencies are in Dependency mode**:
   - Open export profile
   - Verify dependencies are **Dependency** mode (not Bundle)

4. **Check VPM repositories are configured**:
   - Common packages (VRChat, VRCFury) are auto-configured
   - Custom packages need repository URLs

**Solutions**:

| Issue | Fix |
|-------|-----|
| Installer not bundled | Verify dependencies are in Dependency mode |
| No VPM repositories found | Check package.json has vpmRepositories section |
| Download fails | Check internet connection and repository URLs |
| Installation hangs | Check Console for error messages |
| User cancelled | Run `Tools → YUCP → Manual - Install VPM Dependencies` |

---

### Bundled Packages Not Enabling

**Symptom**: Bundled packages stay as `.yucp_disabled` files after installation.

**Possible Causes**:

| Cause | Solution |
|-------|----------|
| **Installer didn't run** | Check Console for installer logs |
| **Installation failed** | Check for error messages in Console |
| **File permissions** | Verify write permissions in Packages/ folder |
| **Manual cancellation** | Installer skips enabling if user cancels |

**Manual Fix**:
1. Manually rename `.yucp_disabled` files (remove extension)
2. Manually rename `.yucp_disabled.meta` files (remove extension)
3. Refresh AssetDatabase

---

### Compilation Errors After Import

**Symptom**: Compilation errors appear immediately after importing package.

**Likely Cause**: Smart Bundling didn't work or dependencies failed to install.

**Solutions**:

1. **Check if installer ran**:
   ```
   Look for Console logs:
   [DirectVpmInstaller] Installing dependencies...
   [DirectVpmInstaller] Installation complete
   ```

2. **Install dependencies manually**:
   - `Tools → YUCP → Manual - Install VPM Dependencies`

3. **Check bundled files**:
   - Look for `.yucp_disabled` files in Packages/
   - They should have been renamed after installation

4. **Force full domain reload**:
   - Close and reopen Unity
   - Or: `Tools → YUCP → Manual - Install VPM Dependencies`

---

### Re-Importing Same Package

**Symptom**: Re-importing the same package multiple times.

**This is now fully supported!** The system handles re-imports gracefully:

**What Happens**:
1. **Fresh GUIDs for disabled files** - No conflicts with existing files
2. **Version detection** - Checks if package is already installed
3. **Smart replacement** - Only overwrites if new version is newer
4. **Cleanup** - Removes orphaned `.yucp_disabled` files automatically

**Re-Import Scenarios**:

| Scenario | Behavior |
|----------|----------|
| **Same version** | Skips extraction if identical, enables any disabled files |
| **Newer version** | Replaces old files with new ones |
| **Older version** | Skips replacement, keeps newer installed version |
| **User modified files** | Checks timestamps, preserves newer modifications |

**Example Re-Import Flow**:
```
User has MyPackage v1.0.0 installed
  ↓
User imports MyPackage v1.0.1 .unitypackage
  ↓
System detects v1.0.0 already exists
  ↓
Compares versions (1.0.1 > 1.0.0)
  ↓
Replaces outdated files with new versions
  ↓
Enables any new .yucp_disabled files
  ↓
Cleanup removes old .yucp_disabled files
  ↓
v1.0.1 now installed, no conflicts
```

> **Note**: This makes iterative development much smoother - you can export and re-import repeatedly without issues.

---

### GUID Conflicts

**Symptom**: "GUID conflicts detected" error when importing package.

**This issue has been fixed!** The system now:

1. **Generates fresh GUIDs** for all `.yucp_disabled` files
2. **Preserves GUIDs** only for non-disabled files
3. **Automatic cleanup** removes disabled versions after enabling

**Old Behavior** (before fix):
```
MyScript.cs (GUID: abc123) exists in project
Import package with MyScript.cs.yucp_disabled (GUID: abc123 - CONFLICT!)
Unity error: "GUID abc123 already in use"
```

**New Behavior** (fixed):
```
MyScript.cs (GUID: abc123) exists in project
Import package with MyScript.cs.yucp_disabled (GUID: xyz789 - NEW GUID)
No conflict - both can coexist temporarily
Installer enables and cleanup removes .yucp_disabled
Clean result: Only MyScript.cs (GUID: abc123)
```

---

### Orphaned .yucp_disabled Files

**Symptom**: `.yucp_disabled` files remain in project after installation.

**This has been fixed!** The installer now:

1. Enables bundled files (removes `.yucp_disabled` extension)
2. **Automatically deletes** all remaining `.yucp_disabled` files
3. Cleans up associated `.meta` files
4. Refreshes AssetDatabase

**Cleanup Process**:
```
[DirectVpmInstaller] Enabled 5 bundled package files
[DirectVpmInstaller] Cleaning up 5 .yucp_disabled files...
[DirectVpmInstaller] Deleted: MyScript.cs.yucp_disabled
[DirectVpmInstaller] Deleted: MyScript.cs.yucp_disabled.meta
[DirectVpmInstaller] Cleanup complete - 0 disabled files remaining
```

**Manual Cleanup** (if needed):
1. Search project for `*.yucp_disabled` files
2. Delete them and their `.meta` files manually
3. Refresh AssetDatabase

---

## FAQ

Frequently asked questions about Package Exporter.

---

### Q: Can I export without obfuscation?

**A**: Yes! Obfuscation is completely optional.

Simply leave **`Enable Obfuscation`** unchecked, and your package will export with unobfuscated DLLs.

> Obfuscation is only needed if you want to protect proprietary code.

---

### Q: Is obfuscation reversible?

**A**: **Partially**.

ConfuserEx creates automatic backups:
- Original DLLs: Saved as `.dll.backup`
- Location: Same folder as obfuscated DLL

**To restore**:
- Manually: Rename `.dll.backup` to `.dll`
- Via tool: Use "Restore Original DLLs" option (if available)

> However, once distributed, obfuscation cannot be reversed by users.

---

### Q: What's the difference between Bundle and Dependency mode?

**A**: 

| Aspect | Bundle | Dependency |
|--------|--------|------------|
| **Files included** | Yes (in .unitypackage) | No (referenced only) |
| **Package size** | Larger | Smaller |
| **User downloads** | None (all included) | Must install dependency separately |
| **Best for** | Small dependencies | Large dependencies (SDK, frameworks) |
| **VPM** | Not needed | Required for auto-download |

**Example**: If your package uses VRCFury:
- **Bundle**: Include all VRCFury files in your package (large)
- **Dependency**: Reference VRCFury in package.json (users download via VPM)

---

### Q: Can I export to multiple locations?

**A**: **Yes**, using multiple profiles:

1. Clone your profile multiple times
2. Set different export paths for each
3. Use **Export All Profiles** for batch export

**Example**:
- Profile 1: Export Path = "Desktop/Dev" (development)
- Profile 2: Export Path = "Desktop/Release" (production)
- Profile 3: Export Path = "C:/Releases" (distribution)

---

### Q: Does this work with UPM packages?

**A**: **Absolutely!** 

The system is specifically designed for UPM (Unity Package Manager) packages:
- Supports `Packages/` folder structure
- Generates proper package.json
- Handles UPM dependencies correctly
- VPM compatible

---

### Q: How do I distribute VPM packages?

**A**: 

1. **Export with package.json** enabled
2. **Add to VPM repository**:
   - Upload to your VPM repo (e.g., vpm.yucp.club)
   - Or distribute .unitypackage directly
3. **Users install via VPM** or manually

> The exported package.json ensures VPM compatibility.

---

### Q: Can I use this for Asset Store packages?

**A**: **Yes**, with considerations:

- **Obfuscation**: May be useful for protecting code
- **Dependencies**: Use **Bundle** mode (Asset Store doesn't support external deps)
- **Package.json**: Not needed for Asset Store
- **Icon**: May not show in Asset Store interface

---

### Q: How do I update existing packages?

**A**:

1. **Update your code** in Unity
2. **Open existing export profile**
3. **Update version number** (or enable auto-increment)
4. **Click Export Package**
5. **Distribute updated package**

> Version tracking helps users know they're getting the latest version.

---

### Q: Can obfuscation break my code?

**A**: **Rarely**, but possible with Aggressive preset.

**Recommendations**:
- **Start with Normal preset** - balanced protection
- **Test after obfuscation** - import and test the exported package
- **Don't obfuscate dependencies** - only your own code
- **Use Mild for compatibility** - if you encounter issues

**Common issues**:
- Reflection-based code may break
- Serialization may have issues
- Some Unity APIs may conflict

---

### Q: How long does export take?

**A**: Depends on several factors:

| Configuration | Typical Time |
|---------------|--------------|
| **No obfuscation** | 5-30 seconds |
| **With obfuscation (Mild)** | 30-60 seconds |
| **With obfuscation (Normal)** | 1-2 minutes |
| **With obfuscation (Aggressive)** | 2-5 minutes |
| **Large packages (100+ files)** | +30-60 seconds |

> Obfuscation is the slowest part. Consider having separate profiles with/without obfuscation.

---

### Q: Can I customize ConfuserEx settings?

**A**: **Currently** only through presets (Mild, Normal, Aggressive).

For advanced customization, you would need to:
1. Manually edit generated `.crproj` files
2. Or modify the preset generation code

> Future versions may add custom ConfuserEx configuration options.

---

### Q: How does Direct VPM Installer work?

**A**: When you export with VPM dependencies, the exporter automatically bundles:

1. **DirectVpmInstaller.cs** - Auto-installation script
2. **package.json** - With VPM dependencies and repository URLs
3. **FullDomainReload.cs** - Helper for proper reloading

When someone imports your package:
- Installer runs on first domain reload
- Prompts user to install missing VPM dependencies
- Downloads from VPM repositories automatically
- Installs packages and reloads project
- Self-deletes after completion

**Users don't need VCC (VRChat Creator Companion)!** The installer handles everything.

---

### Q: What is Smart Bundling?

**A**: Smart Bundling prevents compilation errors when bundling packages that have dependencies.

**The Problem**: If you bundle a package that uses VRCFury, it would try to compile before VRCFury is installed → compilation error.

**The Solution**: Smart Bundling adds `.yucp_disabled` extension to scripts:
- Prevents immediate compilation
- DirectVpmInstaller installs dependencies first
- Installer removes `.yucp_disabled` extensions
- Scripts compile successfully with dependencies present

> Happens automatically - no configuration needed.

---

### Q: Can users install my package without VCC?

**A**: **Yes!** With Direct VPM Installer:

Your package can be a simple `.unitypackage` file that users import normally. The bundled installer handles VPM dependencies automatically, no VCC required.

**Requirements**:
- Your dependencies must be on public VPM repositories
- Use **Dependency** mode (not Bundle) for VPM packages
- Keep **Generate Package.json** enabled

---

### Q: What happens if user cancels the installer?

**A**: If user clicks **Cancel** when prompted to install dependencies:

- Installer logs a warning to Console
- Installer scripts delete themselves
- Project may have compilation errors (missing dependencies)
- User can manually install dependencies later via `Tools → YUCP → Manual - Install VPM Dependencies`

---

### Q: Do the installer scripts stay in the project?

**A**: **No**. The installer is completely self-cleaning:

After successful installation:
1. Deletes `YUCP_TempInstall_*.json`
2. Deletes `YUCP_Installer_*.cs`
3. Deletes `YUCP_Installer_*.asmdef`
4. Deletes `YUCP_FullDomainReload_*.cs`
5. Refreshes AssetDatabase

Zero files remain after installation completes.

---

### Q: Can I test the installer before distributing?

**A**: **Yes**:

1. Export your package
2. Create a new test Unity project
3. Import your exported `.unitypackage`
4. Installer will run and prompt for dependencies
5. Test the installation flow

> Testing in a clean project ensures the installer works correctly for end users.

---

### Q: Can I re-import the same package multiple times?

**A**: **Yes!** The system fully supports re-importing:

**What happens**:
1. **GUID Management**: Fresh GUIDs for `.yucp_disabled` files prevent conflicts
2. **Version Detection**: Checks installed version vs. imported version
3. **Smart Replacement**: Only updates files when new version is newer
4. **Automatic Cleanup**: Removes orphaned `.yucp_disabled` files

**Safe for iterative development**:
- Export → Import → Test → Fix → Export → Re-import
- No GUID conflicts
- No orphaned files
- Clean, predictable behavior

---

### Q: What if VCC is not installed?

**A**: **No problem!** Direct VPM Installer works without VCC:

- Reads repository URLs from package.json
- Downloads packages directly from VPM repositories
- Doesn't require VRChat Creator Companion
- Works in any Unity project

> Users don't even need to know what VCC is!

---

### Q: How are repository URLs determined?

**A**: The system uses a smart detection process:

1. **Check VCC settings** (if VCC installed): Reads user's configured repositories
2. **Check vpm-manifest.json**: Finds repositories for installed packages
3. **Query repositories**: Tests each repo to see which hosts your dependencies
4. **Include only needed repos**: Only adds repositories that host your specific dependencies

**Result**: package.json includes minimal, accurate repository list.

---

### Q: What improvements were made for re-importing packages?

**A**: Several critical improvements for production use:

**1. Fresh GUID Generation**
- Disabled files get new GUIDs each time
- No conflicts with existing files
- Safe to re-import repeatedly

**2. Smart File Replacement**
- Compares file timestamps before replacing
- Only updates if new version is newer
- Preserves user modifications

**3. Automatic Orphan Cleanup**
- Deletes all `.yucp_disabled` files after enabling
- Removes associated `.meta` files
- Zero leftover files

**4. Version Detection**
- Checks if package already installed
- Skips re-extraction if same version
- Smart upgrade path for newer versions

**5. VCC Settings Integration**
- Reads VCC repository configuration
- Includes accurate repository URLs
- Works with custom VPM repositories

**Before improvements**:
```
Re-import package → GUID conflicts → Manual cleanup required
```

**After improvements**:
```
Re-import package → Smooth update → Zero conflicts → Auto cleanup
```

> Makes iterative development workflow seamless!

---

### Q: What's the advantage of Direct VPM Installer over traditional VPM?

**A**: Several major advantages:

**Traditional VPM Workflow**:
```
1. User downloads your .unitypackage
2. User opens VRChat Creator Companion (VCC)
3. User adds VPM repositories manually
4. User searches for and installs dependencies
5. User returns to Unity
6. User imports your .unitypackage
7. Finally ready to use
```

**With Direct VPM Installer**:
```
1. User imports your .unitypackage
2. Dialog prompts to install dependencies
3. Click "Install"
4. Done - everything ready!
```

**Benefits**:
- **No VCC required** - Works in any Unity project
- **One-click import** - Single .unitypackage file
- **Automatic** - No manual VPM setup
- **Self-contained** - Installer included in package
- **Beginner-friendly** - Less technical knowledge required

> Users don't even need to know what VPM is!

---

### Q: Can I disable Direct VPM Installer for a package?

**A**: **Yes**, simply use **Bundle** mode for all dependencies instead of Dependency mode.

When all dependencies are bundled:
- DirectVpmInstaller won't be added
- Package is completely self-contained
- Larger file size but no downloads needed
- No internet required for installation

---

### Q: Does Smart Bundling work for all file types?

**A**: Smart Bundling only affects **compilable files**:

| File Type | Smart Bundling Applied |
|-----------|------------------------|
| `.cs` files | ✓ Yes → `.cs.yucp_disabled` |
| `.asmdef` files | ✓ Yes → `.asmdef.yucp_disabled` |
| `.prefab` files | ✗ No (imported normally) |
| `.asset` files | ✗ No (imported normally) |
| `.shader` files | ✗ No (imported normally) |
| `.png`/`.jpg` etc. | ✗ No (imported normally) |

> Only scripts and assembly definitions are delayed to prevent compilation errors.

---

## For the Nerds

> **Deep technical dive into Package Exporter's internals, algorithms, and implementation details.**

This section is for developers, technical users, and anyone who wants to understand how Package Exporter works under the hood.

---

### System Architecture

The Package Exporter system consists of several interconnected components.

#### Core Components

| Component | File | Purpose |
|-----------|------|---------|
| **ExportProfile** | `ExportProfile.cs` | ScriptableObject holding profile data |
| **PackageBuilder** | `PackageBuilder.cs` | Main export logic and orchestration |
| **AssemblyScanner** | `AssemblyScanner.cs` | .asmdef → DLL mapping |
| **DependencyScanner** | `DependencyScanner.cs` | Package detection and analysis |
| **ConfuserExManager** | `ConfuserExManager.cs` | Obfuscation pipeline |
| **PackageIconInjector** | `PackageIconInjector.cs` | Icon injection into .tar.gz |
| **YUCPPackageExporterWindow** | `YUCPPackageExporterWindow.cs` | Main UI window |
| **ExportProfileEditor** | `ExportProfileEditor.cs` | Profile Inspector UI |

---

### Export Pipeline

The complete export process flow:

```
┌─────────────────────────────────────────┐
│ ExportPackage() called                  │
└────────────┬────────────────────────────┘
             ↓
┌─────────────────────────────────────────┐
│ Validate Profile                        │
│ - Folders exist                         │
│ - Name is valid                         │
│ - Settings are correct                  │
└────────────┬────────────────────────────┘
             ↓
┌─────────────────────────────────────────┐
│ Collect Assets to Export                │
│ - Recurse through folders               │
│ - Apply inclusion/exclusion filters     │
└────────────┬────────────────────────────┘
             ↓
┌─────────────────────────────────────────┐
│ Apply Exclusion Filters                 │
│ - File pattern matching                 │
│ - Folder name matching                  │
└────────────┬────────────────────────────┘
             ↓
    ┌────────┴────────┐
    │ Obfuscation?    │
    └────┬────────┬───┘
         Yes      No
         ↓        │
┌────────────────────┐
│ Obfuscation Steps  │
│ 1. Scan assemblies │
│ 2. Download ConfuserEx (if needed) │
│ 3. Generate .crproj │
│ 4. Copy DLLs to temp │
│ 5. Run ConfuserEx CLI │
│ 6. Copy obfuscated DLLs back │
└────────┬───────────┘
         │
         ↓←───────────┘
┌─────────────────────────────────────────┐
│ Generate package.json (if enabled)      │
│ - Dependencies list                     │
│ - VPM dependencies                      │
│ - Version info                          │
└────────────┬────────────────────────────┘
             ↓
┌─────────────────────────────────────────┐
│ Export Unity Package                    │
│ AssetDatabase.ExportPackage()           │
└────────────┬────────────────────────────┘
             ↓
    ┌────────┴────────┐
    │ Icon set?       │
    └────┬────────┬───┘
         Yes      No
         ↓        │
┌────────────────────┐
│ Icon Injection     │
│ 1. Extract .tar.gz │
│ 2. Inject icon.png │
│ 3. Repack .tar.gz  │
└────────┬───────────┘
         │
         ↓←───────────┘
┌─────────────────────────────────────────┐
│ Record Export Statistics                │
│ - Last export time                      │
│ - Increment export count                │
└────────────┬────────────────────────────┘
             ↓
┌─────────────────────────────────────────┐
│ Auto-increment Version (if enabled)     │
│ 1.0.0 → 1.0.1                          │
└────────────┬────────────────────────────┘
             ↓
┌─────────────────────────────────────────┐
│ Save Profile                            │
│ Write changes to ScriptableObject       │
└────────────┬────────────────────────────┘
             ↓
┌─────────────────────────────────────────┐
│ Return ExportResult                     │
│ - Success status                        │
│ - Output path                           │
│ - Build time                            │
│ - Error messages (if any)               │
└─────────────────────────────────────────┘
```

---

### ConfuserEx Integration

How the system integrates with ConfuserEx for code obfuscation.

#### Automatic Download Process
```csharp
const string CONFUSEREX_DOWNLOAD_URL = 
    "https://github.com/mkaring/ConfuserEx/releases/download/v1.6.0/ConfuserEx-CLI.zip";

using (var client = new WebClient())
{
    client.DownloadProgressChanged += (sender, e) => {
        progressCallback?.Invoke(0.2f + e.ProgressPercentage / 100f * 0.5f, 
                                $"Downloading ConfuserEx: {e.ProgressPercentage}%");
    };
    
    client.DownloadFileTaskAsync(CONFUSEREX_DOWNLOAD_URL, tempZipPath).Wait();
}

ExtractZipFile(tempZipPath, ConfuserExDirectory);
```

#### Project File Generation
```csharp
string GenerateProjectFile(List<Assembly> assemblies, ConfuserExPreset preset)
{
    var xml = new StringBuilder();
    xml.AppendLine("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
    xml.AppendLine("<project baseDir=\".\" outputDir=\"./Obfuscated\">");
    xml.AppendLine("  <rule pattern=\"true\" inherit=\"false\">");
    
    // Add protections based on preset
    xml.AppendLine(ConfuserExPresetGenerator.GenerateProtectionRules(preset));
    
    xml.AppendLine("  </rule>");
    
    // Add modules
    foreach (var assembly in assemblies)
    {
        xml.AppendLine($"  <module path=\"{assembly.name}.dll\" />");
    }
    
    xml.AppendLine("</project>");
    return xml.ToString();
}
```

#### ConfuserEx Execution
```csharp
var process = new Process
{
    StartInfo = new ProcessStartInfo
    {
        FileName = "Confuser.CLI.exe",
        Arguments = $"\"{projectFilePath}\"",
        WorkingDirectory = workingDir,
        RedirectStandardOutput = true,
        RedirectStandardError = true,
        CreateNoWindow = true
    }
};

process.Start();
process.WaitForExit();

if (process.ExitCode != 0)
    throw new Exception($"ConfuserEx failed with code {process.ExitCode}");
```

---

### Package.json Generation

How package.json files are generated for UPM/VPM compatibility.

```csharp
public static string GeneratePackageJson(ExportProfile profile, List<PackageDependency> dependencies)
{
    var packageJson = new JObject();
    
    packageJson["name"] = profile.packageName.ToLower().Replace(" ", ".");
    packageJson["displayName"] = profile.packageName;
    packageJson["version"] = profile.version;
    packageJson["description"] = profile.description;
    
    if (!string.IsNullOrEmpty(profile.author))
    {
        packageJson["author"] = new JObject { ["name"] = profile.author };
    }
    
    packageJson["unity"] = "2022.3";
    
    // Regular dependencies
    var regularDeps = dependencies.Where(d => d.enabled && !d.isVpmDependency).ToList();
    if (regularDeps.Count > 0)
    {
        var depsObj = new JObject();
        foreach (var dep in regularDeps)
        {
            depsObj[dep.packageName] = dep.packageVersion;
        }
        packageJson["dependencies"] = depsObj;
    }
    
    // VPM dependencies
    var vpmDeps = dependencies.Where(d => d.enabled && d.isVpmDependency).ToList();
    if (vpmDeps.Count > 0)
    {
        var vpmDepsObj = new JObject();
        foreach (var dep in vpmDeps)
        {
            vpmDepsObj[dep.packageName] = $">={dep.packageVersion}";
        }
        packageJson["vpmDependencies"] = vpmDepsObj;
    }
    
    return packageJson.ToString(Newtonsoft.Json.Formatting.Indented);
}
```

---

### Icon Injection Process

How custom icons are injected into Unity packages.

```csharp
public static bool AddIconToPackage(string packagePath, string iconPath, string outputPath)
{
    string tempDir = GetTemporaryDirectory();
    
    // Extract .tar.gz
    ExtractTarGz(packagePath, tempDir);
    
    // Copy icon
    string iconDest = Path.Combine(tempDir, "icon.png");
    File.Copy(iconPath, iconDest);
    
    // Repack with icon
    CreateTarGzWithIcon(outputPath, tempDir, iconDest);
    
    // Cleanup
    Directory.Delete(tempDir, true);
    
    return true;
}
```

> Uses **ICSharpCode.SharpZipLib** library for tar.gz compression and extraction operations.

---

### Assembly Scanning

How .asmdef files are discovered and mapped to DLL files.

```csharp
public static List<AssemblyInfo> ScanFolders(List<string> folders)
{
    var assemblies = new List<AssemblyInfo>();
    
    foreach (string folder in folders)
    {
        // Find all .asmdef files
        string[] asmdefFiles = Directory.GetFiles(folder, "*.asmdef", SearchOption.AllDirectories);
        
        foreach (string asmdefPath in asmdefFiles)
        {
            string assemblyName = ExtractAssemblyName(asmdefPath);  // Parse JSON
            string dllPath = FindDllPath(assemblyName);  // Library/ScriptAssemblies/
            
            assemblies.Add(new AssemblyInfo
            {
                assemblyName = assemblyName,
                asmdefPath = asmdefPath,
                dllPath = dllPath,
                exists = File.Exists(dllPath)
            });
        }
    }
    
    return assemblies;
}

private static string FindDllPath(string assemblyName)
{
    string libraryPath = Path.Combine(Application.dataPath, "..", "Library", "ScriptAssemblies");
    return Path.Combine(libraryPath, assemblyName + ".dll");
}
```

---

### Source Code Reference

Complete reference to all implementation files and their purposes.

#### Data Models

| File | Lines | Purpose |
|------|-------|---------|
| `ExportProfile.cs` | 217 | ScriptableObject profile data |
| `PackageDependency.cs` | 50 | Dependency data structure |
| `ConfuserExPreset.cs` | 131 | Obfuscation preset definitions |

**Location**: `Editor/PackageExporter/Data/`

#### Core Logic

| File | Lines | Purpose |
|------|-------|---------|
| `PackageBuilder.cs` | 513 | Main export orchestration |
| `AssemblyScanner.cs` | 184 | .asmdef scanning and DLL mapping |
| `DependencyScanner.cs` | 403 | Package dependency detection |
| `ConfuserExManager.cs` | 390 | Obfuscation pipeline management |
| `PackageIconInjector.cs` | 153 | Icon injection into packages |

**Location**: `Editor/PackageExporter/Core/`

#### UI Components

| File | Lines | Purpose |
|------|-------|---------|
| `YUCPPackageExporterWindow.cs` | 1169 | Main exporter window |
| `ExportProfileEditor.cs` | 675 | Profile Inspector UI |

**Location**: `Editor/PackageExporter/UI/`

#### Menu Items

| File | Lines | Purpose |
|------|-------|---------|
| `MenuItems.cs` | 137 | Unity menu integration |

**Location**: `Editor/PackageExporter/`

#### Templates

| File | Lines | Purpose |
|------|-------|---------|
| `DirectVpmInstaller.cs` | 469 | Auto-install VPM dependencies on import |
| `FullDomainReload.cs` | 75 | Helper for proper domain reloading |
| `Example_ExportProfile.asset` | N/A | Example export profile template |
| `README_Template.md` | 64 | Template documentation |

**Location**: `Editor/PackageExporter/Templates/`

#### Auto-Finalize

| File | Lines | Purpose |
|------|-------|---------|
| `YucpAutoFinalize.cs` | 85 | Post-compilation cleanup and UI refresh |

**Location**: `Editor/PackageExporter/AutoFinalize/`

---

### Performance Characteristics

Algorithm complexities and typical timings.

#### Time Complexity

| Operation | Complexity | Explanation |
|-----------|-----------|-------------|
| **Asset collection** | O(n) | Where n = files in folders |
| **Dependency scanning** | O(m × p) | Where m = assets, p = packages |
| **Obfuscation** | Variable | 5-30 seconds per assembly |
| **Icon injection** | O(1) | Fixed ~1-2 seconds |

#### Typical Export Times

| Configuration | Time Range |
|---------------|------------|
| **Small package, no obfuscation** | 10-30 seconds |
| **Medium package, no obfuscation** | 30-60 seconds |
| **Small package + Mild obfuscation** | 30-60 seconds |
| **Medium package + Normal obfuscation** | 1-2 minutes |
| **Large package + Aggressive obfuscation** | 2-5 minutes |

**Factors affecting speed**:
- Number of files to export
- Number of assemblies to obfuscate
- Obfuscation preset (Aggressive is slowest)
- Icon injection (minimal impact)
- Disk I/O speed

---

### ExportResult Structure

Data structure returned from export operations.

```csharp
public class ExportResult
{
    public bool success;
    public string errorMessage;
    public string outputPath;
    public float buildTimeSeconds;
    public int filesExported;
    public int assembliesObfuscated;
}
```

Used for logging, UI feedback, and error handling after export operations.

---

### Batch Export Implementation

How multiple profiles are exported sequentially.

```csharp
public static List<ExportResult> ExportMultiple(List<ExportProfile> profiles, 
    Action<int, int, float, string> progressCallback)
{
    var results = new List<ExportResult>();
    
    for (int i = 0; i < profiles.Count; i++)
    {
        var profile = profiles[i];
        
        progressCallback?.Invoke(i, profiles.Count, 0f, $"Exporting {profile.packageName}...");
        
        var result = ExportPackage(profile, (progress, status) => {
            progressCallback?.Invoke(i, profiles.Count, progress, status);
        });
        
        results.Add(result);
        
        if (!result.success)
            Debug.LogError($"Export failed for {profile.packageName}: {result.errorMessage}");
    }
    
    return results;
}
```

> **Note**: Batch export stops on first error unless configured otherwise. Check `ExportResult` for each profile.

---

### Direct VPM Installer Implementation

Technical details of the automatic VPM dependency installer.

#### Installation Flow

**File**: `Editor/PackageExporter/Templates/DirectVpmInstaller.cs`

```csharp
[InitializeOnLoad]
public static class DirectVpmInstaller
{
    static DirectVpmInstaller()
    {
        // Run on domain reload
        EditorApplication.delayCall += CheckAndInstallVpmPackages;
    }
    
    private static void CheckAndInstallVpmPackages()
    {
        // 1. Find temp install JSON
        string[] tempJsonFiles = Directory.GetFiles(Application.dataPath, 
            "YUCP_TempInstall_*.json", SearchOption.TopDirectoryOnly);
        
        if (tempJsonFiles.Length == 0) return;
        
        // 2. Parse package.json with vpmDependencies and vpmRepositories
        var packageInfo = JObject.Parse(File.ReadAllText(tempJsonFiles[0]));
        var vpmDependencies = packageInfo["vpmDependencies"] as JObject;
        var vpmRepositories = packageInfo["vpmRepositories"] as JObject;
        
        // 3. Check which packages need installation
        foreach (var dep in vpmDependencies.Properties())
        {
            if (!IsPackageInstalled(dep.Name, dep.Value.ToString()))
                packagesToInstall.Add(...);
        }
        
        // 4. Prompt user
        bool install = EditorUtility.DisplayDialog(
            "Install VPM Dependencies",
            $"This package requires:\n{packageList}\n\nInstall now?",
            "Install", "Cancel"
        );
        
        // 5. Lock assemblies to prevent mid-install compilation
        EditorApplication.LockReloadAssemblies();
        AssetDatabase.DisallowAutoRefresh();
        
        // 6. Install all packages
        foreach (var package in packagesToInstall)
        {
            InstallPackage(package.Item1, package.Item2, repositories);
        }
        
        // 7. Enable bundled packages (remove .yucp_disabled)
        EnableBundledPackages();
        
        // 8. Unlock and force full domain reload
        EditorApplication.UnlockReloadAssemblies();
        FullDomainReload.Run(() => { /* Complete */ });
        
        // 9. Cleanup temp files and self-delete
        CleanupTemporaryFiles();
    }
}
```

#### Version Resolution

The installer supports semantic versioning requirements:

| Requirement | Meaning | Example |
|-------------|---------|---------|
| `>=1.0.0` | Minimum version | Install 1.0.0 or higher |
| `^1.2.0` | Compatible within major | Install 1.x.x where x >= 2.0 |
| `~1.2.0` | Compatible within minor | Install 1.2.x where x >= 0 |
| `1.0.0` | Exact or higher | Install 1.0.0 or higher |

**Resolution algorithm**:
```csharp
private static bool VersionSatisfiesRequirement(string installed, string requirement)
{
    if (requirement.StartsWith(">="))
        return CompareVersions(installed, minVersion) >= 0;
    
    if (requirement.StartsWith("^"))
        return sameMajor && installed >= baseVersion;
    
    if (requirement.StartsWith("~"))
        return sameMajor && sameMinor && installed >= baseVersion;
    
    return CompareVersions(installed, requirement) >= 0;
}
```

#### VPM Repository Detection from VCC Settings

**File**: `Editor/PackageExporter/Core/DependencyScanner.cs`

The system reads VCC settings to get accurate repository URLs:

```csharp
private static Dictionary<string, string> GetRequiredRepositories(List<PackageDependency> vpmDeps)
{
    var repositories = new Dictionary<string, string>();
    
    // 1. Read VCC settings.json
    string vccSettingsPath = Path.Combine(
        Environment.GetFolderPath(SpecialFolder.LocalApplicationData),
        "VRChatCreatorCompanion",
        "settings.json"
    );
    
    if (File.Exists(vccSettingsPath))
    {
        var settings = JObject.Parse(File.ReadAllText(vccSettingsPath));
        var userRepos = settings["userRepos"] as JArray;
        
        // Extract repository URLs configured in VCC
        foreach (var repoObj in userRepos)
        {
            string repoUrl = repo["url"]?.ToString();
            string repoName = repo["name"]?.ToString();
            vccRepositories[repoName] = repoUrl;
        }
    }
    
    // 2. Add built-in repositories
    vccRepositories["VRChat Official"] = "https://packages.vrchat.com/official?download";
    vccRepositories["VRChat Curated"] = "https://packages.vrchat.com/curated?download";
    
    // 3. For each VPM dependency, find which repo hosts it
    foreach (var dep in vpmDeps)
    {
        string packageName = dep.packageName;
        
        foreach (var repo in vccRepositories)
        {
            try
            {
                // Query repository to check if it has this package
                string repoData = new WebClient().DownloadString(repo.Value);
                var repoJson = JObject.Parse(repoData);
                var packages = repoJson["packages"] as JObject;
                
                if (packages[packageName] != null)
                {
                    // This repo hosts the package - include it
                    repositories[repo.Key] = repo.Value;
                    break;
                }
            }
            catch { /* Skip failed repos */ }
        }
    }
    
    return repositories;
}
```

**Why Query Repositories?**
- Only includes repos that actually host your dependencies
- Reduces package.json size
- Faster DirectVpmInstaller execution (fewer repos to check)
- More accurate for custom VPM repositories

#### VPM Repository Integration

**Built-in repositories** (fallback if VCC not installed):
```csharp
var repositories = new Dictionary<string, string>
{
    { "VRChat Official", "https://packages.vrchat.com/official?download" },
    { "VRChat Curated", "https://packages.vrchat.com/curated?download" },
    { "VRCFury", "https://vpm.vrcfury.com/index.json" },
};
```

**Repository query**:
```csharp
// Download repository index
var repoData = JObject.Parse(new WebClient().DownloadString(repoUrl));

// Find package
var packages = repoData["packages"][packageName];
var versions = packages["versions"];

// Find best matching version
foreach (var version in versions)
{
    if (VersionSatisfiesRequirement(version.Name, requirement))
    {
        if (bestVersion == null || CompareVersions(version, bestVersion) > 0)
            bestVersion = version;
    }
}

// Download package
string downloadUrl = bestVersion["url"];
WebClient.DownloadFile(downloadUrl, tempZipPath);
ExtractToDirectory(tempZipPath, "Packages/{packageName}");
```

#### Self-Cleanup Mechanism

The installer removes all traces after installation, including orphaned disabled files:

```csharp
private static void CleanupTemporaryFiles(string packageJsonPath)
{
    // Delete temp package.json
    File.Delete("Assets/YUCP_TempInstall_*.json");
    File.Delete("Assets/YUCP_TempInstall_*.json.meta");
    
    // Delete installer script
    File.Delete("Assets/Editor/YUCP_Installer_*.cs");
    File.Delete("Assets/Editor/YUCP_Installer_*.cs.meta");
    File.Delete("Assets/Editor/YUCP_Installer_*.asmdef");
    File.Delete("Assets/Editor/YUCP_Installer_*.asmdef.meta");
    
    // Delete reload helper
    File.Delete("Assets/Editor/YUCP_FullDomainReload_*.cs");
    File.Delete("Assets/Editor/YUCP_FullDomainReload_*.cs.meta");
    
    // NEW: Delete all remaining .yucp_disabled files (orphan cleanup)
    string[] orphanedDisabled = Directory.GetFiles(
        "Packages/",
        "*.yucp_disabled",
        SearchOption.AllDirectories
    );
    
    foreach (string orphan in orphanedDisabled)
    {
        File.Delete(orphan);
        if (File.Exists(orphan + ".meta"))
            File.Delete(orphan + ".meta");
        
        Debug.Log($"[DirectVpmInstaller] Deleted orphaned: {orphan}");
    }
    
    // Refresh to remove from Unity
    AssetDatabase.Refresh();
    
    Debug.Log("[DirectVpmInstaller] Cleanup complete - all temporary files removed");
}
```

**What Gets Cleaned**:
1. Temporary package.json and meta
2. Installer scripts and asmdefs
3. Reload helper scripts
4. **All `.yucp_disabled` files** (NEW - prevents orphans)
5. All associated `.meta` files

> Complete cleanup ensures zero files remain after installation.

---

### Smart Bundling Implementation

How `.yucp_disabled` extension prevents premature compilation with GUID conflict prevention.

#### Bundling Process with Fresh GUID Generation

**File**: `Editor/PackageExporter/Core/PackageBuilder.cs`

```csharp
// When bundling a package in Bundle mode:
foreach (string file in packageFiles)
{
    string extension = Path.GetExtension(file);
    bool isCompilableScript = (extension == ".cs" || extension == ".asmdef");
    
    // Create pathname for Unity package
    string unityPathname = $"Packages/{packageName}/{relativePath}";
    
    // Add .yucp_disabled to compilable files
    if (isCompilableScript)
    {
        unityPathname += ".yucp_disabled";
    }
    
    // IMPORTANT: GUID handling
    string fileGuid;
    
    if (isCompilableScript)
    {
        // Generate FRESH GUID for disabled files
        // Prevents conflicts when re-importing same package
        fileGuid = Guid.NewGuid().ToString("N");
    }
    else
    {
        // Preserve original GUID for non-script files
        // Safe because these files don't get renamed
        fileGuid = AssetDatabase.AssetPathToGUID(file);
        if (string.IsNullOrEmpty(fileGuid))
            fileGuid = Guid.NewGuid().ToString("N");
    }
    
    // Add to package with pathname and GUID
    AddFileToPackage(file, unityPathname, fileGuid);
}
```

**GUID Strategy**:

| File State | GUID Strategy | Reason |
|------------|---------------|---------|
| **Non-disabled files** | Preserve original GUID | No renaming occurs, safe to preserve |
| **Disabled files** (.yucp_disabled) | Generate fresh GUID | Prevents conflicts with enabled version |

**Why Fresh GUIDs Matter**:

**Without fresh GUIDs** (old behavior):
```
Import package v1.0.0:
  MyScript.cs.yucp_disabled (GUID: abc123)
  
Installer enables:
  MyScript.cs (GUID: abc123)
  
Re-import package v1.0.1:
  MyScript.cs.yucp_disabled (GUID: abc123) → CONFLICT!
  Unity error: "GUID abc123 already in use by MyScript.cs"
```

**With fresh GUIDs** (new behavior):
```
Import package v1.0.0:
  MyScript.cs.yucp_disabled (GUID: NEW_xyz789)
  
Installer enables:
  MyScript.cs (preserves GUID from disabled version)
  
Re-import package v1.0.1:
  MyScript.cs.yucp_disabled (GUID: NEW_def456) → No conflict!
  Both can coexist temporarily
  Smart replacement handles version comparison
```

#### Enabling Bundled Packages with Smart Replacement

**DirectVpmInstaller** re-enables bundled packages with conflict prevention:

```csharp
private static void EnableBundledPackages()
{
    // Find all .yucp_disabled files in Packages folder
    string[] disabledFiles = Directory.GetFiles(
        "Packages/", 
        "*.yucp_disabled", 
        SearchOption.AllDirectories
    );
    
    int enabledCount = 0;
    
    foreach (string disabledFile in disabledFiles)
    {
        // Remove .yucp_disabled extension
        string enabledFile = disabledFile.Substring(0, 
            disabledFile.Length - ".yucp_disabled".Length);
        
        // Smart replacement: Check if target exists
        if (File.Exists(enabledFile))
        {
            // Compare timestamps - only replace if disabled file is newer
            DateTime existingTime = File.GetLastWriteTimeUtc(enabledFile);
            DateTime disabledTime = File.GetLastWriteTimeUtc(disabledFile);
            
            if (disabledTime <= existingTime)
            {
                // Existing file is newer - skip replacement, just delete disabled
                File.Delete(disabledFile);
                File.Delete(disabledFile + ".meta");
                continue;
            }
            
            // Disabled file is newer - delete old version first
            File.Delete(enabledFile);
            if (File.Exists(enabledFile + ".meta"))
                File.Delete(enabledFile + ".meta");
        }
        
        // Move file and meta (no conflict now)
        File.Move(disabledFile, enabledFile);
        if (File.Exists(disabledFile + ".meta"))
            File.Move(disabledFile + ".meta", enabledFile + ".meta");
        
        enabledCount++;
    }
    
    Debug.Log($"[DirectVpmInstaller] Enabled {enabledCount} bundled package files");
}
```

**Timeline**:
```
T0: Package imported
    → MyExtension.cs.yucp_disabled (won't compile)
    → VRCFury not installed yet

T1: DirectVpmInstaller runs
    → Downloads VRCFury
    → Installs to Packages/com.vrcfury/

T2: EnableBundledPackages() called
    → Renames MyExtension.cs.yucp_disabled
    → Becomes MyExtension.cs

T3: Domain reload
    → Scripts compile with VRCFury available
    → No compilation errors!
```

---

### Auto-Finalize System

Ensures proper UI updates and cleanup after compilation.

**File**: `Editor/PackageExporter/AutoFinalize/YucpAutoFinalize.cs`

```csharp
[InitializeOnLoad]
public static class YucpAutoFinalize
{
    static YucpAutoFinalize()
    {
        if (SessionState.GetBool("YUCP_Finalize_Pending", false))
            EditorApplication.update += Tick;
    }
    
    public static void Arm()
    {
        // Record baseline DLL timestamps
        var latest = Directory.GetFiles("Library/ScriptAssemblies", "*.dll")
                             .Select(File.GetLastWriteTimeUtc)
                             .Max();
        
        SessionState.SetString("YUCP_Finalize_BaselineUtcTicks", latest.Ticks);
        SessionState.SetBool("YUCP_Finalize_Pending", true);
        
        // Request compilation
        CompilationPipeline.RequestScriptCompilation();
        EditorUtility.RequestScriptReload();
    }
    
    private static void Tick()
    {
        // Check if new DLLs have been compiled
        long baseline = SessionState.GetString("YUCP_Finalize_BaselineUtcTicks");
        long latest = Directory.GetFiles("Library/ScriptAssemblies", "*.dll")
                               .Select(File.GetLastWriteTimeUtc)
                               .Max().Ticks;
        
        if (latest > baseline)
        {
            // New compilation detected - finalize
            InternalEditorUtility.RepaintAllViews();
            TryClearConsole();
            
            // Cleanup session state
            SessionState.EraseString("YUCP_Finalize_BaselineUtcTicks");
            SessionState.EraseBool("YUCP_Finalize_Pending");
            EditorApplication.update -= Tick;
        }
    }
}
```

**Purpose**:
- Detect when compilation completes
- Repaint all editor windows
- Clear console for clean state
- Used by FullDomainReload for proper finalization

---

### Recent Enhancements (Implemented)

Major features and critical bug fixes added to the Package Exporter:

#### Core Features

| Feature | Status | Description |
|---------|--------|-------------|
| **Direct VPM Installer** | ✓ Implemented | Auto-install VPM dependencies on import |
| **Smart Bundling** | ✓ Implemented | Delayed compilation with .yucp_disabled |
| **Full Domain Reload** | ✓ Implemented | Proper reload after dependency installation |
| **Auto-Finalize System** | ✓ Implemented | Post-compilation cleanup and UI refresh |
| **Export Templates** | ✓ Implemented | Example export profile included |
| **VPM Repository Detection** | ✓ Implemented | Auto-detect and include repository URLs |

#### Re-Import System Improvements

| Improvement | Status | Description |
|-------------|--------|-------------|
| **Fresh GUID Generation** | ✓ Fixed | Generate new GUIDs for .yucp_disabled files to prevent conflicts |
| **Orphan Cleanup** | ✓ Fixed | Automatically delete all .yucp_disabled files after enabling |
| **Smart File Replacement** | ✓ Fixed | Compare timestamps, only replace if newer |
| **Version Detection** | ✓ Fixed | Detect existing packages, skip re-extraction if same version |
| **VCC Settings Integration** | ✓ Implemented | Read VCC repositories for accurate URLs |

**Impact**: These improvements make the exporter fully production-ready with:
- **Zero GUID conflicts** on re-import
- **Zero orphaned files** after installation
- **Safe re-importing** of packages during development
- **Smart updates** that preserve user modifications

---

### Future Enhancements

Potential improvements and features for future versions.

| Feature | Description | Priority |
|---------|-------------|----------|
| **Git Integration** | Auto-commit and tag on successful export | High |
| **Automated Testing** | Run unit tests before allowing export | High |
| **Changelog Generation** | Auto-generate CHANGELOG.md from git commits | Medium |
| **Multi-Platform Support** | Export for different Unity versions simultaneously | Medium |
| **Compression Options** | Choose compression levels for .unitypackage | Low |
| **Digital Signing** | Sign packages for authenticity verification | Medium |
| **Upload Automation** | Auto-upload to VPM repositories or storage | High |
| **Custom ConfuserEx Config** | Advanced obfuscation configuration options | Medium |
| **Scheduled Exports** | Automated exports on a schedule | Low |
| **Dependency Version Lock** | Pin exact versions instead of ranges | Medium |
| **Custom Repository URLs** | Add custom VPM repository URLs via UI | Medium |

---

## End of Documentation

This documentation covers all aspects of Package Exporter from basic usage to advanced technical details. For additional support, consult the source code or contact the developer.

**Key Takeaways**:
- Export profiles provide reusable, reproducible package exports
- ConfuserEx obfuscation protects commercial code
- **Direct VPM Installer** enables zero-setup imports (no VCC required!)
- **Smart Bundling** prevents compilation errors with .yucp_disabled
- **Fresh GUID generation** prevents conflicts on re-import
- **Smart replacement** preserves user modifications
- **Automatic cleanup** removes all temporary and orphaned files
- Dependency management ensures proper package relationships
- Batch export enables efficient multi-package workflows
- VPM compatibility makes distribution easy

**Major Features**:
- Users can import your .unitypackage and dependencies auto-install
- No VRChat Creator Companion (VCC) required
- Bundled packages compile only after dependencies ready
- Completely automatic installation and cleanup
- **Safe re-importing** during iterative development
- **Zero GUID conflicts** even with repeated imports
- **Production-ready** with robust error handling

**Quick Links**:
- [Quick Start](#quick-start)
- [Export Profile Settings](#export-profile-settings)
- [Troubleshooting](#troubleshooting)
- [FAQ](#faq)
- [For the Nerds](#for-the-nerds)

