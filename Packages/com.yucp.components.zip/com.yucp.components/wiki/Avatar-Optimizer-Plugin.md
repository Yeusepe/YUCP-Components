# Avatar Optimizer Plugin

The **Avatar Optimizer Plugin** provides seamless integration with [d4rkAvatarOptimizer](https://github.com/d4rkc0d3r/d4rkAvatarOptimizer), allowing you to configure optimization settings **per-avatar** with YUCP's modern UI.

## Overview

This component acts as a bridge between YUCP Components and d4rkAvatarOptimizer, giving you fine-grained control over avatar optimization on a **per-avatar basis**. Each avatar can have different optimizer settings - perfect for managing multiple avatars with different optimization needs.

### Per-Avatar Configuration

Unlike global optimizer settings, this plugin lets you:
- Configure different optimization levels for different avatars
- Have aggressive optimization on simple avatars
- Use conservative settings on complex or delicate avatars
- Test optimization settings per-avatar without affecting others

## Features

### Core Features
- **Per-Avatar Configuration**: Each avatar gets its own unique optimizer settings
- **One-Click Installation**: Install d4rkAvatarOptimizer directly from the inspector via VPM
- **Dual UI Modes**: 
  - **Preset Mode**: Simple preset-based configuration (Conservative/Balanced/Aggressive)
  - **Advanced Mode**: Full control over 20+ individual optimization settings
- **Automatic Detection**: Instantly detects if d4rkAvatarOptimizer is installed
- **Smart Defaults**: Auto-detect settings based on avatar complexity
- **Transform Exclusions**: Exclude specific transforms from optimization per-avatar
- **YUCP UI**: Consistent modern interface with other YUCP components
- **Build Statistics**: View optimizer status and applied settings count after builds
- **Independent Settings**: Multiple avatars in the same project can have completely different optimization profiles
- **Seamless Integration**: Works automatically with Auto Body Hider and other YUCP components

## Requirements

- **Optional**: d4rkAvatarOptimizer (https://github.com/d4rkc0d3r/d4rkAvatarOptimizer)
  - If not installed, the component will show a warning and remain disabled
  - All settings are hidden until the optimizer is installed

## How to Use

### 1. Add the Component First

1. **Select your avatar root** (the GameObject with VRCAvatarDescriptor)
2. Add Component → YUCP → Avatar Optimizer Plugin
3. The component will appear in the Inspector

### 2. Install d4rkAvatarOptimizer (If Not Already Installed)

The inspector will detect if d4rkAvatarOptimizer is installed:

**If NOT Installed:**
- A large green "Install d4rkAvatarOptimizer" button appears
- Click it for automatic VPM installation
- Unity will download and install the package (30-60 seconds)
- Inspector updates automatically when complete

**Alternative Manual Installation:**
- Click "Open GitHub Releases Page" button
- Download the latest .unitypackage
- Import into Unity project
- Click "Check If Installed" to verify

### 3. Choose UI Mode

The plugin offers two UI modes to suit different experience levels:

#### Preset Mode (Recommended for Most Users)
- Simple interface with preset configurations
- Quick "one-click" optimization setup
- Three presets:
  - **Conservative**: Safe settings for complex avatars
  - **Balanced**: Good mix of optimization and safety
  - **Aggressive**: Maximum optimization (test carefully!)
- Auto-Settings option for automatic configuration
- Shows clear overview of enabled optimizations

#### Advanced Mode (For Experienced Users)
- Full access to all 20+ optimizer settings
- Organized into collapsible categories
- Fine-tune every aspect of optimization
- Platform-specific warnings (e.g., Windows-only features)
- Detailed tooltips for every setting

Switch between modes using the toggle at the top of the inspector.

### 4. Configure Settings

#### Preset Mode Configuration

**Option 1: Auto Settings (Recommended)**
- Enable "Auto-Detect Settings"
- The optimizer analyzes your avatar and chooses optimal settings automatically
- Best for most users

**Option 2: Manual Presets**
- Disable "Auto-Detect Settings"
- Choose one of three presets:
  - **Conservative**: Basic mesh merging, FX optimization, component cleanup
  - **Balanced**: Add NaNimation merging, animation combining, safe GameObject deletion
  - **Aggressive**: All features enabled, including material merging and texture arrays

#### Advanced Mode Configuration

All settings are organized into clear, collapsible categories:

**1. Mesh Merging**
- Merge Skinned Meshes: Combines multiple skinned meshes
- Include Static Meshes: Converts and merges static meshes too

**2. Advanced Mesh Merging**
- Shader Toggle Level (0-2): Uses shader-based mesh toggling
- NaNimation Level (0-2): Uses NaN in animations for visibility
- Allow 3-Bone Skinning: More aggressive NaNimation merging
- Separate by Default State: Keeps meshes with different default states apart

**3. Material Optimization**
- Merge Different Property Materials: Creates unified optimized shaders
- Merge Textures to Arrays: Combines similar textures into arrays
- Include Main Textures: Merges _MainTex properties
- Write Static Properties: Bakes non-animated properties into shader

**4. FX Layer Optimization**
- Optimize FX Layer: Merges and cleans up animator layers
- Combine Similar-Length Animations: Merges animations with similar durations

**5. Component Cleanup**
- Disable Unused PhysBones: Auto-disables inactive PhysBones
- Delete Unused Components: Removes IEditorOnly and unused components
- Delete Unused GameObjects (0-2): Removes empty/unused objects

**6. Blendshape Optimization**
- Merge Same-Ratio Blendshapes: Combines blendshapes that move together
- MMD Compatibility: Preserves MikuMikuDance blendshapes

**7. Advanced Features**
- Ring Finger → Foot Collider: Moves contact receiver to feet

**8. Exclusions**
- Excluded Transforms: Objects to protect from all optimizations

**9. Inspector Display**
- Show Mesh Merge Preview: Displays merge preview in inspector
- Show FX Layer Results: Shows FX layer optimization results
- Show Debug Info: Detailed debug information

**10. Debug & Profiling**
- Profile Time Used: Shows time spent on each optimization
- Debug Logging: Detailed console logs

## Presets Explained

### Conservative Preset
**Best for:** Complex avatars with many custom systems, toggles, or posebones
- Basic mesh merging only
- FX layer optimization
- Component cleanup (safe mode)
- Blendshape merging with MMD compatibility
- **Safest option** - unlikely to break anything

### Balanced Preset  
**Best for:** Most avatars - good performance improvement without major risks
- Mesh merging + static mesh conversion
- Basic NaNimation merging
- FX layer + animation combining
- Component cleanup (safe mode)
- PhysBone optimization
- **Recommended starting point** for most users

### Aggressive Preset
**Best for:** Simple avatars, final optimization, or high-poly models needing maximum reduction
- All mesh merging techniques enabled
- Advanced NaNimation + Shader toggles
- Material merging with texture arrays
- Aggressive component/GameObject deletion
- Ring finger collider moved to feet
- **Test thoroughly** - may break some features

## Tips and Best Practices

1. **Start Simple**: Begin with Auto Settings or Conservative preset
2. **Test After Each Change**: Build and test your avatar after changing presets
3. **Use Preset Mode**: Unless you're experienced, stick to Preset Mode
4. **Protect Custom Systems**: Add posebones, penetrators, and custom systems to Exclusions
5. **Platform Matters**: Material merging only works on Windows build target
6. **Multiple Avatars**: Each avatar can have different settings - no need to change between uploads

## Per-Avatar Basis

Each avatar in your project can have its own optimizer configuration:

- **Avatar A**: Aggressive optimization (simple model, high poly count)
- **Avatar B**: Conservative optimization (complex setup, many toggles)
- **Avatar C**: No optimization (uses custom systems that break with optimizer)

Simply add the Avatar Optimizer Plugin to each avatar's root GameObject and configure independently. When you build an avatar, only its plugin settings are used - other avatars in the scene are unaffected.

### One Plugin Per Avatar

The component uses `[DisallowMultipleComponent]` and requires `VRCAvatarDescriptor`, so you can only have one per avatar. This ensures clean, predictable configuration.

## Troubleshooting

### "d4rkAvatarOptimizer Not Installed" Warning

**Solutions:**
1. **Automatic Install (Recommended)**: Click the large green "Install d4rkAvatarOptimizer" button in the inspector
2. **Manual Install**: Click "Manual Install - Open GitHub Releases", download .unitypackage, and import
3. **Verify Installation**: After installing, click "Check If Installed" to confirm

### Installation Takes Too Long

**Normal behavior**: VPM package installation can take 30-60 seconds
- Unity is downloading the package
- Compiling the code
- Resolving dependencies

**If it takes longer than 2 minutes:**
1. Check Unity console for errors
2. Try manual installation from GitHub instead
3. Check your internet connection

### "Invalid Placement" Error

**Solution**: The component must be on the avatar root (same GameObject as VRCAvatarDescriptor)
- Click "Find Avatar Root and Move Component" button to auto-fix
- Or manually move the component to the correct GameObject

### Optimizer Not Running

**Solution**: Check that "Apply On Upload" is enabled in the plugin settings.

### Avatar Breaks After Optimization

**Solutions**:
1. Add problematic transforms to the Exclusion list
2. Disable specific optimization features one by one to find the culprit
3. Try "Apply Recommended" settings for a safer configuration
4. Enable Debug Mode to see what the optimizer is doing

### Material Merging Not Working

**Solution**: Material property merging requires Windows build target. Check your Build Settings.

## Integration with Auto Body Hider

The Avatar Optimizer Plugin works seamlessly with Auto Body Hider for coordinated optimization:

### How They Work Together

1. **Auto Body Hider runs first** (early in build pipeline)
   - Detects hidden vertices
   - Applies UDIM discards to body mesh
   - Creates toggles for clothing

2. **Avatar Optimizer Plugin runs later** (late in build pipeline)
   - Receives the already-modified body mesh
   - Merges body mesh with other meshes if settings allow
   - Optimizes materials and FX layer
   - Preserves UDIM discard functionality

### Benefits of Combined Use

- **Reduced Draw Calls**: Body mesh can be merged with other meshes after UDIM modification
- **Preserved Toggles**: Clothing toggles continue to work after mesh merging
- **Better Performance**: Combines UDIM-based body hiding with overall avatar optimization
- **No Conflicts**: Both systems are designed to work together

### Recommended Settings for Auto Body Hider + Optimizer

**If using UDIM Discard mode:**
- Conservative Preset: Safe mesh merging that preserves UDIM materials
- Balanced Preset: Good optimization while maintaining material functionality
- Avoid Aggressive material merging if you have complex UDIM setups

**If using Mesh Deletion mode:**
- Any preset works fine since the body mesh is permanently modified
- Aggressive preset is safe to use

### Example Workflow

1. Add Auto Body Hider to clothing objects
2. Configure UDIM discard settings
3. Add Avatar Optimizer Plugin to avatar root
4. Choose Balanced preset
5. Build avatar
6. Both systems work together automatically!

## Integration with Other YUCP Components

The Avatar Optimizer Plugin is designed to work with all YUCP components:

- **Auto Grip**: Optimizer preserves grip animations and hand bones
- **All Auto-Link Components**: Optimizer respects VRCFury armature links
- **Gesture Manager Input Emulator**: Optimizer preserves runtime input handlers
- **Model Revision System**: Optimizer works with transferred components

The plugin runs very late in the build pipeline (just before the optimizer itself) to ensure all other YUCP components have completed their processing first.

## Build Statistics

After building your avatar, the plugin shows:
- **Optimizer Detected**: Whether d4rkAvatarOptimizer was found
- **Optimization Applied**: Whether settings were successfully applied
- **Build Error**: Any errors that occurred during processing

## Links

- [d4rkAvatarOptimizer GitHub](https://github.com/d4rkc0d3r/d4rkAvatarOptimizer)
- [d4rkAvatarOptimizer Documentation](https://github.com/d4rkc0d3r/d4rkAvatarOptimizer/blob/main/README.md)
- [YUCP Components](https://github.com/Yeusepe/Yeusepes-Modules)

