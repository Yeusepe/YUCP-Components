# Symmetric Armature Auto-Link

**Automatically attach objects to left/right body parts with intelligent side detection.**

## Overview

The Symmetric Armature Auto-Link component (`AttachToBodyPartData`) automatically determines whether an accessory should attach to the left or right side of the avatar and creates the appropriate VRCFury armature link during build time.

### Key Features
- **Automatic side detection** - Analyzes accessory position to pick closest side
- **Manual override** - Force left or right if needed
- **Component cleanup** - Optionally delete components based on chosen side
- **Offset support** - Fine-tune attachment with path offsets
- **Zero runtime overhead** - Converts to VRCFury armature link at build

### Why Use This?

Instead of manually creating two versions of an accessory (one for left, one for right) or manually setting up VRCFury armature links, this component:

1. Lets you place the accessory once in your scene
2. Automatically detects which side it should go on
3. Converts to a proper armature link at build time
4. Optionally cleans up unused mirror components

## Use Cases

- **Earrings** - Place one earring, auto-detects left/right ear
- **Knee pads** - Single knee pad automatically attaches to correct leg
- **Shoulder accessories** - Pauldrons, armor pieces, badges
- **Arm/leg bands** - Bracelets, anklets, arm wraps
- **Hand accessories** - Rings, wrist accessories
- **Finger attachments** - Rings that need precise finger bone attachment
- **Eye accessories** - Monocles, eye patches

## Quick Start

1. **Import your accessory** into your avatar scene
2. **Position it** on the desired side (left or right)
3. **Add component**: `Add Component → YUCP → Symmetric Armature Auto-Link`
4. **Configure**:
   - Set `Body Part` (e.g., "UpperArm", "Hand", "Foot")
   - Set `Side` to "Closest" (auto-detect) or force "Left"/"Right"
5. **Build avatar** - Component handles everything automatically

[Image: Unity Inspector showing Symmetric Armature Auto-Link component with Body Part dropdown and Side selection]

## Component Settings

### Target Settings

#### Body Part
**Type**: Dropdown enum  
**Default**: `UpperLeg`  
**Description**: Which symmetric body part to attach to.

Available body parts:
- **Leg parts**: UpperLeg, LowerLeg, Foot, Toes
- **Arm parts**: Shoulder, UpperArm, LowerArm, Hand
- **Finger parts**: ThumbProximal/Intermediate/Distal, IndexProximal/Intermediate/Distal, MiddleProximal/Intermediate/Distal, RingProximal/Intermediate/Distal, LittleProximal/Intermediate/Distal
- **Eye parts**: Eye

**Tooltip**: "Which symmetric body part to attach to."

#### Side
**Type**: Dropdown enum (Left, Right, Closest)  
**Default**: `Closest`  
**Description**: For symmetric parts, which side to use.

- **Left** - Force attachment to left side
- **Right** - Force attachment to right side  
- **Closest** - Automatically detect based on accessory position

**Tooltip**: "For symmetric parts, pick a side (or Closest)."

#### Offset
**Type**: String  
**Default**: `""` (empty)  
**Description**: Optional bone path offset for fine-tuning attachment.

Examples:
- `""` - Attach directly to the bone
- `"Clothing/Sleeve"` - Attach to a child object under the bone
- `"../OtherBone"` - Navigate up and to another bone

**Tooltip**: "Optional offset string for fine tuning the attachment."

### Auto-Delete Components

#### Delete if Left
**Type**: Component reference  
**Default**: `None`  
**Description**: Component to destroy if the left side is selected.

**Use case**: You have a mirror component that should only exist on the opposite side.

**Tooltip**: "Drag in the Component you want destroyed if Left is selected."

#### Delete if Right
**Type**: Component reference  
**Default**: `None`  
**Description**: Component to destroy if the right side is selected.

**Use case**: You have a mirror component that should only exist on the opposite side.

**Tooltip**: "Drag in the Component you want destroyed if Right is selected."

## Step-by-Step Tutorial

### Example: Adding Symmetric Earrings

Let's walk through adding a pair of earrings that automatically attach to the correct ear.

#### Step 1: Import the Earring Model
1. Import your earring 3D model into Unity
2. Drag it into your avatar hierarchy
3. Position it near the left or right ear

[Image: Earring model positioned near avatar's ear in Scene view]

#### Step 2: Add the Component
1. Select the earring GameObject
2. Click `Add Component`
3. Type "Symmetric" and select `YUCP → Symmetric Armature Auto-Link`

[Image: Add Component menu with YUCP components listed]

#### Step 3: Configure the Component
1. In the Inspector, find the component settings
2. Set `Body Part` to **"Head"** (earrings attach to head since there's no ear bone in humanoid rig)
3. Set `Side` to **"Closest"**
4. Leave `Offset` empty for now

[Image: Inspector showing configured Symmetric Armature component]

> **Note**: If your avatar has custom ear bones (non-humanoid), you may need to use the Closest Bone Auto-Link component instead.

#### Step 4: Create the Mirror Side (Optional)
If you want both earrings:
1. Duplicate the earring GameObject (`Ctrl+D`)
2. Move it to the opposite ear
3. The component will automatically detect which side each earring is on

[Image: Both earrings positioned in Scene view]

#### Step 5: Build and Test
1. Build your avatar (`VRChat SDK → Build & Publish`)
2. During build, the components will:
   - Detect which earring is closest to left/right head
   - Create VRCFury armature links automatically
   - The components are removed (processed at build time)

[Image: Console log showing "Linked 'Earring_L' → Head" and "Linked 'Earring_R' → Head"]

### Example: Knee Pad with Component Cleanup

Let's add a knee pad that deletes its mirror component based on which side is chosen.

#### Step 1: Setup
1. Import knee pad model
2. Position it on one knee (left or right)
3. Add `Symmetric Armature Auto-Link` component
4. Set `Body Part` to **"UpperLeg"**
5. Set `Side` to **"Closest"**

#### Step 2: Add Mirror Component
1. Suppose your knee pad has a `MirrorReflection` component that needs different settings for left/right
2. Create two MirrorReflection components on the knee pad
3. Name them "MirrorReflection_Left" and "MirrorReflection_Right"
4. Configure each for its respective side

#### Step 3: Configure Auto-Delete
1. In the Symmetric Armature component:
   - Drag `MirrorReflection_Left` into **"Delete if Right"** field
   - Drag `MirrorReflection_Right` into **"Delete if Left"** field

2. At build time:
   - If left knee is chosen → `MirrorReflection_Right` is deleted
   - If right knee is chosen → `MirrorReflection_Left` is deleted

[Image: Inspector showing Delete if Left/Right fields populated with component references]

## Advanced Features

### Working with Finger Bones

The component supports all finger bones in the humanoid rig:

```
- ThumbProximal, ThumbIntermediate, ThumbDistal
- IndexProximal, IndexIntermediate, IndexDistal  
- MiddleProximal, MiddleIntermediate, MiddleDistal
- RingProximal, RingIntermediate, RingDistal
- LittleProximal, LittleIntermediate, LittleDistal
```

**Example: Finger Ring**
1. Add component to ring object
2. Set `Body Part` to **"RingDistal"** (tip of ring finger)
3. Set `Side` to **"Closest"**
4. Position ring on the finger
5. Build - ring attaches to correct hand's ring finger tip

### Using Offsets for Complex Hierarchies

Offsets allow you to navigate bone hierarchies:

**Example: Attach to a child bone**
```
Offset: "Armor/Plate"
Result: Attaches to {SelectedBone}/Armor/Plate
```

**Example: Attach to a sibling bone**
```
Offset: "../OtherBone"
Result: Navigates up one level, then to OtherBone
```

**Example: Complex path**
```
Offset: "Equipment/Slot_01/Attachment"
Result: Attaches to {SelectedBone}/Equipment/Slot_01/Attachment
```

### Combining with VRCFury Features

Since this component creates a VRCFury Armature Link, it's compatible with all VRCFury features:

- **Bake transforms** - The link bakes the current offset
- **Scale matching** - Automatically matches bone scaling
- **Multiple links** - Use multiple components on the same object for different targets

## Troubleshooting

### "Cannot resolve bone" Error

**Problem**: Build log shows "Cannot resolve bone part=X, side=Y"

**Solutions**:
1. Check that your avatar has a valid Humanoid rig
2. Verify the selected body part exists (e.g., some avatars don't have all finger bones)
3. Try a different body part that's guaranteed to exist (e.g., Hand instead of finger bones)

### Wrong Side Selected

**Problem**: Component chose the wrong side.

**Solutions**:
1. **Force the side**: Change `Side` from "Closest" to "Left" or "Right"
2. **Reposition the object**: Move it further away from the center line
3. **Check pivot point**: The component uses the GameObject's position, not the mesh center

### Component Not Processing

**Problem**: Component still exists after build.

**Causes**:
1. VRCFury not installed
2. Component disabled
3. Build failed before preprocessing

**Solutions**:
1. Install VRCFury via VCC
2. Ensure component is enabled (checkbox in Inspector)
3. Check Unity Console for build errors

### Object Not Following Bone

**Problem**: After upload, object doesn't move with the bone.

**Solutions**:
1. Check VRCFury processed correctly (look for VRCFury components in build output)
2. Verify no errors in Console during build
3. Try rebuilding from scratch (clear cache)

## FAQ

### Q: Can I use this on non-humanoid bones?
**A**: No. This component only works with Unity's humanoid bone system. For custom bones (ears, tails, etc.), use the [Closest Bone Auto-Link](Closest-Bone-Auto-Link.md) component instead.

### Q: Does this work with Modular Avatar?
**A**: This component creates VRCFury armature links. For Modular Avatar compatibility, use Modular Avatar's own bone proxy system.

### Q: Can I attach to the same bone from multiple objects?
**A**: Yes! Multiple objects can use this component to attach to the same bone.

### Q: What happens if I set Side to "Closest" but the object is perfectly centered?
**A**: The component will choose left side as the default when distances are equal.

### Q: Can I preview which side will be selected before building?
**A**: Not currently in the UI, but you can check the distance in Scene view. The component chooses whichever side bone is closer to the object's world position.

### Q: Does the component handle rotation/scale?
**A**: The VRCFury armature link bakes the current transform offset (position, rotation, scale) at build time.

### Q: Can I use this for asymmetric objects?
**A**: Yes, but you'll need to set `Side` to "Left" or "Right" explicitly instead of using "Closest".

## Examples

### Example 1: Simple Earring
```
Component Settings:
- Body Part: Head
- Side: Closest
- Offset: (empty)
- Delete if Left: None
- Delete if Right: None

Result: Earring attaches to head bone on the closest side
```

### Example 2: Knee Pad with Mirror Deletion
```
Component Settings:
- Body Part: LowerLeg
- Side: Closest
- Offset: (empty)
- Delete if Left: RightKneePadComponent
- Delete if Right: LeftKneePadComponent

Result: Knee pad attaches to closest leg, deletes the wrong-side component
```

### Example 3: Ring on Index Finger
```
Component Settings:
- Body Part: IndexDistal
- Side: Right (forced)
- Offset: (empty)
- Delete if Left: None
- Delete if Right: None

Result: Ring always attaches to right hand index finger tip
```

### Example 4: Shoulder Armor with Child Offset
```
Component Settings:
- Body Part: Shoulder
- Side: Closest
- Offset: Armor/MountPoint
- Delete if Left: None
- Delete if Right: None

Result: Armor attaches to {LeftShoulder or RightShoulder}/Armor/MountPoint
```

## For the Nerds

### Technical Architecture

The Symmetric Armature Auto-Link component is implemented using VRChat's build pipeline preprocessing system.

#### Component Class
**File**: `Runtime/Components/Data/AttachToBodyPartData.cs`

```csharp
public class AttachToBodyPartData : MonoBehaviour, 
    IEditorOnly, IPreprocessCallbackBehaviour
{
    public enum BodyPart { UpperLeg, LowerLeg, Foot, ... }
    public enum Side { Left, Right, Closest }
    
    public BodyPart part;
    public Side side = Side.Closest;
    public string offset = "";
    public Component leftComponentToDelete;
    public Component rightComponentToDelete;
}
```

#### Processor Class
**File**: `Editor/Components/Processors/AttachToBodyPartProcessor.cs`

```csharp
public class AttachToBodyPartProcessor : IVRCSDKPreprocessAvatarCallback
{
    public int callbackOrder => int.MinValue; // Run very early
    
    public bool OnPreprocessAvatar(GameObject avatarRoot)
    {
        // Process all AttachToBodyPartData components
        // Create VRCFury armature links
        // Delete specified components
    }
}
```

### Preprocessing Pipeline

The component uses VRChat SDK's `IVRCSDKPreprocessAvatarCallback` system:

1. **Build starts** - VRChat SDK begins avatar upload/build process
2. **Preprocessing phase** - All callbacks with `callbackOrder` execute in order
3. **AttachToBodyPartProcessor runs** (at `int.MinValue` - very early)
4. **Side detection** - `GetSelectedSide()` determines left/right
5. **Component deletion** - Optional cleanup based on side
6. **Bone resolution** - `TryResolveBone()` converts BodyPart+Side to HumanBodyBones
7. **VRCFury link creation** - `FuryComponents.CreateArmatureLink()`
8. **Offset application** - Applies offset path to link
9. **Component removal** - The original component is left in scene (VRCFury processes it later)

### Side Detection Algorithm

```csharp
public Side GetSelectedSide(Animator animator)
{
    if (side != Side.Closest)
        return side; // User forced a side
    
    // Get both side bones
    if (!TryResolveBone(animator, out HumanBodyBones leftBone, out HumanBodyBones rightBone))
        return Side.Left; // Fallback
    
    Transform leftT = animator.GetBoneTransform(leftBone);
    Transform rightT = animator.GetBoneTransform(rightBone);
    
    // Calculate distances
    float leftDist = Vector3.Distance(transform.position, leftT.position);
    float rightDist = Vector3.Distance(transform.position, rightT.position);
    
    // Choose closest
    return leftDist <= rightDist ? Side.Left : Side.Right;
}
```

**Distance calculation**:
- Uses world-space positions
- Straight-line distance (Euclidean)
- Equal distances default to left side
- Calculated once per build

### Bone Resolution

The component maps `BodyPart` enum + `Side` enum to Unity's `HumanBodyBones`:

```csharp
public bool TryResolveBone(Animator animator, out HumanBodyBones result)
{
    Side chosenSide = GetSelectedSide(animator);
    
    switch (part)
    {
        case BodyPart.UpperArm:
            result = chosenSide == Side.Left 
                ? HumanBodyBones.LeftUpperArm 
                : HumanBodyBones.RightUpperArm;
            return true;
        
        case BodyPart.IndexDistal:
            result = chosenSide == Side.Left 
                ? HumanBodyBones.LeftIndexDistal 
                : HumanBodyBones.RightIndexDistal;
            return true;
        
        // ... all other body parts
    }
}
```

### VRCFury Integration

The processor creates a VRCFury Armature Link using the VRCFury API:

```csharp
// Create link
var link = FuryComponents.CreateArmatureLink(data.gameObject);

// Configure link
link.LinkTo(bone, data.offset);

// Example result:
// LinkTo(HumanBodyBones.LeftUpperArm, "Armor/MountPoint")
// → Links to LeftUpperArm/Armor/MountPoint
```

**VRCFury API Reference**:
- `FuryComponents.CreateArmatureLink(GameObject)` - Creates `VRCFuryArmatureLink` component
- `link.LinkTo(HumanBodyBones, string)` - Sets target bone and offset path
- `link.LinkTo(string)` - Alternative: use full bone path

### Callback Order

**Order**: `int.MinValue` (approximately -2,147,483,648)

**Why so early?**
- Runs before most other systems
- Ensures bone links are set up before other components that might depend on them
- Avoids conflicts with other preprocessors

**Execution sequence**:
```
1. AttachToBodyPartProcessor (int.MinValue)
2. AttachToClosestBoneProcessor (int.MinValue)  
3. AttachToViewPositionProcessor (int.MinValue)
4. ... (other YUCP processors)
5. AutoBodyHiderCoordinator (int.MinValue + 99)
6. AutoBodyHiderProcessor (int.MinValue + 100)
7. ... (VRCFury processors run later)
```

### Component Deletion Mechanism

```csharp
Component toDelete = (chosenSide == Side.Left)
    ? data.leftComponentToDelete
    : data.rightComponentToDelete;

if (toDelete != null)
{
    if (toDelete is Transform tr)
        Object.DestroyImmediate(tr.gameObject); // Delete entire GameObject
    else
        Object.DestroyImmediate(toDelete); // Delete just the component
}
```

**Important notes**:
- Uses `DestroyImmediate` during build preprocessing
- If deleting a Transform, destroys the entire GameObject
- Other component types are deleted individually
- Deletion happens BEFORE VRCFury link creation

### Progress Window Integration

The processor uses YUCP's custom progress window:

```csharp
var progressWindow = YUCPProgressWindow.Create();
progressWindow.Progress(0, "Processing symmetric armature links...");

// ... processing loop ...

float progress = (float)(i + 1) / dataList.Length;
progressWindow.Progress(progress, $"Processed symmetric link {i + 1}/{dataList.Length}");

progressWindow.CloseWindow();
```

**Progress window features**:
- Custom YUCP branding
- Transparent background
- Centers on editor window
- Auto-closes after processing

### Editor UI Implementation

**File**: `Editor/Header/AttachToBodyPartDataInstances.cs`

The custom inspector uses Unity's UIElements (Visual Elements) system:

```csharp
[CustomEditor(typeof(AttachToBodyPartData))]
public class AttachToBodyPartDataEditor : UnityEditor.Editor
{
    public override VisualElement CreateInspectorGUI()
    {
        var root = new VisualElement();
        
        // Add YUCP header overlay
        root.Add(YUCPComponentHeader.CreateHeaderOverlay("Symmetric Armature Auto-Link"));
        
        // Add IMGUI container for property fields
        var container = new IMGUIContainer(() => {
            // Draw properties using SerializedObject
        });
        
        return root;
    }
}
```

**Header overlay system**:
- Uses `YUCPComponentHeader.CreateHeaderOverlay()` for consistent branding
- Overlays on top of Unity's default header
- Shows YUCP logo and component name
- Implemented using absolute positioning

### Performance Characteristics

**Runtime**: None - component is `IEditorOnly` and removed from builds  
**Build time**: ~1ms per component  
**Memory**: Negligible - simple data container  
**Processing**: Single distance calculation per component  

### Humanoid Bone Mapping

Full mapping of `BodyPart` enum to `HumanBodyBones`:

| BodyPart | Left Bone | Right Bone |
|----------|-----------|------------|
| UpperLeg | LeftUpperLeg | RightUpperLeg |
| LowerLeg | LeftLowerLeg | RightLowerLeg |
| Foot | LeftFoot | RightFoot |
| Toes | LeftToes | RightToes |
| Shoulder | LeftShoulder | RightShoulder |
| UpperArm | LeftUpperArm | RightUpperArm |
| LowerArm | LeftLowerArm | RightLowerArm |
| Hand | LeftHand | RightHand |
| ThumbProximal | LeftThumbProximal | RightThumbProximal |
| ThumbIntermediate | LeftThumbIntermediate | RightThumbIntermediate |
| ThumbDistal | LeftThumbDistal | RightThumbDistal |
| IndexProximal | LeftIndexProximal | RightIndexProximal |
| IndexIntermediate | LeftIndexIntermediate | RightIndexIntermediate |
| IndexDistal | LeftIndexDistal | RightIndexDistal |
| MiddleProximal | LeftMiddleProximal | RightMiddleProximal |
| MiddleIntermediate | LeftMiddleIntermediate | RightMiddleIntermediate |
| MiddleDistal | LeftMiddleDistal | RightMiddleDistal |
| RingProximal | LeftRingProximal | RightRingProximal |
| RingIntermediate | LeftRingIntermediate | RightRingIntermediate |
| RingDistal | LeftRingDistal | RightRingDistal |
| LittleProximal | LeftLittleProximal | RightLittleProximal |
| LittleIntermediate | LeftLittleIntermediate | RightLittleIntermediate |
| LittleDistal | LeftLittleDistal | RightLittleDistal |
| Eye | LeftEye | RightEye |

### Source Code Reference

**Runtime Component**:
```
Packages/com.yucp.components/Runtime/Components/Data/AttachToBodyPartData.cs
```

**Build Processor**:
```
Packages/com.yucp.components/Editor/Components/Processors/AttachToBodyPartProcessor.cs
```

**Custom Inspector**:
```
Packages/com.yucp.components/Editor/Header/AttachToBodyPartDataInstances.cs
```

**Assembly Definition**:
```
Runtime: yucp.components.Runtime.asmdef
Editor: yucp.components.Editor.asmdef
```

### Integration Points

**VRCFury API calls**:
```csharp
using com.vrcfury.api;

// Create armature link
var link = FuryComponents.CreateArmatureLink(GameObject target);

// Link to bone
link.LinkTo(HumanBodyBones bone);              // Direct bone
link.LinkTo(HumanBodyBones bone, string path); // Bone + offset
link.LinkTo(string fullPath);                  // Full path string
```

**VRChat SDK callbacks**:
```csharp
using VRC.SDKBase.Editor.BuildPipeline;

public class AttachToBodyPartProcessor : IVRCSDKPreprocessAvatarCallback
{
    public int callbackOrder { get; } // Execution order
    public bool OnPreprocessAvatar(GameObject avatarRoot); // Main callback
}
```

### Memory Layout

Component serialization:
```
AttachToBodyPartData (MonoBehaviour)
├── part (int/enum) - 4 bytes
├── side (int/enum) - 4 bytes  
├── offset (string) - reference + string data
├── leftComponentToDelete (UnityEngine.Object ref) - 8 bytes
└── rightComponentToDelete (UnityEngine.Object ref) - 8 bytes

Total: ~32 bytes + string allocation
```

### Future Enhancements

Potential improvements for future versions:

1. **Preview visualization** - Show which side will be selected in Scene view
2. **Multiple offset paths** - Support array of offsets for complex setups
3. **Constraint support** - Integrate with Unity constraints as alternative to VRCFury
4. **Batch processing UI** - Configure multiple symmetric components at once
5. **Template presets** - Save/load common configurations



